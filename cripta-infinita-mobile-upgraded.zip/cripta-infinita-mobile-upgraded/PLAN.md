# Cripta Infinita — Passe mobile/gameplay

## Entregue
- [x] Adicionar Scar, o Carrasco, com kit Q/W/E/R, passiva de marcas e execução.
- [x] Integrar portrait e sprite gerados ao seletor e ao jogo.
- [x] Tornar controles touch maiores e mais confortáveis em telas pequenas.
- [x] Adicionar feedback de ataque/execução com partículas, hitstop, tremor e telegráficos.
- [x] Dar leitura visual mais forte aos bosses com aura, nome e barra.

## Verificação
- TypeScript: `npm run typecheck`
- Build: `npm run build`
- Smoke test: carregar `/` no servidor local e confirmar resposta HTML.
