# Memória

- O projeto original é React + TanStack Start + Canvas 2D, não Babylon.
- A base já possuía joystick, telegráficos, partículas, hitstop e tremor; o passe ampliou esses sistemas sem trocar a engine.
- Scar usa a identidade visual vermelho-ferro e entra na sexta posição do seletor.
- O sprite gerado é uma imagem transparente única, por isso é carregado como sheet 1x1.
- `npm run typecheck` e `npm run build` passaram em 28/09/2026.
- O build informa apenas avisos existentes/benignos de diretivas `use client` e migração sem DATABASE_URL.
