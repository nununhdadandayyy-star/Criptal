import fs from 'node:fs';
const root = '/home/ubuntu/grok-workspace';
function edit(file, fn) {
  const p = `${root}/${file}`;
  const before = fs.readFileSync(p, 'utf8');
  const after = fn(before);
  if (after === before) throw new Error(`No change made to ${file}`);
  fs.writeFileSync(p, after);
}

edit('src/game/types.ts', s => s.replace(
  'export type HeroId = "valkhar" | "morvak" | "volgar" | "urgot" | "sion";',
  'export type HeroId = "valkhar" | "morvak" | "volgar" | "urgot" | "sion" | "scar";'
));

edit('src/game/heroes.ts', s => s
  .replace('    ],\n  },\n};\n\nexport const SKILL_AIM', `    ],
  },
  scar: {
    id: "scar",
    name: "Scar",
    title: "o Carrasco",
    role: "Executor",
    blurb: "Ele não caça heróis. Ele marca sentenças. Cada golpe abre uma ferida que a cripta não consegue fechar.",
    portrait: "/portraits/scar.png",
    sheet: "/sprites/scar.png",
    tint: "ruin",
    passive: { name: "Sentença de Sangue", desc: "Ataques e habilidades aplicam marcas. No terceiro acúmulo, a ferida explode e o alvo fica vulnerável.", max: 3 },
    base: { hp: 980, ad: 98, as: 0.74, ms: 270, armor: 46, range: 128, radius: 21 },
    skills: [
      { slot: "q", key: "Q", name: "Corte Condenado", desc: "Arremessa o cutelo em uma linha. O ponto final causa dano extra e puxa inimigos marcados." },
      { slot: "w", key: "W", name: "Capa de Ferro", desc: "Fica intocável por um instante e devolve uma lâmina em cone. Abates renovam a proteção." },
      { slot: "e", key: "E", name: "Gancho do Carrasco", desc: "Avança até a mira e arrasta o primeiro inimigo atingido, causando atordoamento." },
      { slot: "r", key: "R", name: "Execução Final", desc: "Marca o inimigo sob a mira. Ao cair abaixo de 35% de vida, Scar o executa e espalha terror." },
    ],
  },
};

export const SKILL_AIM`)
  .replace('  sion: {\n    q: { shape: "line", range: 360, width: 92, radius: 0, follow: true },\n    w: { shape: "self", range: 0, width: 0, radius: 175, follow: true },\n    e: { shape: "line", range: 460, width: 46, follow: true },\n    r: { shape: "dash", range: 640, width: 78, radius: 0, follow: false },\n  },', '  sion: {\n    q: { shape: "line", range: 360, width: 92, radius: 0, follow: true },\n    w: { shape: "self", range: 0, width: 0, radius: 175, follow: true },\n    e: { shape: "line", range: 460, width: 46, radius: 0, follow: true },\n    r: { shape: "dash", range: 640, width: 78, radius: 0, follow: false },\n  },\n  scar: {\n    q: { shape: "line", range: 390, width: 54, radius: 0, follow: true },\n    w: { shape: "cone", range: 250, width: 0.55, radius: 0, follow: true },\n    e: { shape: "dash", range: 300, width: 64, radius: 0, follow: false },\n    r: { shape: "unit", range: 460, width: 96, radius: 64, follow: false },\n  },')
  .replace('export const HERO_IDS: HeroId[] = ["valkhar", "morvak", "volgar", "urgot", "sion"];', 'export const HERO_IDS: HeroId[] = ["valkhar", "morvak", "volgar", "urgot", "sion", "scar"];')
);

edit('src/game/sprites.ts', s => s
  .replace('  sion: Sheet;\n', '  sion: Sheet;\n  scar: Sheet;\n')
  .replace('    sion: load("/sprites/sion.png", 4, 4),\n', '    sion: load("/sprites/sion.png", 4, 4),\n    scar: load("/sprites/scar.png", 1, 1),\n')
);

edit('src/components/game-app.tsx', s => s
  .replace('  sion: "text-grave",\n};', '  sion: "text-grave",\n  scar: "text-ruin",\n};')
  .replace('  sion: "ring-grave",\n};', '  sion: "ring-grave",\n  scar: "ring-ruin",\n};')
  .replace('  if (id === "sion") return <Skull className={cls} />;\n  return <Crosshair className={cls} />;', '  if (id === "sion") return <Skull className={cls} />;\n  if (id === "scar") return <Swords className={cls} />;\n  return <Crosshair className={cls} />;')
  .replace('Cinco guerreiros. Waves que nunca cessam.', 'Seis guerreiros. Waves que nunca cessam.')
  .replace('className="skill-button pointer-events-auto relative flex h-16 w-16 min-w-16', 'className="skill-button pointer-events-auto relative flex h-[4.35rem] w-[4.35rem] min-w-[4.35rem] sm:h-16 sm:w-16 sm:min-w-16')
  .replace('className="relative flex size-8 items-center', 'className="relative flex size-9 items-center sm:size-8')
  .replace('className="flex items-end justify-between gap-3">\n            <div className={`combo-meter', 'className="flex items-end justify-between gap-3 pb-1">\n            <div className={`combo-meter')
  .replace('className="relative size-[92px] touch-none', 'className="relative size-[112px] touch-none sm:size-[108px]')
);

edit('src/game/world.ts', s => s
  .replace('  if (hero === "valkhar") skills.e.charges = 2;', '  if (hero === "valkhar") skills.e.charges = 2;')
  .replace('    const zombie = p.hero === "sion" && p.zombie > 0;\n', '    const zombie = p.hero === "sion" && p.zombie > 0;\n    const scar = p.hero === "scar";\n')
  .replace('    ad: h.ad + UPGRADE_POWER.ad * u.ad + (ruin ? 28 : 0) + (zombie ? 22 : 0),', '    ad: h.ad + UPGRADE_POWER.ad * u.ad + (ruin ? 28 : 0) + (zombie ? 22 : 0) + (scar && p.ultT > 0 ? 42 : 0),')
  .replace('    armor: h.armor + UPGRADE_POWER.armor * u.armor + (p.hero === "morvak" ? p.passiveN * 8 : 0),', '    armor: h.armor + UPGRADE_POWER.armor * u.armor + (p.hero === "morvak" ? p.passiveN * 8 : 0) + (scar && p.wToggle > 0 ? 28 : 0),')
  .replace('    ms: h.ms * (1 + 0.028 * u.move) * (ruin ? 1.28 : 1)', '    ms: h.ms * (1 + 0.028 * u.move) * (ruin ? 1.28 : 1)')
  .replace(' * (zombie ? 0.88 : 1),', ' * (zombie ? 0.88 : 1) * (scar && p.ultT > 0 ? 1.18 : 1),')
  .replace('function heroColor(id: HeroId) {\n', 'function heroColor(id: HeroId) {\n')
  .replace('  if (id === "sion") return "#c47a3a";\n  return "#8fa84a";', '  if (id === "sion") return "#c47a3a";\n  if (id === "scar") return "#e14b43";\n  return "#8fa84a";')
  .replace('  if (p.hero === "sion" && p.qCharge > 0 && w.preview === "q") return;', '  if (p.hero === "sion" && p.qCharge > 0 && w.preview === "q") return;')
  .replace('  const sionZ = p.hero === "sion" && p.zombie > 0 ? t.maxHp * 0.07 : 0;', '  const sionZ = p.hero === "sion" && p.zombie > 0 ? t.maxHp * 0.07 : 0;\n  const scarEmpowered = p.hero === "scar" && p.passiveN >= 2;')
  .replace('  const valkMul = valkEmpowered ? 1.6 : 1;', '  const valkMul = valkEmpowered ? 1.6 : 1;\n  const scarMul = scarEmpowered ? 1.45 : 1;')
  .replace('  hurtEnemy(w, t, skillDmg(st, 10, baseMul * furyMul * valkMul, 0) + sionZ, {', '  hurtEnemy(w, t, skillDmg(st, 10, baseMul * furyMul * valkMul * scarMul, 0) + sionZ, {')
  .replace('  if (p.hero === "sion" && p.zombie > 0) {\n    burst(w, t.x, t.y, 10, "#c47a3a", "slash", 160);', '  if (p.hero === "scar") {\n    p.passiveN = scarEmpowered ? 0 : p.passiveN + 1;\n    if (scarEmpowered) {\n      t.stunT = Math.max(t.stunT, 0.9);\n      addZone(w, "fear", t.x, t.y, 120, 0.65);\n      burst(w, t.x, t.y, 22, "#e14b43", "ring", 120);\n      floatText(w, t.x, t.y - t.radius - 14, "SENTENÇA", "#e14b43", true);\n      shake(w, 0.3);\n    }\n  }\n  if (p.hero === "sion" && p.zombie > 0) {\n    burst(w, t.x, t.y, 10, "#c47a3a", "slash", 160);')
  .replace('  if (p.hero === "sion") {\n    if (slot === "q") {', `  if (p.hero === "scar") {
    if (slot === "q") {
      if (sk.cd > 0) return;
      addTele(w, "line", p.x, p.y, ang, 390, 54, 0, 0.22, "#e14b43", "scarQ", true, true);
      cdSet(sk, 6.5 * (1 - st.cdr));
      sfx.slash();
      shake(w, 0.16);
    }
    if (slot === "w") {
      if (p.wToggle > 0) {
        p.wToggle = 0;
        addTele(w, "cone", p.x, p.y, ang, 250, 0.55, 0, 0.16, "#e14b43", "scarW", true, true);
        sfx.slash();
        shake(w, 0.22);
      } else if (sk.cd <= 0) {
        p.wToggle = 1.1;
        p.iframe = 0.42;
        cdSet(sk, 10 * (1 - st.cdr));
        burst(w, p.x, p.y, 16, "#e14b43", "ghost", 100);
        sfx.shield();
      }
    }
    if (slot === "e") {
      if (sk.cd > 0) return;
      p.dashT = 0.24;
      p.dashVx = Math.cos(ang) * 1250;
      p.dashVy = Math.sin(ang) * 1250;
      p.iframe = 0.2;
      cdSet(sk, 9 * (1 - st.cdr));
      addTele(w, "bar", p.x, p.y, ang, 300, 64, 0, 0.18, "#e14b43", "scarE", false, false);
      sfx.dash();
      shake(w, 0.28);
    }
    if (slot === "r") {
      if (sk.cd > 0) return;
      const t = hoverTarget(w, 460);
      if (!t) { sfx.deny(); return; }
      p.rMarkId = t.id;
      p.rMarkT = 8;
      p.ultT = 10;
      cdSet(sk, 68 * (1 - st.cdr * 0.3));
      t.markT = 8;
      burst(w, t.x, t.y, 24, "#e14b43", "ring", 100);
      floatText(w, t.x, t.y - t.radius - 18, "SENTENÇA FINAL", "#e14b43", true);
      w.announce = "Ninguém escapa do Carrasco";
      w.announceT = 1.5;
      sfx.ult();
      shake(w, 0.42);
    }
  }

  if (p.hero === "sion") {
    if (slot === "q") {`)
  .replace('  if (t.tag.startsWith("vq")) {', '  if (t.tag === "scarQ") {\n    hitShape(w, t, skillDmg(st, 26, 1.35, 0.15), 34);\n    const hit = nearest(w, t.x + Math.cos(t.ang) * t.len, t.y + Math.sin(t.ang) * t.len, 90);\n    if (hit && hit.markT > 0) { hit.pullT = 0.3; hit.pullX = p.x; hit.pullY = p.y; }\n    burst(w, p.x + Math.cos(t.ang) * 160, p.y + Math.sin(t.ang) * 160, 18, "#e14b43", "slash", 130);\n    sfx.slash(); shake(w, 0.24); stop(w, 0.04);\n  } else if (t.tag === "scarW") {\n    hitShape(w, t, skillDmg(st, 22, 1.05, 0.2), 24);\n    burst(w, p.x, p.y, 18, "#e14b43", "ring", 100);\n  } else if (t.tag === "scarE") {\n    hitShape(w, t, skillDmg(st, 24, 1.15, 0.1), 42);\n    for (const e of w.enemies) if (e.alive && inLine(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid)) e.stunT = Math.max(e.stunT, 0.8);\n    sfx.chain(); shake(w, 0.28);\n  } else if (t.tag.startsWith("vq")) {')
  .replace('  if (p.hero === "urgot" && e.id === p.rMarkId && e.hp > 0 && e.hp / e.maxHp <= 0.28) {', '  if (p.hero === "scar" && e.id === p.rMarkId && e.hp > 0 && e.hp / e.maxHp <= 0.35) {\n    floatText(w, e.x, e.y - e.radius - 18, "EXECUTA", "#e14b43", true);\n    e.hp = 0;\n    burst(w, e.x, e.y, 30, "#e14b43", "ring", 120);\n    addZone(w, "fear", e.x, e.y, 180, 0.8);\n    shake(w, 0.6); stop(w, 0.12);\n    sfx.execute();\n    p.rMarkId = -1; p.rMarkT = 0;\n  }\n  if (p.hero === "urgot" && e.id === p.rMarkId && e.hp > 0 && e.hp / e.maxHp <= 0.28) {')
);

edit('src/game/render.ts', s => s
  .replace('              : p.hero === "sion"\n                ? "#c47a3a"\n                : "#8fa84a";', '              : p.hero === "sion"\n                ? "#c47a3a"\n                : p.hero === "scar"\n                  ? "#e14b43"\n                  : "#8fa84a";')
  .replace('  if (p.hero === "sion") {\n    if (p.qCharge > 0) {', '  if (p.hero === "scar") {\n    ctx.globalAlpha = 0.7;\n    ctx.strokeStyle = "#e14b43";\n    ctx.lineWidth = 3;\n    ctx.beginPath();\n    ctx.arc(p.x, p.y, radius + 9 + Math.sin(w.time * 7) * 2, 0, Math.PI * 2);\n    ctx.stroke();\n    if (p.passiveN > 0) {\n      for (let i = 0; i < p.passiveN; i++) {\n        const a = w.time * 2.4 + i * 2.1;\n        ctx.fillStyle = "#e14b43";\n        ctx.beginPath(); ctx.arc(p.x + Math.cos(a) * (radius + 10), p.y + Math.sin(a) * (radius + 10), 4, 0, Math.PI * 2); ctx.fill();\n      }\n    }\n  }\n  if (p.hero === "sion") {\n    if (p.qCharge > 0) {')
  .replace('const size = (p.hero === "volgar" ? 86 : p.hero === "urgot" ? 88 : p.hero === "sion" ? 92 : 80) * p.sizeMul;', 'const size = (p.hero === "volgar" ? 86 : p.hero === "urgot" ? 88 : p.hero === "sion" ? 92 : p.hero === "scar" ? 94 : 80) * p.sizeMul;')
  .replace('    const drawn = drawSheet(ctx, sheet, frame, row, p.x, py, size, p.flash);\n    if (!drawn) sil(ctx, p.hero, p.x, py, size, p.face, p.flash);', '    const drawn = p.hero === "scar" ? drawSheet(ctx, sheet, 0, 0, p.x, py, size, p.flash) : drawSheet(ctx, sheet, frame, row, p.x, py, size, p.flash);\n    if (!drawn) sil(ctx, p.hero, p.x, py, size, p.face, p.flash);')
  .replace('      e.kind === "elite" || e.kind === "boss" || e.kind === "herald" || e.kind === "devourer" || e.kind === "lich",', '      e.kind === "elite" || e.kind === "boss" || e.kind === "herald" || e.kind === "devourer" || e.kind === "lich",')
);

edit('src/styles.css', s => s + `\n/* Mobile-first combat controls */\n@media (max-width: 640px) {\n  .game-canvas { cursor: default; }\n  .hud-chip { backdrop-filter: blur(14px); }\n  .skill-button { min-height: 69px; min-width: 69px; border-radius: 18px; }\n  .game-root > .absolute > .mt-auto { padding-bottom: max(8px, env(safe-area-inset-bottom)); }\n}\n`);

console.log('scar pass applied');
