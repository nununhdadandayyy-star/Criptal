import fs from 'node:fs';
const p='/home/ubuntu/grok-workspace/src/game/world.ts';
let s=fs.readFileSync(p,'utf8');
s=s.replace('  const zombie = p.hero === "sion" && p.zombie > 0;\n  const asBase', '  const zombie = p.hero === "sion" && p.zombie > 0;\n  const scar = p.hero === "scar";\n  const asBase');
s=s.replace('  const valkMul = valkEmpowered ? 1.6 : 1;\n  const scarMul = scarEmpowered ? 1.45 : 1;\n  const sionZ', '  const valkMul = valkEmpowered ? 1.6 : 1;\n  const scarEmpowered = p.hero === "scar" && p.passiveN >= 2;\n  const scarMul = scarEmpowered ? 1.45 : 1;\n  const sionZ');
s=s.replace('  const sionZ = p.hero === "sion" && p.zombie > 0 ? t.maxHp * 0.07 : 0;\n  const scarEmpowered = p.hero === "scar" && p.passiveN >= 2;\n', '  const sionZ = p.hero === "sion" && p.zombie > 0 ? t.maxHp * 0.07 : 0;\n');
fs.writeFileSync(p,s);
console.log('fixed');
