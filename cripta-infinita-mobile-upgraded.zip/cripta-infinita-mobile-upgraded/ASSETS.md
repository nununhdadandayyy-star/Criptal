# Assets

| Asset | Uso | Origem |
|---|---|---|
| `/portraits/scar.png` | Retrato do Scar no seletor e título | Gerado com prompt dark-fantasy original, 1536x2304 |
| `/sprites/scar.png` | Corpo do Scar no combate | Gerado com fundo transparente, 1920x1920 |
| `public/portraits/*.jpg` | Retratos dos cinco heróis existentes | Assets originais do projeto |
| `public/sprites/*.png` | Sprites dos heróis e inimigos existentes | Assets originais do projeto |
