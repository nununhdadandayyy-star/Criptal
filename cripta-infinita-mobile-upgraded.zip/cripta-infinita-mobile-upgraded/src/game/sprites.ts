export type Sheet = {
  img: HTMLImageElement;
  cols: number;
  rows: number;
  ready: boolean;
};

function load(src: string, cols: number, rows: number): Sheet {
  const img = new Image();
  img.crossOrigin = "anonymous";
  const sheet: Sheet = { img, cols, rows, ready: false };
  img.onload = () => {
    sheet.ready = true;
  };
  img.onerror = () => {
    sheet.ready = false;
  };
  img.src = src;
  return sheet;
}

export type SpriteBank = {
  valkhar: Sheet;
  morvak: Sheet;
  volgar: Sheet;
  urgot: Sheet;
  sion: Sheet;
  scar: Sheet;
  ghoul: Sheet;
  skeleton: Sheet;
  brute: Sheet;
  wraith: Sheet;
  cultist: Sheet;
  hound: Sheet;
  golem: Sheet;
  herald: Sheet;
  devourer: Sheet;
  lich: Sheet;
};

export function loadSprites(): SpriteBank {
  return {
    valkhar: load("/sprites/valkhar.png", 4, 4),
    morvak: load("/sprites/morvak.png", 4, 4),
    volgar: load("/sprites/volgar.png", 4, 4),
    urgot: load("/sprites/urgot.png", 4, 4),
    sion: load("/sprites/sion.png", 4, 4),
    scar: load("/sprites/scar.png", 1, 1),
    ghoul: load("/sprites/ghoul.png", 4, 4),
    skeleton: load("/sprites/skeleton.png", 4, 4),
    brute: load("/sprites/brute.png", 2, 2),
    wraith: load("/sprites/wraith.png", 2, 2),
    cultist: load("/sprites/cultist.png", 2, 2),
    hound: load("/sprites/hound.png", 2, 2),
    golem: load("/sprites/golem.png", 2, 2),
    herald: load("/sprites/herald.png", 2, 2),
    devourer: load("/sprites/devourer.png", 2, 2),
    lich: load("/sprites/lich.png", 2, 2),
  };
}

export function dirFromAngle(ang: number): number {
  if (ang >= -Math.PI / 4 && ang < Math.PI / 4) return 2; // right
  if (ang >= Math.PI / 4 && ang < (3 * Math.PI) / 4) return 0; // down
  if (ang >= (-3 * Math.PI) / 4 && ang < -Math.PI / 4) return 3; // up
  return 1; // left
}

export function drawSheet(
  ctx: CanvasRenderingContext2D,
  sheet: Sheet,
  col: number,
  row: number,
  x: number,
  y: number,
  size: number,
  flash = 0,
): boolean {
  if (!sheet.ready || !sheet.img.complete || sheet.img.naturalWidth === 0) return false;
  const cw = sheet.img.naturalWidth / sheet.cols;
  const ch = sheet.img.naturalHeight / sheet.rows;
  const sx = Math.max(0, Math.min(sheet.cols - 1, col)) * cw;
  const sy = Math.max(0, Math.min(sheet.rows - 1, row)) * ch;
  ctx.save();
  if (flash > 0) {
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.55 + flash * 0.45;
  }
  ctx.drawImage(sheet.img, sx, sy, cw, ch, x - size / 2, y - size / 2, size, size);
  ctx.restore();
  if (flash > 0) {
    ctx.save();
    ctx.globalAlpha = Math.min(0.7, flash);
    ctx.filter = "brightness(2.4)";
    ctx.drawImage(sheet.img, sx, sy, cw, ch, x - size / 2, y - size / 2, size, size);
    ctx.filter = "none";
    ctx.restore();
  }
  return true;
}
