import { EMPTY_UPGRADES, HEROES, SKILL_AIM, UPGRADE_LIST, UPGRADE_POWER, upgradeCost } from "./heroes";
import { sfx } from "./audio";
import type { Actions, Edges } from "./input";
import type { AimShape, EnemyKind, HeroId, HudSnapshot, Phase, SkillHud, SkillSlot, UpgradeId } from "./types";

export const ARENA_R = 740;
export const FIXED_DT = 1 / 60;

export type Pillar = { x: number; y: number; r: number };

export type Player = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  aim: number;
  face: number;
  aimX: number;
  aimY: number;
  hero: HeroId;
  hp: number;
  radius: number;
  sizeMul: number;
  aaCd: number;
  dashT: number;
  dashVx: number;
  dashVy: number;
  slowT: number;
  ultT: number;
  iframe: number;
  flash: number;
  hop: number;
  lastMx: number;
  lastMy: number;
  qArmed: number;
  stacks: number;
  markId: number;
  markT: number;
  eCharges: number;
  eRech: number;
  walkT: number;
  walkEmit: number;
  lungeT: number;
  combo: number;
  comboT: number;
  wToggle: number;
  rMarkId: number;
  rMarkT: number;
  pelletCd: number;
  passiveN: number;
  passiveT: number;
  passiveFlash: number;
  hasDest: boolean;
  destX: number;
  destY: number;
  qCharge: number;
  zombie: number;
  zombieUsed: boolean;
  bonusHp: number;
  unstoppable: number;
  rHitToken: number;
};

export type Enemy = {
  alive: boolean;
  id: number;
  kind: EnemyKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  kx: number;
  ky: number;
  hp: number;
  maxHp: number;
  radius: number;
  speed: number;
  ad: number;
  armor: number;
  gold: number;
  aaCd: number;
  stunT: number;
  rootT: number;
  slowT: number;
  flash: number;
  hop: number;
  markT: number;
  pullT: number;
  pullX: number;
  pullY: number;
  locked: boolean;
  specialCd: number;
  dashHit: number;
  thrownT: number;
  thrownAng: number;
  thrownDmg: number;
};

export type Bullet = {
  alive: boolean;
  kind: "chain" | "orb" | "acid" | "pellet" | "drill" | "roar" | "hex" | "bone";
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  dmg: number;
  ttl: number;
  friendly: boolean;
  hit: number;
};

export type Zone = {
  alive: boolean;
  kind: "storm" | "realm" | "slam" | "fear" | "root";
  x: number;
  y: number;
  r: number;
  t: number;
  maxT: number;
  data: number;
};

export type Telegraph = {
  alive: boolean;
  shape: "line" | "bar" | "circle" | "cone";
  x: number;
  y: number;
  ang: number;
  len: number;
  wid: number;
  r: number;
  t: number;
  maxT: number;
  color: string;
  sweet: boolean;
  tag: string;
  follow: boolean;
};

export type Particle = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number;
  maxT: number;
  size: number;
  color: string;
  kind: "spark" | "blood" | "dust" | "ring" | "slash" | "ghost";
  ang: number;
};

export type Floater = {
  alive: boolean;
  x: number;
  y: number;
  t: number;
  text: string;
  color: string;
  crit: boolean;
};

export type Decal = { x: number; y: number; r: number; a: number; color: string };

type SkillState = { cd: number; maxCd: number; charges: number; maxCharges: number; recast: number; pips: number };

export type World = {
  player: Player;
  enemies: Enemy[];
  bullets: Bullet[];
  zones: Zone[];
  telegraphs: Telegraph[];
  particles: Particle[];
  floaters: Floater[];
  decals: Decal[];
  pillars: Pillar[];
  gold: number;
  wave: number;
  kills: number;
  phase: Phase;
  betweenT: number;
  announce: string;
  announceT: number;
  upgrades: Record<UpgradeId, number>;
  trauma: number;
  hitstop: number;
  time: number;
  camX: number;
  camY: number;
  spawnQ: { kind: EnemyKind; t: number; ang: number }[];
  nextId: number;
  skills: Record<SkillSlot, SkillState>;
  qPhase: number;
  qWindow: number;
  wShield: number;
  wShieldMax: number;
  wShieldT: number;
  realmId: number;
  dashToken: number;
  shakeOn: boolean;
  preview: SkillSlot | null;
  hoverId: number;
};

export type AimGhost = {
  shape: AimShape;
  x: number;
  y: number;
  ang: number;
  len: number;
  wid: number;
  r: number;
  color: string;
  sweet: boolean;
  targetId: number;
};

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}
function angNorm(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function skill(cd = 0, charges = 1): SkillState {
  return { cd: 0, maxCd: Math.max(0.01, cd), charges, maxCharges: charges, recast: 0, pips: 0 };
}

export function makePillars(): Pillar[] {
  const out: Pillar[] = [];
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + 0.42;
    out.push({ x: Math.cos(a) * 365, y: Math.sin(a) * 365, r: 28 });
  }
  return out;
}

function enemyBase(kind: EnemyKind) {
  switch (kind) {
    case "ghoul":
      return { hp: 115, ad: 18, ms: 168, r: 15, gold: 26, armor: 6 };
    case "skeleton":
      return { hp: 210, ad: 26, ms: 128, r: 16, gold: 42, armor: 14 };
    case "brute":
      return { hp: 480, ad: 40, ms: 82, r: 22, gold: 82, armor: 24 };
    case "wraith":
      return { hp: 150, ad: 24, ms: 136, r: 15, gold: 50, armor: 8 };
    case "cultist":
      return { hp: 190, ad: 30, ms: 118, r: 16, gold: 58, armor: 10 };
    case "hound":
      return { hp: 95, ad: 22, ms: 210, r: 14, gold: 32, armor: 5 };
    case "golem":
      return { hp: 720, ad: 38, ms: 68, r: 26, gold: 96, armor: 32 };
    case "elite":
      return { hp: 920, ad: 50, ms: 144, r: 24, gold: 170, armor: 28 };
    case "boss":
      return { hp: 2800, ad: 64, ms: 90, r: 36, gold: 420, armor: 34 };
    case "herald":
      return { hp: 3400, ad: 58, ms: 112, r: 34, gold: 480, armor: 30 };
    case "devourer":
      return { hp: 4300, ad: 74, ms: 96, r: 42, gold: 560, armor: 36 };
    case "lich":
      return { hp: 3800, ad: 62, ms: 102, r: 34, gold: 520, armor: 26 };
  }
}

export function createWorld(hero: HeroId): World {
  const h = HEROES[hero];
  const skills: Record<SkillSlot, SkillState> = {
    q: skill(1),
    w: skill(1),
    e: skill(1, hero === "valkhar" ? 2 : 1),
    r: skill(1),
  };
  if (hero === "valkhar") skills.e.charges = 2;
  return {
    player: {
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      aim: -Math.PI / 2,
      face: -Math.PI / 2,
      aimX: 0,
      aimY: -160,
      hero,
      hp: h.base.hp,
      radius: h.base.radius,
      sizeMul: 1,
      aaCd: 0,
      dashT: 0,
      dashVx: 0,
      dashVy: 0,
      slowT: 0,
      ultT: 0,
      iframe: 0,
      flash: 0,
      hop: 0,
      lastMx: 0,
      lastMy: -1,
      qArmed: 0,
      stacks: 0,
      markId: -1,
      markT: 0,
      eCharges: hero === "valkhar" ? 2 : 1,
      eRech: 0,
      walkT: 0,
      walkEmit: 0,
      lungeT: 0,
      combo: 0,
      comboT: 0,
      wToggle: 0,
      rMarkId: -1,
      rMarkT: 0,
      pelletCd: 0,
      passiveN: 0,
      passiveT: 1.15,
      passiveFlash: 0,
      hasDest: false,
      destX: 0,
      destY: 0,
      qCharge: 0,
      zombie: 0,
      zombieUsed: false,
      bonusHp: 0,
      unstoppable: 0,
      rHitToken: 0,
    },
    enemies: [],
    bullets: [],
    zones: [],
    telegraphs: [],
    particles: [],
    floaters: [],
    decals: [],
    pillars: makePillars(),
    gold: 80,
    wave: 0,
    kills: 0,
    phase: "between",
    betweenT: 3.2,
    announce: "Clique no chão para andar",
    announceT: 3.2,
    upgrades: { ...EMPTY_UPGRADES },
    trauma: 0,
    hitstop: 0,
    time: 0,
    camX: 0,
    camY: 0,
    spawnQ: [],
    nextId: 1,
    skills,
    qPhase: 0,
    qWindow: 0,
    wShield: 0,
    wShieldMax: 0,
    wShieldT: 0,
    realmId: -1,
    dashToken: 1,
    shakeOn: true,
    preview: null,
    hoverId: -1,
  };
}

export type StatsNow = {
  ad: number;
  ap: number;
  crit: number;
  critDmg: number;
  ls: number;
  maxHp: number;
  armor: number;
  as: number;
  asBase: number;
  ms: number;
  cdr: number;
  regen: number;
  range: number;
  radius: number;
};

export function statsOf(w: World): StatsNow {
  const h = HEROES[w.player.hero].base;
  const u = w.upgrades;
  const p = w.player;
  const ruin = p.hero === "valkhar" && p.ultT > 0;
  const storm = p.hero === "volgar" && p.ultT > 0;
  const zombie = p.hero === "sion" && p.zombie > 0;
  const scar = p.hero === "scar";
  const asBase = h.as * (1 + 0.035 * u.haste);
  return {
    ad: h.ad + UPGRADE_POWER.ad * u.ad + (ruin ? 28 : 0) + (zombie ? 22 : 0) + (scar && p.ultT > 0 ? 42 : 0),
    ap: UPGRADE_POWER.ap * u.ap,
    crit: Math.min(0.75, 0.08 + 0.022 * u.crit),
    critDmg: 1.5 + 0.06 * u.critDmg,
    ls: UPGRADE_POWER.ls * u.lifesteal + (ruin ? 0.18 : 0) + (zombie ? 0.12 : 0),
    maxHp: h.hp + UPGRADE_POWER.hp * u.hp + p.bonusHp + (storm ? 420 : 0) + (zombie ? 280 : 0),
    armor: h.armor + UPGRADE_POWER.armor * u.armor + (p.hero === "morvak" ? p.passiveN * 8 : 0) + (scar && p.wToggle > 0 ? 28 : 0),
    as: asBase,
    asBase,
    ms: h.ms * (1 + 0.028 * u.move) * (ruin ? 1.28 : 1) * (p.hero === "volgar" && p.qArmed > 0 ? 1.42 : 1) * (p.hero === "urgot" && p.wToggle > 0 ? 0.82 : 1) * (zombie ? 0.88 : 1) * (scar && p.ultT > 0 ? 1.18 : 1),
    cdr: Math.min(UPGRADE_POWER.cdrCap, UPGRADE_POWER.cdr * u.cdr),
    regen: 1.8 + 0.85 * u.regen,
    range: h.range * (storm ? 1.35 : 1) * p.sizeMul,
    radius: h.radius * p.sizeMul,
  };
}

function skillDmg(st: StatsNow, base: number, adR: number, apR = 0) {
  return base + st.ad * adR + st.ap * apR;
}

function acquire<T extends { alive: boolean }>(pool: T[], make: () => T): T {
  for (const it of pool) if (!it.alive) return it;
  const n = make();
  pool.push(n);
  return n;
}

function burst(w: World, x: number, y: number, n: number, color: string, kind: Particle["kind"], spd = 140) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2;
    const s = spd * (0.4 + Math.random());
    const p = acquire(w.particles, () => ({
      alive: false,
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      t: 0,
      maxT: 1,
      size: 3,
      color: "#fff",
      kind: "spark" as const,
      ang: 0,
    }));
    p.alive = true;
    p.x = x;
    p.y = y;
    p.vx = Math.cos(a) * s;
    p.vy = Math.sin(a) * s;
    p.t = 0;
    p.maxT = 0.25 + Math.random() * 0.35;
    p.size = kind === "ring" ? 10 : 2 + Math.random() * 4;
    p.color = color;
    p.kind = kind;
    p.ang = a;
  }
}

function floatText(w: World, x: number, y: number, text: string, color: string, crit = false) {
  const f = acquire(w.floaters, () => ({
    alive: false,
    x: 0,
    y: 0,
    t: 0,
    text: "",
    color: "#fff",
    crit: false,
  }));
  f.alive = true;
  f.x = x + (Math.random() - 0.5) * 18;
  f.y = y - 10;
  f.t = 0;
  f.text = text;
  f.color = color;
  f.crit = crit;
}

function decal(w: World, x: number, y: number, r: number, color: string) {
  if (w.decals.length > 80) w.decals.shift();
  w.decals.push({ x, y, r, a: 0.55, color });
}

function shake(w: World, amt: number) {
  if (!w.shakeOn) return;
  w.trauma = Math.min(1, w.trauma + amt);
}

function stop(w: World, t: number) {
  w.hitstop = Math.min(0.07, Math.max(w.hitstop, t));
}

function inLine(px: number, py: number, ox: number, oy: number, ang: number, length: number, width: number) {
  const dx = px - ox;
  const dy = py - oy;
  const c = Math.cos(-ang);
  const s = Math.sin(-ang);
  const lx = dx * c - dy * s;
  const ly = dx * s + dy * c;
  return lx >= 0 && lx <= length && Math.abs(ly) <= width / 2;
}

function inCone(px: number, py: number, ox: number, oy: number, ang: number, range: number, half: number) {
  const dx = px - ox;
  const dy = py - oy;
  const d = Math.hypot(dx, dy);
  if (d > range || d < 1) return false;
  return Math.abs(angNorm(Math.atan2(dy, dx) - ang)) <= half;
}

function inCirc(px: number, py: number, cx: number, cy: number, r: number) {
  const dx = px - cx;
  const dy = py - cy;
  return dx * dx + dy * dy <= r * r;
}

export function groundPoint(px: number, py: number, tx: number, ty: number, range: number) {
  const dx = tx - px;
  const dy = ty - py;
  const d = Math.hypot(dx, dy) || 0.001;
  if (d <= range) return { x: tx, y: ty };
  return { x: px + (dx / d) * range, y: py + (dy / d) * range };
}

function collideWorld(w: World, x: number, y: number, r: number): { x: number; y: number } {
  let px = x;
  let py = y;
  const clampArena = () => {
    const d = Math.hypot(px, py);
    const max = ARENA_R - r - 2;
    if (d > max) {
      const k = max / (d || 1);
      px *= k;
      py *= k;
    }
  };
  clampArena();
  for (let n = 0; n < 3; n++) {
    for (const p of w.pillars) {
      const dx = px - p.x;
      const dy = py - p.y;
      const dist = Math.hypot(dx, dy) || 0.001;
      const min = r + p.r + 1;
      if (dist < min) {
        const k = (min - dist) / dist;
        px += dx * k;
        py += dy * k;
      }
    }
    clampArena();
  }
  if (!Number.isFinite(px) || !Number.isFinite(py)) return { x: 0, y: 0 };
  return { x: px, y: py };
}

function heal(w: World, amt: number) {
  const st = statsOf(w);
  w.player.hp = clamp(w.player.hp + amt, 0, st.maxHp);
}

function inRealm(w: World, e: Enemy): boolean {
  if (w.realmId < 0) return false;
  for (const z of w.zones) {
    if (z.alive && z.kind === "realm") return inCirc(e.x, e.y, z.x, z.y, z.r);
  }
  return false;
}

function killEnemy(w: World, e: Enemy) {
  e.alive = false;
  w.kills += 1;
  w.gold += e.gold;
  burst(w, e.x, e.y, 14, e.kind === "wraith" || e.kind === "lich" ? "#8eb4c8" : "#8a2e28", "blood", 180);
  decal(w, e.x, e.y, e.radius * 1.6, "#4a1c18");
  floatText(w, e.x, e.y - 16, `+${e.gold}`, "#c4b08a");
  sfx.coin();
  const isBoss = e.kind === "boss" || e.kind === "herald" || e.kind === "devourer" || e.kind === "lich";
  shake(w, isBoss ? 0.55 : e.kind === "elite" ? 0.32 : 0.12);
  if (isBoss) stop(w, 0.12);
  if (w.player.hero === "sion") {
    const bonus = isBoss ? 48 : e.kind === "elite" || e.kind === "golem" ? 22 : e.kind === "brute" ? 14 : 8;
    w.player.bonusHp += bonus;
    heal(w, bonus);
    floatText(w, w.player.x, w.player.y - 28, `+${bonus} HP`, "#c47a3a");
  }
}

function hurtEnemy(
  w: World,
  e: Enemy,
  raw: number,
  opts: { sweet?: boolean; knock?: number; ang?: number; name?: string },
) {
  if (!e.alive) return 0;
  const st = statsOf(w);
  const p = w.player;
  let dmg = raw * (1 + Math.min(0.2, p.combo * 0.04));
  const crit = Math.random() < st.crit;
  if (crit) dmg *= st.critDmg;
  if (opts.sweet) dmg *= 1.48;
  if (inRealm(w, e)) dmg *= 1.22;
  dmg *= 100 / (100 + e.armor);
  e.hp -= dmg;
  e.flash = 0.12;
  p.combo = Math.min(5, p.combo + 1);
  p.comboT = 0.9;
  heal(w, dmg * st.ls);
  floatText(w, e.x, e.y - e.radius, `${Math.round(dmg)}`, crit ? "#e8d7b0" : "#ebe6dc", crit);
  if (opts.knock && opts.ang !== undefined) {
    e.kx += Math.cos(opts.ang) * opts.knock * 3.4;
    e.ky += Math.sin(opts.ang) * opts.knock * 3.4;
    e.hop = 0.18;
  }
  burst(w, e.x, e.y, crit ? 10 : 5, crit ? "#e8d7b0" : "#b54a40", "spark", 160);
  if (crit) {
    sfx.crit();
    stop(w, 0.045);
    shake(w, 0.2);
  } else {
    sfx.hit();
    shake(w, 0.08);
  }
  if (p.hero === "scar" && e.id === p.rMarkId && e.hp > 0 && e.hp / e.maxHp <= 0.35) {
    floatText(w, e.x, e.y - e.radius - 18, "EXECUTA", "#e14b43", true);
    e.hp = 0;
    burst(w, e.x, e.y, 30, "#e14b43", "ring", 120);
    addZone(w, "fear", e.x, e.y, 180, 0.8);
    shake(w, 0.6); stop(w, 0.12);
    sfx.execute();
    p.rMarkId = -1; p.rMarkT = 0;
  }
  if (p.hero === "urgot" && e.id === p.rMarkId && e.hp > 0 && e.hp / e.maxHp <= 0.28) {
    floatText(w, e.x, e.y - e.radius - 18, "EXECUTA", "#8fa84a", true);
    e.hp = 0;
    heal(w, st.maxHp * 0.08);
    addZone(w, "fear", e.x, e.y, 180, 0.7);
    for (const o of w.enemies) {
      if (o.alive && o.id !== e.id && inCirc(o.x, o.y, e.x, e.y, 180)) {
        o.stunT = Math.max(o.stunT, 0.85);
        const a = Math.atan2(o.y - e.y, o.x - e.x);
        o.kx += Math.cos(a) * 80;
        o.ky += Math.sin(a) * 80;
      }
    }
    burst(w, e.x, e.y, 26, "#8fa84a", "ring", 90);
    sfx.execute();
    shake(w, 0.55);
    stop(w, 0.1);
    p.rMarkId = -1;
    p.rMarkT = 0;
  }
  if (e.hp <= 0) killEnemy(w, e);
  return dmg;
}

function nearest(w: World, x: number, y: number, range: number, pred?: (e: Enemy) => boolean): Enemy | null {
  let best: Enemy | null = null;
  let bd = range;
  for (const e of w.enemies) {
    if (!e.alive) continue;
    if (pred && !pred(e)) continue;
    const d = Math.hypot(e.x - x, e.y - y);
    if (d < bd) {
      bd = d;
      best = e;
    }
  }
  return best;
}

function preferredTarget(w: World, range: number): Enemy | null {
  const p = w.player;
  let best: Enemy | null = null;
  let bs = 1e9;
  for (const e of w.enemies) {
    if (!e.alive) continue;
    const d = Math.hypot(e.x - p.x, e.y - p.y);
    if (d > range) continue;
    const ang = Math.abs(angNorm(Math.atan2(e.y - p.y, e.x - p.x) - p.aim));
    const score = d + ang * 90;
    if (score < bs) {
      bs = score;
      best = e;
    }
  }
  return best;
}

function hoverTarget(w: World, range: number): Enemy | null {
  const p = w.player;
  let best: Enemy | null = null;
  let bd = 86;
  for (const e of w.enemies) {
    if (!e.alive) continue;
    if (Math.hypot(e.x - p.x, e.y - p.y) > range) continue;
    const d = Math.hypot(e.x - p.aimX, e.y - p.aimY);
    if (d < bd) {
      bd = d;
      best = e;
    }
  }
  return best ?? preferredTarget(w, range);
}

function hitShape(w: World, t: Telegraph, dmg: number, knock: number) {
  for (const e of w.enemies) {
    if (!e.alive) continue;
    let hit = false;
    let sweet = false;
    if (t.shape === "line") {
      hit = inLine(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid);
      if (hit) {
        const dx = e.x - t.x;
        const dy = e.y - t.y;
        const along = dx * Math.cos(t.ang) + dy * Math.sin(t.ang);
        sweet = t.sweet && along > t.len * 0.62;
      }
    } else if (t.shape === "bar") {
      hit = inLine(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid);
      sweet = t.sweet && hit;
    } else if (t.shape === "circle") {
      hit = inCirc(e.x, e.y, t.x, t.y, t.r);
      if (hit && t.sweet) {
        const d = Math.hypot(e.x - t.x, e.y - t.y);
        sweet = d > t.r * 0.55;
      }
    } else {
      hit = inCone(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid);
    }
    if (hit) hurtEnemy(w, e, dmg, { sweet, knock: knock + (sweet ? 18 : 0), ang: t.ang });
  }
}

function spawnEnemy(w: World, kind: EnemyKind, ang: number) {
  const b = enemyBase(kind);
  const mul = 1 + (w.wave - 1) * 0.22;
  const dmgM = 1 + (w.wave - 1) * 0.18;
  const spdM = 1 + Math.min(0.55, (w.wave - 1) * 0.032);
  const dist = ARENA_R - 40;
  const x = Math.cos(ang) * dist;
  const y = Math.sin(ang) * dist;
  const e = acquire(w.enemies, () => ({
    alive: false,
    id: 0,
    kind: "ghoul" as const,
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    kx: 0,
    ky: 0,
    hp: 1,
    maxHp: 1,
    radius: 12,
    speed: 80,
    ad: 8,
    armor: 0,
    gold: 1,
    aaCd: 0,
    stunT: 0,
    rootT: 0,
    slowT: 0,
    flash: 0,
    hop: 0,
    markT: 0,
    pullT: 0,
    pullX: 0,
    pullY: 0,
    locked: false,
    specialCd: 0,
    dashHit: 0,
    thrownT: 0,
    thrownAng: 0,
    thrownDmg: 0,
  }));
  e.alive = true;
  e.id = w.nextId++;
  e.kind = kind;
  e.x = x;
  e.y = y;
  e.vx = 0;
  e.vy = 0;
  e.kx = 0;
  e.ky = 0;
  e.hp = b.hp * mul;
  e.maxHp = e.hp;
  e.radius = b.r;
  e.speed = b.ms * spdM;
  e.ad = b.ad * dmgM;
  e.armor = b.armor + w.wave * 0.6;
  e.gold = b.gold + Math.floor(w.wave * 2.2);
  e.aaCd = 0.4;
  e.stunT = 0;
  e.rootT = 0;
  e.slowT = 0;
  e.flash = 0;
  e.hop = 0;
  e.markT = 0;
  e.pullT = 0;
  e.locked = false;
  e.specialCd = 2 + Math.random();
  e.dashHit = 0;
  e.thrownT = 0;
  e.thrownAng = 0;
  e.thrownDmg = 0;
}

function planWave(w: World) {
  w.wave += 1;
  w.spawnQ.length = 0;
  const n = w.wave;
  const push = (kind: EnemyKind, count: number, delay: number, ring = 0) => {
    for (let i = 0; i < count; i++) {
      const ang = ring + (i / Math.max(1, count)) * Math.PI * 2 + n * 0.37;
      w.spawnQ.push({ kind, t: delay + i * 0.22, ang });
    }
  };
  push("ghoul", 6 + n * 2, 0.2, 0.2);
  if (n >= 2) push("skeleton", 2 + Math.floor(n * 0.8), 1.1, 1.1);
  if (n >= 2) push("hound", 2 + Math.floor(n * 0.55), 0.7, 2.2);
  if (n >= 3) push("wraith", Math.max(1, Math.floor((n - 1) * 0.5)), 1.8, 2.4);
  if (n >= 4) push("brute", Math.max(1, Math.floor((n - 2) * 0.45)), 2.2, 3.6);
  if (n >= 5) push("cultist", Math.max(1, Math.floor((n - 3) * 0.4)), 2.6, 4.1);
  if (n >= 6) push("golem", Math.max(1, Math.floor((n - 5) * 0.35)), 3.1, 5.2);
  if (n % 5 === 0) push("elite", 1 + Math.floor(n / 10), 3, 0.8);
  if (n % 7 === 0) push("hound", 3 + Math.floor(n / 7), 0.4, 3.8);
  if (n % 10 === 0) {
    const rot = (n / 10) % 4;
    const boss: EnemyKind = rot === 1 ? "boss" : rot === 2 ? "herald" : rot === 3 ? "devourer" : "lich";
    push(boss, 1, 4, Math.PI);
    w.announce = rot === 1 ? `Onda ${n} · Colosso` : rot === 2 ? `Onda ${n} · Arauto` : rot === 3 ? `Onda ${n} · Devorador` : `Onda ${n} · Lich`;
  } else {
    w.announce = `Onda ${n}`;
  }
  if (n % 15 === 0) push("elite", 2, 5.2, 1.7);
  w.phase = "combat";
  w.announceT = 1.8;
  sfx.wave();
}

function addTele(
  w: World,
  shape: Telegraph["shape"],
  x: number,
  y: number,
  ang: number,
  len: number,
  wid: number,
  r: number,
  delay: number,
  color: string,
  tag: string,
  sweet = false,
  follow = false,
) {
  const t = acquire(w.telegraphs, () => ({
    alive: false,
    shape: "line" as const,
    x: 0,
    y: 0,
    ang: 0,
    len: 0,
    wid: 0,
    r: 0,
    t: 0,
    maxT: 1,
    color: "#fff",
    sweet: false,
    tag: "",
    follow: false,
  }));
  t.alive = true;
  t.shape = shape;
  t.x = x;
  t.y = y;
  t.ang = ang;
  t.len = len;
  t.wid = wid;
  t.r = r;
  t.t = 0;
  t.maxT = delay;
  t.color = color;
  t.sweet = sweet;
  t.tag = tag;
  t.follow = follow;
}

function addZone(w: World, kind: Zone["kind"], x: number, y: number, r: number, dur: number, data = 0) {
  const z = acquire(w.zones, () => ({
    alive: false,
    kind: "storm" as const,
    x: 0,
    y: 0,
    r: 0,
    t: 0,
    maxT: 1,
    data: 0,
  }));
  z.alive = true;
  z.kind = kind;
  z.x = x;
  z.y = y;
  z.r = r;
  z.t = 0;
  z.maxT = dur;
  z.data = data;
}

function fireBullet(
  w: World,
  kind: Bullet["kind"],
  x: number,
  y: number,
  ang: number,
  spd: number,
  dmg: number,
  r: number,
  ttl: number,
  friendly: boolean,
) {
  const b = acquire(w.bullets, () => ({
    alive: false,
    kind: "orb" as const,
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    r: 6,
    dmg: 0,
    ttl: 1,
    friendly: true,
    hit: -1,
  }));
  b.alive = true;
  b.kind = kind;
  b.x = x;
  b.y = y;
  b.vx = Math.cos(ang) * spd;
  b.vy = Math.sin(ang) * spd;
  b.r = r;
  b.dmg = dmg;
  b.ttl = ttl;
  b.friendly = friendly;
  b.hit = -1;
}

function cdSet(s: SkillState, t: number) {
  s.cd = t;
  s.maxCd = Math.max(t, 0.01);
}

function heroColor(id: HeroId) {
  if (id === "valkhar") return "#b54a40";
  if (id === "morvak") return "#4d8a86";
  if (id === "volgar") return "#6ea8c9";
  if (id === "sion") return "#c47a3a";
  if (id === "scar") return "#e14b43";
  return "#8fa84a";
}

export function aimGhost(w: World): AimGhost | null {
  const slot = w.preview;
  if (!slot) return null;
  const p = w.player;
  const spec = SKILL_AIM[p.hero][slot];
  const color = heroColor(p.hero);
  let shape: AimShape = spec.shape;
  let range = spec.range;
  let width = spec.width;
  let radius = spec.radius;
  let ang = p.aim;
  let x = p.x;
  let y = p.y;
  let sweet = false;
  let targetId = -1;

  if (p.hero === "valkhar" && slot === "q") {
    const next = w.qWindow > 0 && w.qPhase > 0 && w.qPhase < 3 ? w.qPhase + 1 : 1;
    if (next === 1) {
      shape = "line";
      range = 280;
      width = 64;
      sweet = true;
    } else if (next === 2) {
      shape = "bar";
      range = 175;
      width = 210;
      sweet = true;
    } else {
      shape = "circle";
      radius = 155;
      range = 0;
      sweet = true;
    }
  }
  if (p.hero === "morvak" && slot === "q" && p.stacks >= 3) {
    range = 250;
    width = 110;
    sweet = true;
  }
  if (p.hero === "sion" && slot === "q") {
    const ch = clamp(p.qCharge, 0.18, 1);
    range = 170 + 210 * ch;
    width = 72 + 48 * ch;
    sweet = ch >= 0.85;
  }

  if (shape === "circle" && !spec.follow && !(p.hero === "valkhar" && slot === "q")) {
    const gp = groundPoint(p.x, p.y, p.aimX, p.aimY, range);
    x = gp.x;
    y = gp.y;
  } else if (shape === "unit") {
    const t = hoverTarget(w, range);
    if (t) {
      x = t.x;
      y = t.y;
      targetId = t.id;
      ang = Math.atan2(t.y - p.y, t.x - p.x);
    } else {
      const gp = groundPoint(p.x, p.y, p.aimX, p.aimY, range);
      x = gp.x;
      y = gp.y;
    }
  } else if (shape === "self") {
    x = p.x;
    y = p.y;
  }

  return {
    shape,
    x,
    y,
    ang,
    len: range,
    wid: width,
    r: radius,
    color,
    sweet,
    targetId,
  };
}

function tryValkharQ(w: World) {
  const p = w.player;
  const st = statsOf(w);
  const canRecast = w.qWindow > 0 && w.qPhase > 0 && w.qPhase < 3;
  if (!canRecast && w.skills.q.cd > 0) return;
  if (!canRecast) w.qPhase = 0;
  w.qPhase += 1;
  p.slowT = 0.32;
  const ang = p.aim;
  const delay = (w.qPhase === 3 ? 0.42 : 0.32) * (p.ultT > 0 ? 0.75 : 1);
  if (w.qPhase === 1) addTele(w, "line", p.x, p.y, ang, 280, 64, 0, delay, "#b54a40", "vq1", true, true);
  else if (w.qPhase === 2) addTele(w, "bar", p.x, p.y, ang, 175, 210, 0, delay, "#b54a40", "vq2", true, true);
  else addTele(w, "circle", p.x, p.y, ang, 0, 0, 155, delay, "#b54a40", "vq3", true, true);
  w.qWindow = 3.8;
  w.skills.q.recast = w.qPhase < 3 ? 3.8 : 0;
  w.skills.q.pips = w.qPhase;
  if (w.qPhase >= 3) {
    cdSet(w.skills.q, 8 * (1 - st.cdr));
    w.qWindow = 0;
  }
  sfx.slash();
}

function resolveTele(w: World, t: Telegraph) {
  const st = statsOf(w);
  const p = w.player;
  if (t.tag === "scarQ") {
    hitShape(w, t, skillDmg(st, 26, 1.35, 0.15), 34);
    const hit = nearest(w, t.x + Math.cos(t.ang) * t.len, t.y + Math.sin(t.ang) * t.len, 90);
    if (hit && hit.markT > 0) { hit.pullT = 0.3; hit.pullX = p.x; hit.pullY = p.y; }
    burst(w, p.x + Math.cos(t.ang) * 160, p.y + Math.sin(t.ang) * 160, 18, "#e14b43", "slash", 130);
    sfx.slash(); shake(w, 0.24); stop(w, 0.04);
  } else if (t.tag === "scarW") {
    hitShape(w, t, skillDmg(st, 22, 1.05, 0.2), 24);
    burst(w, p.x, p.y, 18, "#e14b43", "ring", 100);
  } else if (t.tag === "scarE") {
    hitShape(w, t, skillDmg(st, 24, 1.15, 0.1), 42);
    for (const e of w.enemies) if (e.alive && inLine(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid)) e.stunT = Math.max(e.stunT, 0.8);
    sfx.chain(); shake(w, 0.28);
  } else if (t.tag.startsWith("vq")) {
    const mul = t.tag === "vq3" ? 1.85 : t.tag === "vq2" ? 1.35 : 1.08;
    hitShape(w, t, skillDmg(st, 18, mul, 0.05), 22);
    burst(w, p.x + Math.cos(t.ang) * 40, p.y + Math.sin(t.ang) * 40, 12, "#b54a40", "slash", 90);
    shake(w, 0.22);
    stop(w, 0.03);
  } else if (t.tag === "mq") {
    const emp = t.sweet;
    hitShape(w, t, skillDmg(st, 22, emp ? 2.25 : 1.25, 0.08), emp ? 36 : 14);
    if (emp) {
      for (const e of w.enemies) {
        if (e.alive && inLine(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid)) e.slowT = Math.max(e.slowT, 1.4);
      }
    }
    sfx.slash();
  } else if (t.tag === "me") {
    for (const e of w.enemies) {
      if (!e.alive) continue;
      if (!inCone(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid)) continue;
      hurtEnemy(w, e, skillDmg(st, 16, 0.95, 0.25), { ang: t.ang, knock: 8 });
      e.pullT = 0.22;
      e.pullX = p.x;
      e.pullY = p.y;
      e.stunT = Math.max(e.stunT, 0.28);
    }
    sfx.chain();
  } else if (t.tag === "uq") {
    for (const e of w.enemies) {
      if (!e.alive) continue;
      if (!inCirc(e.x, e.y, t.x, t.y, t.r)) continue;
      hurtEnemy(w, e, skillDmg(st, 24, 1.4, 0.35), { knock: 12, ang: Math.atan2(e.y - t.y, e.x - t.x) });
      e.slowT = Math.max(e.slowT, 1.7);
    }
    burst(w, t.x, t.y, 20, "#8fa84a", "spark", 180);
    decal(w, t.x, t.y, t.r * 0.7, "#3a4a22");
    sfx.acid();
    shake(w, 0.26);
  } else if (t.tag === "ue") {
    let flips = 0;
    for (const e of w.enemies) {
      if (!e.alive) continue;
      if (!inLine(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid)) continue;
      if (flips >= 3) break;
      flips += 1;
      hurtEnemy(w, e, skillDmg(st, 20, 1.3, 0.05), { knock: 28, ang: t.ang });
      e.stunT = Math.max(e.stunT, 1.15);
      e.hop = 0.45;
    }
    if (flips > 0) {
      w.wShield = st.maxHp * 0.1;
      w.wShieldMax = w.wShield;
      w.wShieldT = 2.2;
    }
    sfx.dash();
    shake(w, 0.24);
  } else if (t.tag === "sq") {
    const ch = t.sweet ? 1 : t.wid > 100 ? 0.7 : 0.4;
    hitShape(w, t, skillDmg(st, 30, 0.7 + 1.05 * ch, 0.12), 18 + 28 * ch);
    if (ch >= 0.85) {
      for (const e of w.enemies) {
        if (e.alive && inLine(e.x, e.y, t.x, t.y, t.ang, t.len, t.wid)) {
          e.stunT = Math.max(e.stunT, 1.35);
          e.hop = 0.42;
        }
      }
    }
    burst(w, p.x + Math.cos(t.ang) * 50, p.y + Math.sin(t.ang) * 50, 16, "#c47a3a", "slash", 110);
    sfx.slash();
    shake(w, 0.28 + 0.2 * ch);
    stop(w, ch >= 0.85 ? 0.06 : 0.03);
  } else if (t.tag === "golemSlam" || t.tag === "devourBite") {
    if (inCirc(w.player.x, w.player.y, t.x, t.y, t.r) && w.player.iframe <= 0 && w.player.unstoppable <= 0) {
      playerDamage(w, t.len);
    }
  } else if (t.tag === "bossSlam") {
    if (inCirc(w.player.x, w.player.y, t.x, t.y, t.r) && w.player.iframe <= 0 && w.player.unstoppable <= 0) {
      playerDamage(w, t.len);
    }
  }
}

function autoAttack(w: World) {
  const p = w.player;
  const st = statsOf(w);
  if (p.hero === "urgot" && p.wToggle > 0) return;
  if (p.hero === "sion" && p.qCharge > 0 && w.preview === "q") return;
  if (p.aaCd > 0) return;
  const t = preferredTarget(w, st.range + 10);
  if (!t) return;
  p.aaCd = 1 / st.as;
  p.lungeT = 0.09;
  const ang = Math.atan2(t.y - p.y, t.x - p.x);

  if (p.hero === "urgot") {
    fireBullet(w, "pellet", p.x, p.y, ang, 640, skillDmg(st, 8, 1.0, 0), 6, 0.5, true);
    sfx.shotgun();
    p.passiveN += 1;
    p.passiveFlash = 0.35;
    if (p.passiveN >= 3) {
      p.passiveN = 0;
      const extra = nearest(w, t.x, t.y, 160, (e) => e.id !== t.id);
      if (extra) {
        const a2 = Math.atan2(extra.y - p.y, extra.x - p.x);
        fireBullet(w, "pellet", p.x, p.y, a2, 600, skillDmg(st, 6, 0.75, 0), 5, 0.45, true);
        burst(w, extra.x, extra.y, 10, "#8fa84a", "spark", 150);
        floatText(w, extra.x, extra.y - extra.radius - 12, "CANOS!", "#8fa84a", true);
      }
    }
    return;
  }

  const valkEmpowered = p.hero === "valkhar" && p.passiveN >= 2;
  const volgarFury = p.hero === "volgar" ? p.passiveN : 0;
  const baseMul = p.hero === "valkhar" ? 1.12 : p.hero === "sion" ? 1.15 : 1.08;
  const furyMul = p.hero === "volgar" ? 1 + volgarFury * 0.06 : 1;
  const valkMul = valkEmpowered ? 1.6 : 1;
  const scarEmpowered = p.hero === "scar" && p.passiveN >= 2;
  const scarMul = scarEmpowered ? 1.45 : 1;
  const sionZ = p.hero === "sion" && p.zombie > 0 ? t.maxHp * 0.07 : 0;
  hurtEnemy(w, t, skillDmg(st, 10, baseMul * furyMul * valkMul * scarMul, 0) + sionZ, {
    knock: 10 + (valkEmpowered ? 18 : 0) + (sionZ ? 16 : 0),
    ang,
  });

  if (p.hero === "valkhar") {
    p.passiveN = valkEmpowered ? 0 : p.passiveN + 1;
    if (valkEmpowered) {
      heal(w, st.maxHp * 0.04);
      burst(w, t.x, t.y, 18, "#b54a40", "slash", 180);
      floatText(w, t.x, t.y - t.radius - 14, "RUÍNA!", "#b54a40", true);
      stop(w, 0.045);
    }
  }

  if (p.hero === "volgar" && volgarFury > 0) {
    p.passiveN = 0;
    burst(w, t.x, t.y, 12, "#6ea8c9", "spark", 190);
    floatText(w, t.x, t.y - t.radius - 14, `FÚRIA x${volgarFury}`, "#6ea8c9", true);
    shake(w, 0.12);
  }

  if (p.hero === "morvak") p.stacks = Math.min(3, p.stacks + 1);
  if (p.hero === "volgar" && p.qArmed > 0) {
    t.stunT = Math.max(t.stunT, 1.15);
    hurtEnemy(w, t, skillDmg(st, 12, 0.6, 0.15), { knock: 28, ang });
    p.qArmed = 0;
    burst(w, t.x, t.y, 16, "#6ea8c9", "spark", 220);
    sfx.lightning();
    shake(w, 0.28);
  }
  if (p.hero === "scar") {
    p.passiveN = scarEmpowered ? 0 : p.passiveN + 1;
    if (scarEmpowered) {
      t.stunT = Math.max(t.stunT, 0.9);
      addZone(w, "fear", t.x, t.y, 120, 0.65);
      burst(w, t.x, t.y, 22, "#e14b43", "ring", 120);
      floatText(w, t.x, t.y - t.radius - 14, "SENTENÇA", "#e14b43", true);
      shake(w, 0.3);
    }
  }
  if (p.hero === "sion" && p.zombie > 0) {
    burst(w, t.x, t.y, 10, "#c47a3a", "slash", 160);
    floatText(w, t.x, t.y - t.radius - 12, "GLÓRIA", "#c47a3a", true);
  }
  sfx.slash();
}

function firePurge(w: World) {
  const p = w.player;
  const st = statsOf(w);
  if (p.pelletCd > 0) return;
  const as = Math.max(0.45, st.asBase);
  const rate = 5.4 + as * 8.2;
  p.pelletCd = 1 / rate;
  const extra = Math.min(6, Math.floor(Math.max(0, as - 0.5) * 5));
  const n = 3 + extra;
  const spread = 0.34 + n * 0.018;
  for (let i = 0; i < n; i++) {
    const t = n <= 1 ? 0 : (i / (n - 1) - 0.5) * 2;
    const ang = p.aim + t * spread;
    fireBullet(w, "pellet", p.x, p.y, ang, 740 + as * 80, skillDmg(st, 6, 0.3, 0.04), 4.2, 0.36, true);
  }
  sfx.shotgun();
}

function trySionQ(w: World) {
  const p = w.player;
  const st = statsOf(w);
  if (w.skills.q.cd > 0 && p.qCharge <= 0) return;
  const ch = clamp(Math.max(p.qCharge, 0.2), 0.2, 1);
  const len = 170 + 210 * ch;
  const wid = 72 + 48 * ch;
  addTele(w, "line", p.x, p.y, p.aim, len, wid, 0, 0.2, "#c47a3a", "sq", ch >= 0.85, true);
  p.slowT = 0.28;
  p.qCharge = 0;
  cdSet(w.skills.q, 9 * (1 - st.cdr));
  sfx.slash();
}

function cast(w: World, slot: SkillSlot) {
  const p = w.player;
  const st = statsOf(w);
  const sk = w.skills[slot];
  if (w.phase === "dead") return;
  if (p.zombie > 0) {
    sfx.deny();
    return;
  }
  const ang = p.aim;

  if (p.hero === "valkhar") {
    if (slot === "q") tryValkharQ(w);
    if (slot === "w") {
      if (sk.cd > 0) return;
      fireBullet(w, "chain", p.x, p.y, ang, 680, skillDmg(st, 18, 0.7, 0.4), 12, 0.9, true);
      cdSet(sk, 11 * (1 - st.cdr));
      sfx.chain();
    }
    if (slot === "e") {
      if (sk.charges <= 0) return;
      const dang = Math.hypot(p.lastMx, p.lastMy) > 0.15 ? Math.atan2(p.lastMy, p.lastMx) : ang;
      p.dashT = 0.18;
      p.dashVx = Math.cos(dang) * 1020;
      p.dashVy = Math.sin(dang) * 1020;
      p.iframe = 0.16;
      w.dashToken += 1;
      sk.charges -= 1;
      p.eCharges = sk.charges;
      if (sk.charges <= 0) cdSet(sk, 9 * (1 - st.cdr));
      else sk.maxCd = 4;
      burst(w, p.x, p.y, 8, "#6a1d18", "ghost", 60);
      sfx.dash();
    }
    if (slot === "r") {
      if (sk.cd > 0) return;
      p.ultT = 12;
      p.sizeMul = 1.24;
      addZone(w, "fear", p.x, p.y, 210, 0.85);
      for (const e of w.enemies) {
        if (e.alive && inCirc(e.x, e.y, p.x, p.y, 210)) {
          e.stunT = Math.max(e.stunT, 0.7);
          const a = Math.atan2(e.y - p.y, e.x - p.x);
          e.kx += Math.cos(a) * 140;
          e.ky += Math.sin(a) * 140;
        }
      }
      cdSet(sk, 70 * (1 - st.cdr * 0.4));
      burst(w, p.x, p.y, 28, "#b54a40", "ring", 40);
      sfx.ult();
      shake(w, 0.6);
      stop(w, 0.1);
      w.announce = "O mundo termina";
      w.announceT = 1.4;
    }
  }

  if (p.hero === "morvak") {
    if (slot === "q") {
      if (sk.cd > 0) return;
      const emp = p.stacks >= 3;
      addTele(w, "line", p.x, p.y, ang, emp ? 250 : 220, emp ? 110 : 82, 0, 0.24, "#4d8a86", "mq", emp, true);
      p.stacks = emp ? 0 : Math.min(3, p.stacks + 1);
      cdSet(sk, (emp ? 5.5 : 6.5) * (1 - st.cdr));
      p.slowT = 0.22;
    }
    if (slot === "w") {
      if (w.wShieldT > 0) {
        const dmg = 40 + w.wShield * 0.55 + st.ap * 0.7;
        for (const e of w.enemies) {
          if (e.alive && inCirc(e.x, e.y, p.x, p.y, 160)) {
            hurtEnemy(w, e, dmg, { knock: 24, ang: Math.atan2(e.y - p.y, e.x - p.x) });
          }
        }
        w.wShield = 0;
        w.wShieldT = 0;
        burst(w, p.x, p.y, 20, "#4d8a86", "ring", 80);
        sfx.slash();
        return;
      }
      if (sk.cd > 0) return;
      w.wShieldMax = st.maxHp * 0.18 + 70 + st.ap * 0.35;
      w.wShield = w.wShieldMax;
      w.wShieldT = 3.6;
      cdSet(sk, 11 * (1 - st.cdr));
      sfx.shield();
    }
    if (slot === "e") {
      if (sk.cd > 0) return;
      addTele(w, "cone", p.x, p.y, ang, 310, 0.72, 0, 0.18, "#4d8a86", "me", false, true);
      cdSet(sk, 10 * (1 - st.cdr));
      p.slowT = 0.16;
    }
    if (slot === "r") {
      if (sk.cd > 0) return;
      let target = hoverTarget(w, 380);
      if (!target) target = nearest(w, p.x, p.y, 380, (e) => e.kind === "boss" || e.kind === "elite");
      if (!target) target = nearest(w, p.x, p.y, 380);
      if (!target) {
        sfx.deny();
        return;
      }
      w.realmId = target.id;
      target.locked = true;
      addZone(w, "realm", target.x, target.y, 240, 7, target.id);
      cdSet(sk, 70 * (1 - st.cdr * 0.3));
      sfx.ult();
      shake(w, 0.45);
      w.announce = "Reino dos mortos";
      w.announceT = 1.4;
    }
  }

  if (p.hero === "volgar") {
    if (slot === "q") {
      if (sk.cd > 0) return;
      p.qArmed = 4;
      cdSet(sk, 9 * (1 - st.cdr));
      burst(w, p.x, p.y, 10, "#6ea8c9", "spark", 120);
      sfx.lightning();
    }
    if (slot === "w") {
      if (sk.cd > 0 && p.markT <= 0) return;
      const t = hoverTarget(w, st.range + 24) ?? preferredTarget(w, st.range + 16);
      if (!t) {
        sfx.deny();
        return;
      }
      const marked = t.markT > 0;
      const missing = 1 - p.hp / st.maxHp;
      const a = Math.atan2(t.y - p.y, t.x - p.x);
      hurtEnemy(w, t, skillDmg(st, 18, marked ? 2.05 : 1.15, marked ? 0.2 : 0.05), { knock: 14, ang: a });
      if (marked) {
        heal(w, (40 + st.maxHp * 0.08) * (1 + missing));
        t.markT = 0;
        burst(w, t.x, t.y, 14, "#c4b08a", "blood", 150);
      } else {
        t.markT = 6;
        p.markId = t.id;
        p.markT = 6;
      }
      cdSet(sk, 5.5 * (1 - st.cdr));
      sfx.hit();
    }
    if (slot === "e") {
      if (sk.cd > 0) return;
      const gp = groundPoint(p.x, p.y, p.aimX, p.aimY, 300);
      addZone(w, "storm", gp.x, gp.y, 175, 2.05);
      cdSet(sk, 12 * (1 - st.cdr));
      sfx.lightning();
    }
    if (slot === "r") {
      if (sk.cd > 0) return;
      const gp = groundPoint(p.x, p.y, p.aimX, p.aimY, 320);
      const dx = gp.x - p.x;
      const dy = gp.y - p.y;
      const dist = Math.hypot(dx, dy);
      const dur = 0.3;
      p.dashT = dur;
      p.dashVx = (dx / (dist || 1)) * (dist / dur);
      p.dashVy = (dy / (dist || 1)) * (dist / dur);
      p.ultT = 8;
      p.sizeMul = 1.48;
      p.iframe = dur;
      cdSet(sk, 70 * (1 - st.cdr * 0.3));
      sfx.ult();
      w.announce = "A tempestade desce";
      w.announceT = 1.4;
      addZone(w, "slam", gp.x, gp.y, 210, dur, 1);
    }
  }

  if (p.hero === "urgot") {
    if (slot === "q") {
      if (sk.cd > 0) return;
      const gp = groundPoint(p.x, p.y, p.aimX, p.aimY, 430);
      const a = Math.atan2(gp.y - p.y, gp.x - p.x);
      fireBullet(w, "acid", p.x, p.y, a, 520, skillDmg(st, 12, 0.45, 0.35), 9, 0.9, true);
      addTele(w, "circle", gp.x, gp.y, 0, 0, 0, 118, 0.36, "#8fa84a", "uq", false, false);
      cdSet(sk, 7.5 * (1 - st.cdr));
      p.slowT = 0.12;
      sfx.acid();
    }
    if (slot === "w") {
      if (p.wToggle > 0) {
        p.wToggle = 0;
        return;
      }
      if (sk.cd > 0) return;
      p.wToggle = 4.2;
      w.wShieldMax = st.maxHp * 0.14 + 40;
      w.wShield = w.wShieldMax;
      w.wShieldT = 4.2;
      cdSet(sk, 10 * (1 - st.cdr));
      sfx.shield();
    }
    if (slot === "e") {
      if (sk.cd > 0) return;
      const len = 270;
      p.dashT = 0.22;
      p.dashVx = Math.cos(ang) * (len / 0.22);
      p.dashVy = Math.sin(ang) * (len / 0.22);
      p.iframe = 0.12;
      addTele(w, "bar", p.x, p.y, ang, len, 72, 0, 0.16, "#8fa84a", "ue", false, false);
      cdSet(sk, 11 * (1 - st.cdr));
      sfx.dash();
    }
    if (slot === "r") {
      if (sk.cd > 0) return;
      const t = hoverTarget(w, 420);
      if (!t) {
        sfx.deny();
        return;
      }
      const a = Math.atan2(t.y - p.y, t.x - p.x);
      fireBullet(w, "drill", p.x, p.y, a, 780, skillDmg(st, 22, 1.15, 0.1), 11, 0.7, true);
      p.rMarkId = t.id;
      p.rMarkT = 4.2;
      cdSet(sk, 55 * (1 - st.cdr * 0.3));
      sfx.ult();
      shake(w, 0.4);
      w.announce = "Medo além da morte";
      w.announceT = 1.3;
    }
  }

  if (p.hero === "scar") {
    if (slot === "q") {
      if (sk.cd > 0) return;
      addTele(w, "line", p.x, p.y, ang, 390, 54, 0, 0.22, "#e14b43", "scarQ", true, true);
      cdSet(sk, 6.5 * (1 - st.cdr));
      sfx.slash();
      shake(w, 0.16);
    }
    if (slot === "w") {
      if (p.wToggle > 0) {
        p.wToggle = 0;
        addTele(w, "cone", p.x, p.y, ang, 250, 0.55, 0, 0.16, "#e14b43", "scarW", true, true);
        sfx.slash();
        shake(w, 0.22);
      } else if (sk.cd <= 0) {
        p.wToggle = 1.1;
        p.iframe = 0.42;
        cdSet(sk, 10 * (1 - st.cdr));
        burst(w, p.x, p.y, 16, "#e14b43", "ghost", 100);
        sfx.shield();
      }
    }
    if (slot === "e") {
      if (sk.cd > 0) return;
      p.dashT = 0.24;
      p.dashVx = Math.cos(ang) * 1250;
      p.dashVy = Math.sin(ang) * 1250;
      p.iframe = 0.2;
      cdSet(sk, 9 * (1 - st.cdr));
      addTele(w, "bar", p.x, p.y, ang, 300, 64, 0, 0.18, "#e14b43", "scarE", false, false);
      sfx.dash();
      shake(w, 0.28);
    }
    if (slot === "r") {
      if (sk.cd > 0) return;
      const t = hoverTarget(w, 460);
      if (!t) { sfx.deny(); return; }
      p.rMarkId = t.id;
      p.rMarkT = 8;
      p.ultT = 10;
      cdSet(sk, 68 * (1 - st.cdr * 0.3));
      t.markT = 8;
      burst(w, t.x, t.y, 24, "#e14b43", "ring", 100);
      floatText(w, t.x, t.y - t.radius - 18, "SENTENÇA FINAL", "#e14b43", true);
      w.announce = "Ninguém escapa do Carrasco";
      w.announceT = 1.5;
      sfx.ult();
      shake(w, 0.42);
    }
  }

  if (p.hero === "sion") {
    if (slot === "q") {
      trySionQ(w);
    }
    if (slot === "w") {
      if (w.wShieldT > 0) {
        const dmg = 50 + w.wShield * 0.5 + st.ap * 0.65;
        for (const e of w.enemies) {
          if (e.alive && inCirc(e.x, e.y, p.x, p.y, 175)) {
            hurtEnemy(w, e, dmg, { knock: 22, ang: Math.atan2(e.y - p.y, e.x - p.x) });
          }
        }
        w.wShield = 0;
        w.wShieldT = 0;
        burst(w, p.x, p.y, 24, "#c47a3a", "ring", 90);
        sfx.slash();
        return;
      }
      if (sk.cd > 0) return;
      w.wShieldMax = st.maxHp * 0.12 + 80 + st.ap * 0.55;
      w.wShield = w.wShieldMax;
      w.wShieldT = 6;
      cdSet(sk, 12 * (1 - st.cdr));
      sfx.shield();
    }
    if (slot === "e") {
      if (sk.cd > 0) return;
      fireBullet(w, "roar", p.x, p.y, ang, 620, skillDmg(st, 22, 0.5, 0.6), 14, 0.85, true);
      cdSet(sk, 10 * (1 - st.cdr));
      sfx.chain();
    }
    if (slot === "r") {
      if (sk.cd > 0) return;
      const spd = 520;
      p.unstoppable = 2.55;
      p.dashT = 2.55;
      p.dashVx = Math.cos(ang) * spd;
      p.dashVy = Math.sin(ang) * spd;
      p.iframe = 2.55;
      p.sizeMul = 1.18;
      p.rHitToken += 1;
      cdSet(sk, 72 * (1 - st.cdr * 0.3));
      burst(w, p.x, p.y, 22, "#c47a3a", "dust", 80);
      sfx.ult();
      shake(w, 0.5);
      w.announce = "Investida imparável";
      w.announceT = 1.3;
    }
  }
}

function playerDamage(w: World, amt: number) {
  const p = w.player;
  if (p.iframe > 0 || w.phase === "dead" || p.unstoppable > 0) return;
  const st = statsOf(w);
  let dmg = amt * (100 / (100 + st.armor));
  if (w.wShield > 0) {
    const use = Math.min(w.wShield, dmg);
    w.wShield -= use;
    dmg -= use;
  }
  p.hp -= dmg;
  p.flash = 0.14;
  p.iframe = 0.38;
  p.passiveFlash = 0.45;
  if (p.hero === "morvak") {
    p.passiveN = Math.min(3, p.passiveN + 1);
    p.passiveT = 5;
    burst(w, p.x, p.y, 7, "#4d8a86", "ring", 90);
  }
  sfx.playerHurt();
  shake(w, 0.28);
  if (p.hp <= 0) {
    if (p.hero === "sion" && !p.zombieUsed) {
      p.zombieUsed = true;
      p.zombie = 10;
      p.hp = 420 + st.maxHp * 0.45;
      p.iframe = 0.85;
      p.sizeMul = 1.22;
      p.passiveN = 1;
      p.passiveFlash = 0.8;
      burst(w, p.x, p.y, 28, "#c47a3a", "ring", 50);
      floatText(w, p.x, p.y - 36, "GLÓRIA NA MORTE", "#c47a3a", true);
      w.announce = "Glória na morte";
      w.announceT = 2.2;
      sfx.ult();
      shake(w, 0.6);
      stop(w, 0.12);
      return;
    }
    p.hp = 0;
    w.phase = "dead";
    w.announce = "Você caiu";
    w.announceT = 3;
    sfx.death();
    burst(w, p.x, p.y, 30, "#b54a40", "blood", 200);
  }
}

function updateEnemies(w: World, dt: number) {
  const p = w.player;
  const alive = w.enemies.filter((e) => e.alive);
  for (const e of alive) {
    e.flash = Math.max(0, e.flash - dt);
    e.hop = Math.max(0, e.hop - dt);
    e.stunT = Math.max(0, e.stunT - dt);
    e.rootT = Math.max(0, e.rootT - dt);
    e.slowT = Math.max(0, e.slowT - dt);
    e.markT = Math.max(0, e.markT - dt);
    e.aaCd = Math.max(0, e.aaCd - dt);
    e.specialCd = Math.max(0, e.specialCd - dt);
    e.thrownT = Math.max(0, e.thrownT - dt);
    e.kx *= Math.exp(-8 * dt);
    e.ky *= Math.exp(-8 * dt);
    e.x += e.kx * dt;
    e.y += e.ky * dt;
    if (e.pullT > 0) {
      e.pullT -= dt;
      e.x += (e.pullX - e.x) * Math.min(1, dt * 8);
      e.y += (e.pullY - e.y) * Math.min(1, dt * 8);
    }
    if (e.locked) {
      for (const z of w.zones) {
        if (!z.alive || z.kind !== "realm" || z.data !== e.id) continue;
        const d = Math.hypot(e.x - z.x, e.y - z.y);
        if (d > z.r - e.radius) {
          const k = (z.r - e.radius) / (d || 1);
          e.x = z.x + (e.x - z.x) * k;
          e.y = z.y + (e.y - z.y) * k;
        }
      }
    }
    if (e.thrownT > 0) {
      e.x += Math.cos(e.thrownAng) * 520 * dt;
      e.y += Math.sin(e.thrownAng) * 520 * dt;
      e.hop = 0.2;
      for (const o of alive) {
        if (o.id === e.id || !o.alive) continue;
        if (Math.hypot(o.x - e.x, o.y - e.y) < o.radius + e.radius + 8) {
          hurtEnemy(w, o, e.thrownDmg, { knock: 18, ang: e.thrownAng });
          o.stunT = Math.max(o.stunT, 0.45);
        }
      }
      const cThrow = collideWorld(w, e.x, e.y, e.radius);
      e.x = cThrow.x;
      e.y = cThrow.y;
    }
    if (e.stunT > 0 || e.rootT > 0 || e.thrownT > 0) {
      e.vx = 0;
      e.vy = 0;
    } else {
      let tx = p.x - e.x;
      let ty = p.y - e.y;
      const d = Math.hypot(tx, ty) || 1;
      if (e.kind === "wraith" || e.kind === "cultist") {
        const keep = e.kind === "cultist" ? 240 : 260;
        if (d < keep) {
          tx = -tx;
          ty = -ty;
        }
        if (e.aaCd <= 0 && d < 460) {
          const kind = e.kind === "cultist" ? "hex" : "orb";
          const spd = e.kind === "cultist" ? 280 : 240;
          fireBullet(w, kind, e.x, e.y, Math.atan2(p.y - e.y, p.x - e.x), spd, e.ad, 8, 2.2, false);
          e.aaCd = e.kind === "cultist" ? 1.55 : 1.8;
        }
      }
      if (e.kind === "hound" && e.specialCd <= 0 && d < 260) {
        e.kx += (tx / d) * 460;
        e.ky += (ty / d) * 460;
        e.specialCd = 2.4;
        burst(w, e.x, e.y, 6, "#8a3232", "dust", 90);
      }
      if (e.kind === "golem" && e.specialCd <= 0 && d < 220) {
        addTele(w, "circle", e.x, e.y, 0, e.ad * 1.35, 0, 150, 0.7, "#7a6a52", "golemSlam", false, false);
        e.specialCd = 4.6;
      }
      if ((e.kind === "boss" || e.kind === "herald" || e.kind === "devourer" || e.kind === "lich") && e.specialCd <= 0) {
        if (e.kind === "boss") {
          addTele(w, "circle", p.x, p.y, 0, e.ad * 1.7, 0, 140, 0.85, "#b54a40", "bossSlam", false, false);
          e.specialCd = 4.0;
          sfx.ult();
        } else if (e.kind === "herald") {
          fireBullet(w, "bone", e.x, e.y, Math.atan2(p.y - e.y, p.x - e.x), 320, e.ad * 0.85, 9, 2.4, false);
          fireBullet(w, "bone", e.x, e.y, Math.atan2(p.y - e.y, p.x - e.x) + 0.28, 300, e.ad * 0.7, 8, 2.2, false);
          fireBullet(w, "bone", e.x, e.y, Math.atan2(p.y - e.y, p.x - e.x) - 0.28, 300, e.ad * 0.7, 8, 2.2, false);
          e.kx += (tx / d) * 300;
          e.ky += (ty / d) * 300;
          e.specialCd = 3.4;
          sfx.ult();
        } else if (e.kind === "devourer") {
          addTele(w, "circle", p.x, p.y, 0, e.ad * 2.0, 0, 155, 0.72, "#8a3232", "devourBite", false, false);
          e.kx += (tx / d) * 240;
          e.ky += (ty / d) * 240;
          e.specialCd = 3.8;
          sfx.ult();
        } else {
          for (let i = 0; i < 6; i++) {
            const a = (i / 6) * Math.PI * 2 + w.time;
            fireBullet(w, "hex", e.x, e.y, a, 210, e.ad * 0.7, 8, 2.8, false);
          }
          const na = Math.random() * Math.PI * 2;
          e.x = Math.cos(na) * 220;
          e.y = Math.sin(na) * 220;
          e.specialCd = 3.6;
          burst(w, e.x, e.y, 14, "#6ea8c9", "ring", 70);
          sfx.ult();
        }
      }
      if (e.kind === "elite" && e.specialCd <= 0 && d < 280) {
        e.kx += (tx / d) * 380;
        e.ky += (ty / d) * 380;
        e.specialCd = 3.2;
        burst(w, e.x, e.y, 8, "#b54a40", "dust", 80);
      }
      const spd = e.speed * (e.slowT > 0 ? 0.55 : 1);
      e.vx = (tx / d) * spd;
      e.vy = (ty / d) * spd;
      for (const o of alive) {
        if (o.id === e.id) continue;
        const dx = e.x - o.x;
        const dy = e.y - o.y;
        const dd = Math.hypot(dx, dy) || 0.001;
        const min = e.radius + o.radius - 2;
        if (dd < min) {
          e.vx += (dx / dd) * 150;
          e.vy += (dy / dd) * 150;
        }
      }
      e.x += e.vx * dt;
      e.y += e.vy * dt;
      const c = collideWorld(w, e.x, e.y, e.radius);
      e.x = c.x;
      e.y = c.y;
      if (e.kind !== "wraith" && e.kind !== "cultist" && e.kind !== "lich" && e.aaCd <= 0 && d < e.radius + w.player.radius + 6) {
        playerDamage(w, e.ad);
        e.aaCd = 1.05;
      }
    }
  }
}

function updateAim(w: World, a: Actions, st: StatsNow) {
  const p = w.player;
  const aimLen = Math.hypot(a.aimX, a.aimY);
  if (aimLen > 16) {
    p.aim = Math.atan2(a.aimY, a.aimX);
    p.aimX = p.x + a.aimX;
    p.aimY = p.y + a.aimY;
  } else {
    const n = preferredTarget(w, st.range * 2.6);
    if (n) {
      p.aim = Math.atan2(n.y - p.y, n.x - p.x);
      p.aimX = n.x;
      p.aimY = n.y;
    } else if (Math.hypot(a.moveX, a.moveY) > 0.18) {
      p.aim = Math.atan2(a.moveY, a.moveX);
      p.aimX = p.x + Math.cos(p.aim) * 160;
      p.aimY = p.y + Math.sin(p.aim) * 160;
    }
  }
  const turn = angNorm(p.aim - p.face);
  p.face += turn * (1 - Math.exp(-14 * dtSafe(w)));
  const hover = hoverTarget(w, 460);
  w.hoverId = hover ? hover.id : -1;
}

let _dt = FIXED_DT;
function dtSafe(_w: World) {
  return _dt;
}

function updatePlayer(w: World, dt: number, a: Actions) {
  _dt = dt;
  const p = w.player;
  const st = statsOf(w);
  p.radius = st.radius;
  p.aaCd = Math.max(0, p.aaCd - dt);
  p.slowT = Math.max(0, p.slowT - dt);
  p.ultT = Math.max(0, p.ultT - dt);
  p.iframe = Math.max(0, p.iframe - dt);
  p.flash = Math.max(0, p.flash - dt);
  p.hop = Math.max(0, p.hop - dt);
  p.qArmed = Math.max(0, p.qArmed - dt);
  p.markT = Math.max(0, p.markT - dt);
  p.lungeT = Math.max(0, p.lungeT - dt);
  p.comboT = Math.max(0, p.comboT - dt);
  p.wToggle = Math.max(0, p.wToggle - dt);
  p.rMarkT = Math.max(0, p.rMarkT - dt);
  p.pelletCd = Math.max(0, p.pelletCd - dt);
  p.passiveFlash = Math.max(0, p.passiveFlash - dt);
  p.unstoppable = Math.max(0, p.unstoppable - dt);
  if (p.hero === "sion") {
    if (w.preview === "q" && p.zombie <= 0 && w.skills.q.cd <= 0) {
      p.qCharge = clamp(p.qCharge + dt / 1.75, 0, 1);
      p.slowT = 0.2;
      p.vx = 0;
      p.vy = 0;
      p.hasDest = false;
      if (p.qCharge >= 1) {
        trySionQ(w);
      }
    } else if (w.preview !== "q" && p.qCharge > 0 && w.skills.q.cd <= 0) {
      // charge dropped without release this frame — keep until qUp
    }
    if (p.zombie > 0) {
      p.zombie -= dt;
      p.hp -= (420 + st.maxHp * 0.08) * dt / 10;
      p.sizeMul = 1.22;
      if (p.hp <= 0 || p.zombie <= 0) {
        p.hp = 0;
        p.zombie = 0;
        w.phase = "dead";
        w.announce = "A glória acaba";
        w.announceT = 3;
        sfx.death();
        burst(w, p.x, p.y, 30, "#c47a3a", "blood", 200);
      }
    } else if (p.unstoppable <= 0 && p.ultT <= 0) {
      p.sizeMul = 1;
    }
  }
  if (p.hero === "morvak") {
    p.passiveT = Math.max(0, p.passiveT - dt);
    if (p.passiveT <= 0) p.passiveN = 0;
  }
  if (p.hero === "volgar") {
    const moving = Math.hypot(p.vx, p.vy) > 80;
    if (moving) {
      p.passiveT -= dt;
      if (p.passiveT <= 0) {
        p.passiveN = Math.min(5, p.passiveN + 1);
        p.passiveT = 1.15;
        if (p.passiveN >= 5) {
          burst(w, p.x, p.y, 7, "#6ea8c9", "spark", 120);
          p.passiveFlash = 0.3;
        }
      }
    } else {
      p.passiveT = Math.max(0.2, p.passiveT);
    }
  }
  if (p.comboT <= 0) p.combo = 0;
  if (p.rMarkT <= 0) p.rMarkId = -1;
  w.qWindow = Math.max(0, w.qWindow - dt);
  if (w.qWindow <= 0 && w.qPhase > 0 && w.qPhase < 3) {
    cdSet(w.skills.q, 8 * (1 - st.cdr));
    w.qPhase = 0;
    w.skills.q.pips = 0;
    w.skills.q.recast = 0;
  }
  if (p.hero === "volgar" && p.ultT <= 0) p.sizeMul = 1;
  if (p.hero === "valkhar" && p.ultT <= 0) p.sizeMul = 1;
  if (w.wShieldT > 0) {
    w.wShieldT -= dt;
    if (w.wShieldT <= 0) w.wShield = 0;
  }
  if (p.hero === "sion" && p.zombie > 0) {
    /* decay is the only HP change while undead */
  } else {
    p.hp = clamp(p.hp + st.regen * dt, 0, st.maxHp);
  }

  updateAim(w, a, st);

  const chargingQ = p.hero === "sion" && p.qCharge > 0 && w.preview === "q" && p.zombie <= 0;

  if (p.dashT > 0) {
    p.dashT -= dt;
    if (p.hero === "sion" && p.unstoppable > 0) {
      const cur = Math.atan2(p.dashVy, p.dashVx);
      const turn = clamp(angNorm(p.aim - cur), -1.15 * dt, 1.15 * dt);
      const spd = 520;
      const na = cur + turn;
      p.dashVx = Math.cos(na) * spd;
      p.dashVy = Math.sin(na) * spd;
      p.face = na;
      p.aim = na;
      for (const e of w.enemies) {
        if (!e.alive) continue;
        if (Math.hypot(e.x - p.x, e.y - p.y) < e.radius + p.radius + 16) {
          if (e.dashHit !== p.rHitToken) {
            e.dashHit = p.rHitToken;
            hurtEnemy(w, e, skillDmg(st, 35, 1.15, 0.1), { knock: 36, ang: na });
            e.stunT = Math.max(e.stunT, 1.05);
            e.hop = 0.4;
          }
        }
      }
      if (p.dashT <= 0) {
        p.unstoppable = 0;
        p.iframe = 0.2;
        for (const e of w.enemies) {
          if (e.alive && inCirc(e.x, e.y, p.x, p.y, 180)) {
            hurtEnemy(w, e, skillDmg(st, 40, 1.35, 0.15), { knock: 40, ang: Math.atan2(e.y - p.y, e.x - p.x) });
            e.stunT = Math.max(e.stunT, 1.2);
          }
        }
        burst(w, p.x, p.y, 26, "#c47a3a", "ring", 70);
        shake(w, 0.55);
        stop(w, 0.08);
        sfx.slash();
      }
    }
    p.x += p.dashVx * dt;
    p.y += p.dashVy * dt;
    p.hasDest = false;
    if (p.hero === "valkhar") {
      for (const e of w.enemies) {
        if (!e.alive) continue;
        if (Math.hypot(e.x - p.x, e.y - p.y) < e.radius + p.radius + 10) {
          if (e.dashHit !== w.dashToken) {
            e.dashHit = w.dashToken;
            heal(w, (18 + st.ad * 0.12) * (p.ultT > 0 ? 2.2 : 1));
          }
        }
      }
    }
  } else if (!chargingQ) {
    const keyMove = Math.hypot(a.moveX, a.moveY) > 0.12;
    if (keyMove) {
      p.hasDest = false;
    } else if (a.clickMove) {
      const gp = collideWorld(w, a.worldX, a.worldY, p.radius);
      p.hasDest = true;
      p.destX = gp.x;
      p.destY = gp.y;
    }

    let mx = a.moveX;
    let my = a.moveY;
    if (!keyMove && p.hasDest) {
      const dx = p.destX - p.x;
      const dy = p.destY - p.y;
      const d = Math.hypot(dx, dy);
      if (d < 16) {
        p.hasDest = false;
        mx = 0;
        my = 0;
        p.vx *= 0.35;
        p.vy *= 0.35;
      } else {
        mx = dx / d;
        my = dy / d;
      }
    }

    const slow = p.slowT > 0 ? 0.78 : 1;
    const tx = mx * st.ms * slow;
    const ty = my * st.ms * slow;
    const k = 1 - Math.exp(-18 * dt);
    p.vx += (tx - p.vx) * k;
    p.vy += (ty - p.vy) * k;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    if (Math.hypot(mx, my) > 0.1) {
      p.lastMx = mx;
      p.lastMy = my;
    }
  }
  const spd = Math.hypot(p.vx, p.vy);
  if (spd > 24) {
    p.walkT += dt * (spd / 46);
    p.walkEmit += spd * dt;
    p.hop = 0.04 + Math.abs(Math.sin(p.walkT * 6.2)) * 0.08;
    if (p.walkEmit > 32) {
      p.walkEmit = 0;
      burst(w, p.x, p.y + 8, 1, "#5a4e42", "dust", 28);
    }
  } else {
    p.walkT += dt * 0.35;
    p.hop = Math.max(0, p.hop - dt * 0.4);
  }
  if (p.lungeT > 0) {
    p.x += Math.cos(p.aim) * 70 * dt;
    p.y += Math.sin(p.aim) * 70 * dt;
  }
  const attemptedX = p.x;
  const attemptedY = p.y;
  const c = collideWorld(w, p.x, p.y, p.radius);
  const pushX = c.x - attemptedX;
  const pushY = c.y - attemptedY;
  const plen = Math.hypot(pushX, pushY);
  if (plen > 0.001) {
    const nx = pushX / plen;
    const ny = pushY / plen;
    const vn = p.vx * nx + p.vy * ny;
    if (vn < 0) {
      p.vx -= vn * nx;
      p.vy -= vn * ny;
    }
  }
  p.x = c.x;
  p.y = c.y;

  for (const e of w.enemies) {
    if (!e.alive) continue;
    const dx = p.x - e.x;
    const dy = p.y - e.y;
    const dist = Math.hypot(dx, dy) || 0.001;
    const min = p.radius + e.radius * 0.72;
    if (dist < min) {
      const kSep = (min - dist) * 0.55;
      const sx = (dx / dist) * kSep;
      const sy = (dy / dist) * kSep;
      p.x += sx;
      p.y += sy;
      e.x -= sx * 0.4;
      e.y -= sy * 0.4;
    }
  }
  const c2 = collideWorld(w, p.x, p.y, p.radius);
  p.x = c2.x;
  p.y = c2.y;
  if (!Number.isFinite(p.x) || !Number.isFinite(p.y)) {
    p.x = 0;
    p.y = 0;
    p.vx = 0;
    p.vy = 0;
    p.hasDest = false;
  }

  if (p.hero === "urgot" && p.wToggle > 0) firePurge(w);

  if (p.hero === "volgar" && p.ultT > 0) {
    if (Math.floor(p.ultT * 2) !== Math.floor((p.ultT + dt) * 2) && p.ultT < 7.6) {
      for (const e of w.enemies) {
        if (e.alive && inCirc(e.x, e.y, p.x, p.y, 150 * p.sizeMul)) {
          hurtEnemy(w, e, skillDmg(st, 10, 0.5, 0.25), { knock: 6, ang: Math.atan2(e.y - p.y, e.x - p.x) });
        }
      }
      burst(w, p.x, p.y, 10, "#6ea8c9", "spark", 160);
    }
  }
}

function updateProjectiles(w: World, dt: number) {
  const st = statsOf(w);
  for (const b of w.bullets) {
    if (!b.alive) continue;
    b.ttl -= dt;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    if (b.ttl <= 0 || Math.hypot(b.x, b.y) > ARENA_R + 40) {
      b.alive = false;
      continue;
    }
    let hitPillar = false;
    for (const p of w.pillars) {
      if (inCirc(b.x, b.y, p.x, p.y, p.r)) hitPillar = true;
    }
    if (hitPillar) {
      b.alive = false;
      burst(w, b.x, b.y, 6, "#c4b08a", "dust", 70);
      continue;
    }
    if (b.friendly) {
      for (const e of w.enemies) {
        if (!e.alive) continue;
        if (!inCirc(b.x, b.y, e.x, e.y, e.radius + b.r)) continue;
        b.alive = false;
        if (b.kind === "chain") {
          addZone(w, "root", e.x, e.y, 92, 0.28, e.id);
          hurtEnemy(w, e, b.dmg, { knock: 6, ang: Math.atan2(b.vy, b.vx) });
        } else if (b.kind === "drill") {
          w.player.rMarkId = e.id;
          w.player.rMarkT = 4.2;
          hurtEnemy(w, e, b.dmg, { knock: 10, ang: Math.atan2(b.vy, b.vx) });
          burst(w, e.x, e.y, 12, "#8fa84a", "spark", 140);
        } else if (b.kind === "acid") {
          hurtEnemy(w, e, b.dmg, {});
        } else if (b.kind === "roar") {
          const small = e.kind === "ghoul" || e.kind === "hound" || e.kind === "skeleton" || e.kind === "wraith" || e.kind === "cultist";
          hurtEnemy(w, e, b.dmg, { knock: small ? 8 : 14, ang: Math.atan2(b.vy, b.vx) });
          e.slowT = Math.max(e.slowT, 2.1);
          if (small) {
            e.thrownT = 0.42;
            e.thrownAng = Math.atan2(b.vy, b.vx);
            e.thrownDmg = skillDmg(st, 18, 0.55, 0.4);
            e.stunT = Math.max(e.stunT, 0.35);
            burst(w, e.x, e.y, 10, "#c47a3a", "dust", 140);
          }
        } else {
          hurtEnemy(w, e, b.dmg || skillDmg(st, 8, 0.55, 0), { knock: 4, ang: Math.atan2(b.vy, b.vx) });
        }
        break;
      }
    } else if (w.player.iframe <= 0 && inCirc(b.x, b.y, w.player.x, w.player.y, w.player.radius + b.r)) {
      b.alive = false;
      playerDamage(w, b.dmg);
    }
  }
}

function updateZones(w: World, dt: number) {
  const st = statsOf(w);
  const p = w.player;
  for (const z of w.zones) {
    if (!z.alive) continue;
    z.t += dt;
    if (z.kind === "root" && z.t >= z.maxT) {
      for (const e of w.enemies) {
        if (e.alive && e.id === z.data && inCirc(e.x, e.y, z.x, z.y, z.r)) {
          e.rootT = Math.max(e.rootT, 1.55);
          hurtEnemy(w, e, skillDmg(st, 12, 0.45, 0.2), {});
          burst(w, e.x, e.y, 10, "#b54a40", "spark", 80);
        }
      }
      z.alive = false;
    }
    if (z.kind === "storm" && z.t >= z.maxT) {
      for (const e of w.enemies) {
        if (e.alive && inCirc(e.x, e.y, z.x, z.y, z.r)) {
          hurtEnemy(w, e, skillDmg(st, 20, 0.55, 0.95), { knock: 10, ang: Math.atan2(e.y - z.y, e.x - z.x) });
        }
      }
      if (inCirc(p.x, p.y, z.x, z.y, z.r)) {
        w.wShield = st.maxHp * 0.18;
        w.wShieldMax = w.wShield;
        w.wShieldT = 3;
        sfx.shield();
      }
      burst(w, z.x, z.y, 22, "#6ea8c9", "spark", 200);
      sfx.lightning();
      shake(w, 0.3);
      z.alive = false;
    }
    if (z.kind === "slam" && z.t >= z.maxT) {
      for (const e of w.enemies) {
        if (e.alive && inCirc(e.x, e.y, z.x, z.y, z.r)) {
          e.stunT = Math.max(e.stunT, 1.2);
          hurtEnemy(w, e, skillDmg(st, 24, 0.85, 0.55), { knock: 30, ang: Math.atan2(e.y - z.y, e.x - z.x) });
        }
      }
      burst(w, z.x, z.y, 24, "#6ea8c9", "ring", 70);
      shake(w, 0.5);
      stop(w, 0.08);
      z.alive = false;
    }
    if (z.kind === "realm" && z.t >= z.maxT) {
      for (const e of w.enemies) if (e.id === z.data) e.locked = false;
      w.realmId = -1;
      z.alive = false;
    }
    if (z.kind === "fear" && z.t >= z.maxT) z.alive = false;
  }
}

function updateFx(w: World, dt: number) {
  for (const p of w.particles) {
    if (!p.alive) continue;
    p.t += dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.92;
    p.vy *= 0.92;
    if (p.t >= p.maxT) p.alive = false;
  }
  for (const f of w.floaters) {
    if (!f.alive) continue;
    f.t += dt;
    f.y -= 28 * dt;
    if (f.t > 0.85) f.alive = false;
  }
  for (const d of w.decals) d.a = Math.max(0.12, d.a - dt * 0.015);
  w.trauma = Math.max(0, w.trauma - dt * 1.6);
  w.announceT = Math.max(0, w.announceT - dt);
}

function tickSkills(w: World, dt: number) {
  const p = w.player;
  for (const slot of ["q", "w", "e", "r"] as SkillSlot[]) {
    const s = w.skills[slot];
    s.cd = Math.max(0, s.cd - dt);
    s.recast = Math.max(0, s.recast - dt);
  }
  if (p.hero === "valkhar") {
    const s = w.skills.e;
    s.charges = p.eCharges;
    if (s.charges < s.maxCharges) {
      p.eRech += dt;
      const need = s.cd > 0 ? s.maxCd : 4;
      if (p.eRech >= need && s.cd <= 0) {
        p.eCharges = Math.min(2, p.eCharges + 1);
        s.charges = p.eCharges;
        p.eRech = 0;
      }
    }
    w.skills.q.pips = w.qPhase;
    w.skills.q.recast = w.qWindow;
    w.skills.e.pips = p.eCharges;
  }
  if (p.hero === "morvak") {
    w.skills.q.pips = p.stacks;
    w.skills.w.recast = w.wShieldT;
  }
  if (p.hero === "volgar") {
    w.skills.q.pips = p.qArmed > 0 ? 1 : 0;
    w.skills.w.recast = p.markT;
  }
  if (p.hero === "urgot") {
    w.skills.w.recast = p.wToggle;
    w.skills.w.pips = p.wToggle > 0 ? 1 : 0;
    w.skills.r.pips = p.rMarkT > 0 ? 1 : 0;
  }
  if (p.hero === "sion") {
    w.skills.q.pips = p.qCharge >= 0.85 ? 3 : p.qCharge >= 0.4 ? 2 : p.qCharge > 0 ? 1 : 0;
    w.skills.w.recast = w.wShieldT;
    w.skills.r.pips = p.unstoppable > 0 ? 1 : 0;
  }
}

function tickWave(w: World, dt: number) {
  if (w.phase === "combat") {
    for (const s of w.spawnQ) s.t -= dt;
    const ready = w.spawnQ.filter((s) => s.t <= 0);
    w.spawnQ = w.spawnQ.filter((s) => s.t > 0);
    for (const s of ready) {
      spawnEnemy(w, s.kind, s.ang);
    }
    const living = w.enemies.some((e) => e.alive);
    if (!living && w.spawnQ.length === 0) {
      w.phase = "between";
      w.betweenT = 16;
      const bonus = 50 + w.wave * 22;
      w.gold += bonus;
      w.announce = `Onda ${w.wave} limpa  ·  +${bonus} ouro`;
      w.announceT = 2.2;
      sfx.coin();
    }
  } else if (w.phase === "between") {
    w.betweenT -= dt;
    if (w.betweenT <= 0) planWave(w);
  }
}

export function buyUpgrade(w: World, id: UpgradeId): boolean {
  const def = UPGRADE_LIST.find((u) => u.id === id);
  if (!def) return false;
  const lv = w.upgrades[id];
  if (lv >= def.max) {
    sfx.deny();
    return false;
  }
  const cost = upgradeCost(def, lv);
  if (w.gold < cost) {
    sfx.deny();
    return false;
  }
  w.gold -= cost;
  w.upgrades[id] = lv + 1;
  if (id === "hp") heal(w, UPGRADE_POWER.hp);
  sfx.buy();
  return true;
}

export function skipBetween(w: World) {
  if (w.phase === "between") {
    w.betweenT = 0;
    planWave(w);
  }
}

export function hudOf(w: World): HudSnapshot {
  const st = statsOf(w);
  const hero = HEROES[w.player.hero];
  const skills: SkillHud[] = hero.skills.map((s) => {
    const stt = w.skills[s.slot];
    return {
      slot: s.slot,
      name: s.name,
      key: s.slot === "w" ? "F" : s.key,
      cd: stt.cd,
      maxCd: stt.maxCd,
      charges: stt.charges,
      maxCharges: stt.maxCharges,
      recast: stt.recast > 0,
      pips: stt.pips,
    };
  });
  const heroPassive = hero.passive;
  const passiveStacks =
    w.player.hero === "sion"
      ? w.player.zombie > 0
        ? 1
        : w.player.zombieUsed
          ? 0
          : 1
      : w.player.passiveN;
  return {
    phase: w.phase,
    hp: w.player.hp,
    maxHp: st.maxHp,
    shield: w.wShield,
    gold: w.gold,
    wave: Math.max(1, w.wave),
    kills: w.kills,
    betweenT: w.phase === "between" ? w.betweenT : 0,
    announce: w.announceT > 0 ? w.announce : "",
    skills,
    upgrades: { ...w.upgrades },
    heroId: w.player.hero,
    shopHint: w.phase === "between" && w.wave >= 1,
    preview: w.preview,
    passive: {
      name: heroPassive.name,
      desc: heroPassive.desc,
      stacks: passiveStacks,
      max: heroPassive.max,
      active:
        (w.player.hero === "valkhar" && passiveStacks >= heroPassive.max - 1) ||
        (w.player.hero === "volgar" && passiveStacks > 0) ||
        (w.player.hero === "morvak" && passiveStacks > 0) ||
        (w.player.hero === "urgot" && passiveStacks >= heroPassive.max - 1) ||
        (w.player.hero === "sion" && (w.player.zombie > 0 || w.player.bonusHp > 0)),
    },
    combo: w.player.combo,
    ad: st.ad,
    ap: st.ap,
  };
}

export function stepWorld(w: World, dt: number, a: Actions, just: Edges) {
  if (w.phase === "paused") return;
  const freezeCombat = w.hitstop > 0;
  if (w.hitstop > 0) w.hitstop -= dt;
  w.time += dt;
  if (w.phase === "dead") {
    updateFx(w, dt);
    return;
  }

  w.preview = a.q ? "q" : a.w ? "w" : a.e ? "e" : a.r ? "r" : null;
  if (just.qUp) cast(w, "q");
  if (just.wUp) cast(w, "w");
  if (just.eUp) cast(w, "e");
  if (just.rUp) cast(w, "r");
  if (just.skip) skipBetween(w);

  updatePlayer(w, dt, a);
  if (!freezeCombat) {
    if (w.phase === "combat" || w.phase === "between") autoAttack(w);
    for (const t of w.telegraphs) {
      if (!t.alive) continue;
      t.t += dt;
      if (t.follow) {
        t.x = w.player.x;
        t.y = w.player.y;
      }
      if (t.t >= t.maxT) {
        t.alive = false;
        resolveTele(w, t);
      }
    }
    updateProjectiles(w, dt);
    updateEnemies(w, dt);
    updateZones(w, dt);
    tickSkills(w, dt);
    tickWave(w, dt);
  }
  updateFx(w, dt);

  const k = 1 - Math.exp(-10 * dt);
  const lead = 48;
  const tx = w.player.x + Math.cos(w.player.aim) * lead;
  const ty = w.player.y + Math.sin(w.player.aim) * lead;
  w.camX += (tx - w.camX) * k;
  w.camY += (ty - w.camY) * k;
  if (!Number.isFinite(w.camX) || !Number.isFinite(w.camY)) {
    w.camX = w.player.x;
    w.camY = w.player.y;
  }
}

export function startFirstWave(_w: World) {
  void _w;
}
