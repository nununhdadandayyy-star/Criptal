import { sfx, setMuted, unlockAudio } from "./audio";
import { createInput, type InputHandle } from "./input";
import { renderWorld, makeFloorTile } from "./render";
import { loadSprites } from "./sprites";
import { buyUpgrade, createWorld, FIXED_DT, hudOf, skipBetween, stepWorld, type World } from "./world";
import type { HeroId, HudSnapshot, SkillSlot, UpgradeId } from "./types";

export type GameHandle = {
  destroy: () => void;
  buy: (id: UpgradeId) => boolean;
  skip: () => void;
  tap: (slot: SkillSlot | "skip" | "shop") => void;
  hold: (slot: SkillSlot | "skip" | "shop", down: boolean) => void;
  setMoveStick: (x: number, y: number, active: boolean) => void;
  setAimStick: (x: number, y: number, active: boolean) => void;
  setPaused: (v: boolean) => void;
  setShake: (v: boolean) => void;
  getWorld: () => World;
};

type MountOpts = {
  heroId: HeroId;
  muted: boolean;
  shake: boolean;
  onHud: (h: HudSnapshot) => void;
  onDeath: (wave: number, kills: number) => void;
  onShop: () => void;
  onPause: (v: boolean) => void;
};

export function mountGame(canvas: HTMLCanvasElement, opts: MountOpts): GameHandle {
  const rawCtx = canvas.getContext("2d");
  if (!rawCtx) throw new Error("Canvas 2D indisponível");
  const ctx: CanvasRenderingContext2D = rawCtx;

  unlockAudio();
  setMuted(opts.muted);

  const world = createWorld(opts.heroId);
  world.shakeOn = opts.shake;
  const input: InputHandle = createInput(canvas);
  const sprites = loadSprites();
  const floor = makeFloorTile();

  let raf = 0;
  let last = performance.now();
  let acc = 0;
  let deadSent = false;
  let uiPause = false;
  let hudClock = 0;
  let cssW = 1;
  let cssH = 1;
  let running = true;

  function resize() {
    const parent = canvas.parentElement ?? document.body;
    cssW = parent.clientWidth || window.innerWidth;
    cssH = parent.clientHeight || window.innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
    canvas.style.width = `${cssW}px`;
    canvas.style.height = `${cssH}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();
  window.addEventListener("resize", resize);
  canvas.tabIndex = 0;
  canvas.focus({ preventScroll: true });

  // Intro between-timer starts the first wave; do not skip it.

  function aimVec() {
    if (input.aimStick.active && (input.aimStick.x || input.aimStick.y)) {
      return { x: input.aimStick.x * 280, y: input.aimStick.y * 280 };
    }
    if (!input.mouse.moved) return { x: 0, y: 0 };
    const mx = world.camX + (input.mouse.x - cssW / 2);
    const my = world.camY + (input.mouse.y - cssH / 2);
    return { x: mx - world.player.x, y: my - world.player.y };
  }

  window.__controlsTest = {
    getYaw: () => {
      const p = world.player;
      const vx = p.dashT > 0 ? p.dashVx : p.vx;
      const vy = p.dashT > 0 ? p.dashVy : p.vy;
      if (Math.hypot(vx, vy) < 8) return Math.atan2(-p.lastMx, -p.lastMy);
      return Math.atan2(-vx, -vy);
    },
    getSpeed: () => {
      const p = world.player;
      const vx = p.dashT > 0 ? p.dashVx : p.vx;
      const vy = p.dashT > 0 ? p.dashVy : p.vy;
      return Math.hypot(vx, vy);
    },
    getX: () => world.player.x,
    getY: () => world.player.y,
    setKeys: (codes: string[]) => input.setKeys(codes),
  };

  function frame(now: number) {
    if (!running) return;
    const raw = Math.min((now - last) / 1000, 0.1);
    last = now;
    acc += raw;
    const aim = aimVec();
    while (acc >= FIXED_DT) {
      const actions = input.sample(aim);
      actions.worldX = world.camX + (input.mouse.x - cssW / 2);
      actions.worldY = world.camY + (input.mouse.y - cssH / 2);
      const aimingSkill = actions.q || actions.w || actions.e || actions.r;
      actions.clickMove = input.mouse.down && !aimingSkill && !uiPause;
      const just = input.edges(actions);
      if (just.pause) {
        uiPause = !uiPause;
        opts.onPause(uiPause);
      }
      if (just.shop) opts.onShop();
      if (!uiPause) {
        const prev = world.phase;
        stepWorld(world, FIXED_DT, actions, just);
        if (world.phase === "dead" && prev !== "dead" && !deadSent) {
          deadSent = true;
          opts.onDeath(world.wave, world.kills);
        }
      }
      acc -= FIXED_DT;
    }
    renderWorld(ctx, world, sprites, floor, cssW, cssH, world.shakeOn ? 1 : 0);
    hudClock += raw;
    if (hudClock > 0.08) {
      hudClock = 0;
      opts.onHud(hudOf(world));
    }
    raf = requestAnimationFrame(frame);
  }
  raf = requestAnimationFrame(frame);
  opts.onHud(hudOf(world));

  return {
    destroy() {
      running = false;
      cancelAnimationFrame(raf);
      input.destroy();
      window.removeEventListener("resize", resize);
      if (window.__controlsTest) delete window.__controlsTest;
    },
    buy(id) {
      unlockAudio();
      return buyUpgrade(world, id);
    },
    skip() {
      skipBetween(world);
    },
    tap(slot) {
      unlockAudio();
      input.hold(slot, true);
    },
    hold(slot, down) {
      unlockAudio();
      input.hold(slot, down);
    },
    setMoveStick(x, y, active) {
      input.setMoveStick(x, y, active);
    },
    setAimStick(x, y, active) {
      input.setAimStick(x, y, active);
    },
    setPaused(v) {
      uiPause = v;
    },
    setShake(v) {
      world.shakeOn = v;
    },
    getWorld: () => world,
  };
}

void sfx;
