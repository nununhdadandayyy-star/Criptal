import { create } from "zustand";
import { EMPTY_UPGRADES, HEROES } from "./heroes";
import { loadSave, writeSave } from "./save";
import type { HeroId, HudSnapshot, Phase, Screen, SkillHud, UpgradeId } from "./types";

const emptySkills = (hero: HeroId): SkillHud[] =>
  HEROES[hero].skills.map((s) => ({
    slot: s.slot,
    name: s.name,
    key: s.slot === "w" ? "F" : s.key,
    cd: 0,
    maxCd: 1,
    charges: 1,
    maxCharges: 1,
    recast: false,
    pips: 0,
  }));

const emptyHud = (hero: HeroId): HudSnapshot => ({
  phase: "combat",
  hp: HEROES[hero].base.hp,
  maxHp: HEROES[hero].base.hp,
  shield: 0,
  gold: 0,
  wave: 1,
  kills: 0,
  betweenT: 0,
  announce: "",
  skills: emptySkills(hero),
  upgrades: { ...EMPTY_UPGRADES },
  heroId: hero,
  shopHint: false,
  preview: null,
  passive: {
    name: HEROES[hero].passive.name,
    desc: HEROES[hero].passive.desc,
    stacks: 0,
    max: HEROES[hero].passive.max,
    active: false,
  },
  combo: 0,
  ad: HEROES[hero].base.ad,
  ap: 0,
});

type GameStore = {
  screen: Screen;
  heroId: HeroId;
  runId: number;
  hud: HudSnapshot;
  bestWave: number;
  bestKills: number;
  muted: boolean;
  shake: boolean;
  shopOpen: boolean;
  setScreen: (s: Screen) => void;
  setHero: (id: HeroId) => void;
  startRun: () => void;
  setHud: (h: HudSnapshot) => void;
  setShopOpen: (v: boolean) => void;
  recordRun: (wave: number, kills: number) => void;
  toggleMute: () => void;
  toggleShake: () => void;
};

export const useGameStore = create<GameStore>((set, get) => ({
  screen: "title",
  heroId: "valkhar",
  runId: 0,
  hud: emptyHud("valkhar"),
  bestWave: 0,
  bestKills: 0,
  muted: false,
  shake: true,
  shopOpen: false,
  setScreen: (screen) => set({ screen, shopOpen: false }),
  setHero: (heroId) => {
    writeSave({ lastHero: heroId });
    set({ heroId, hud: emptyHud(heroId) });
  },
  startRun: () => {
    const { heroId } = get();
    writeSave({ lastHero: heroId });
    set({
      screen: "play",
      runId: get().runId + 1,
      shopOpen: false,
      hud: emptyHud(heroId),
    });
  },
  setHud: (hud) => set({ hud }),
  setShopOpen: (shopOpen) => set({ shopOpen }),
  recordRun: (wave, kills) => {
    const bestWave = Math.max(get().bestWave, wave);
    const bestKills = Math.max(get().bestKills, kills);
    writeSave({ bestWave, bestKills });
    set({ bestWave, bestKills });
  },
  toggleMute: () => {
    const muted = !get().muted;
    writeSave({ muted });
    set({ muted });
  },
  toggleShake: () => {
    const shake = !get().shake;
    writeSave({ shake });
    set({ shake });
  },
}));

export function hydrateGameSave() {
  if (typeof window === "undefined") return;
  const saved = loadSave();
  useGameStore.setState({
    heroId: saved.lastHero,
    hud: emptyHud(saved.lastHero),
    bestWave: saved.bestWave,
    bestKills: saved.bestKills,
    muted: saved.muted,
    shake: saved.shake,
  });
}

export type { Phase, UpgradeId };
