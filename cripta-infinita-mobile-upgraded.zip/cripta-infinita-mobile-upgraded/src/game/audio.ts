type Bus = {
  ctx: AudioContext;
  master: GainNode;
  sfx: GainNode;
};

let bus: Bus | null = null;
let muted = false;

function ensure(): Bus | null {
  if (typeof window === "undefined") return null;
  if (bus) return bus;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  const ctx = new AC({ latencyHint: "interactive" });
  const master = ctx.createGain();
  const sfxG = ctx.createGain();
  sfxG.connect(master);
  master.connect(ctx.destination);
  master.gain.value = muted ? 0 : 0.7;
  sfxG.gain.value = 0.9;
  bus = { ctx, master, sfx: sfxG };
  return bus;
}

export function unlockAudio(): void {
  const b = ensure();
  if (!b) return;
  if (b.ctx.state === "suspended") void b.ctx.resume();
}

export function setMuted(v: boolean): void {
  muted = v;
  if (!bus) return;
  bus.master.gain.setTargetAtTime(v ? 0 : 0.7, bus.ctx.currentTime, 0.02);
}

function envGain(ctx: AudioContext, dest: AudioNode, start: number, peak: number, attack: number, decay: number): GainNode {
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(peak, start + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, start + attack + decay);
  g.connect(dest);
  return g;
}

function osc(type: OscillatorType, freq: number, dur: number, peak: number, slide?: number): void {
  const b = ensure();
  if (!b || muted) return;
  const t = b.ctx.currentTime;
  const o = b.ctx.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq * slide), t + dur);
  const g = envGain(b.ctx, b.sfx, t, peak, 0.008, dur);
  o.connect(g);
  o.start(t);
  o.stop(t + dur + 0.05);
}

function noise(dur: number, peak: number, hp = 400): void {
  const b = ensure();
  if (!b || muted) return;
  const t = b.ctx.currentTime;
  const n = b.ctx.createBuffer(1, Math.floor(b.ctx.sampleRate * dur), b.ctx.sampleRate);
  const data = n.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = b.ctx.createBufferSource();
  src.buffer = n;
  const filter = b.ctx.createBiquadFilter();
  filter.type = "highpass";
  filter.frequency.value = hp;
  const g = envGain(b.ctx, b.sfx, t, peak, 0.004, dur);
  src.connect(filter);
  filter.connect(g);
  src.start(t);
  src.stop(t + dur + 0.02);
}

export const sfx = {
  slash() {
    noise(0.09, 0.28, 900);
    osc("sawtooth", 220, 0.12, 0.12, 0.4);
  },
  hit() {
    osc("square", 140, 0.07, 0.14, 0.5);
    noise(0.05, 0.16, 200);
  },
  crit() {
    osc("sawtooth", 320, 0.12, 0.18, 0.7);
    osc("square", 180, 0.1, 0.1, 0.5);
  },
  dash() {
    noise(0.12, 0.2, 600);
    osc("triangle", 180, 0.14, 0.1, 1.8);
  },
  chain() {
    osc("triangle", 420, 0.16, 0.12, 0.4);
    noise(0.08, 0.12, 1200);
  },
  shield() {
    osc("sine", 280, 0.2, 0.14, 1.4);
  },
  ult() {
    osc("sawtooth", 90, 0.45, 0.22, 0.55);
    osc("sine", 55, 0.5, 0.18, 0.8);
    noise(0.25, 0.2, 180);
  },
  coin() {
    osc("sine", 880, 0.08, 0.09, 1.4);
    osc("sine", 1320, 0.07, 0.06, 1.1);
  },
  death() {
    osc("sine", 80, 0.6, 0.2, 0.4);
    noise(0.4, 0.18, 120);
  },
  wave() {
    osc("triangle", 240, 0.18, 0.1, 1.6);
  },
  buy() {
    osc("sine", 520, 0.08, 0.1);
    osc("sine", 780, 0.1, 0.08);
  },
  deny() {
    osc("square", 90, 0.08, 0.08);
  },
  lightning() {
    noise(0.12, 0.28, 1800);
    osc("square", 680, 0.08, 0.1, 0.3);
  },
  playerHurt() {
    osc("sawtooth", 110, 0.14, 0.16, 0.45);
  },
  shotgun() {
    noise(0.11, 0.32, 500);
    osc("square", 90, 0.08, 0.12, 0.45);
    osc("sawtooth", 210, 0.07, 0.08, 0.3);
  },
  execute() {
    osc("sawtooth", 70, 0.5, 0.24, 0.35);
    noise(0.3, 0.26, 140);
    osc("square", 160, 0.18, 0.12, 0.5);
  },
  acid() {
    noise(0.16, 0.2, 800);
    osc("triangle", 310, 0.2, 0.1, 0.5);
  },
};
