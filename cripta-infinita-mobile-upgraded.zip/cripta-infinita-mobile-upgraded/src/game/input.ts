export type Actions = {
  moveX: number;
  moveY: number;
  aimX: number;
  aimY: number;
  fire: boolean;
  q: boolean;
  w: boolean;
  e: boolean;
  r: boolean;
  shop: boolean;
  pause: boolean;
  skip: boolean;
  clickMove: boolean;
  worldX: number;
  worldY: number;
};

export type Edges = {
  q: boolean;
  w: boolean;
  e: boolean;
  r: boolean;
  shop: boolean;
  pause: boolean;
  skip: boolean;
  qUp: boolean;
  wUp: boolean;
  eUp: boolean;
  rUp: boolean;
};

const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "KeyQ",
  "KeyE",
  "KeyR",
  "KeyF",
  "KeyB",
  "ArrowUp",
  "ArrowLeft",
  "ArrowDown",
  "ArrowRight",
  "Space",
  "Escape",
  "Digit1",
  "Digit2",
  "Digit3",
  "Digit4",
]);

function radial(x: number, y: number, dz = 0.18): { x: number; y: number } {
  const m = Math.hypot(x, y);
  if (!Number.isFinite(m) || m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

export function createInput(canvas: HTMLCanvasElement) {
  const keys = new Set<string>();
  let injected: Set<string> | null = null;
  const mouse = { x: 0, y: 0, down: false, right: false, moved: false };
  const moveStick = { x: 0, y: 0, active: false };
  const aimStick = { x: 0, y: 0, active: false };
  const prev = {
    q: false,
    w: false,
    e: false,
    r: false,
    shop: false,
    pause: false,
    skip: false,
  };
  const hold: Record<"q" | "w" | "e" | "r", boolean> = { q: false, w: false, e: false, r: false };

  function onKeyDown(e: KeyboardEvent) {
    keys.add(e.code);
    if (GAME_CODES.has(e.code)) e.preventDefault();
  }
  function onKeyUp(e: KeyboardEvent) {
    keys.delete(e.code);
  }
  function clearKeys() {
    keys.clear();
    hold.q = hold.w = hold.e = hold.r = false;
    mouse.down = false;
    mouse.right = false;
  }
  function pointerPos(e: PointerEvent) {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
    mouse.moved = true;
  }
  function onCanvasPointerMove(e: PointerEvent) {
    pointerPos(e);
  }
  function onWindowPointerMove(e: PointerEvent) {
    if (e.pointerType !== "mouse") return;
    pointerPos(e);
  }
  function onPointerDown(e: PointerEvent) {
    if (e.button === 1) return;
    e.preventDefault();
    pointerPos(e);
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
    if (e.button === 2) mouse.right = true;
    else mouse.down = true;
    canvas.focus({ preventScroll: true });
  }
  function onPointerUp(e: PointerEvent) {
    if (e.button === 2) mouse.right = false;
    else mouse.down = false;
    try {
      if (canvas.hasPointerCapture?.(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  }
  function onContext(e: Event) {
    e.preventDefault();
  }

  function onVisibility() {
    if (document.hidden) clearKeys();
  }

  const keyOpts = { capture: true } as const;
  window.addEventListener("keydown", onKeyDown, keyOpts);
  window.addEventListener("keyup", onKeyUp, keyOpts);
  document.addEventListener("keydown", onKeyDown, keyOpts);
  document.addEventListener("keyup", onKeyUp, keyOpts);
  window.addEventListener("blur", clearKeys);
  document.addEventListener("visibilitychange", onVisibility);
  canvas.addEventListener("pointermove", onCanvasPointerMove);
  canvas.addEventListener("pointerdown", onPointerDown);
  window.addEventListener("pointermove", onWindowPointerMove);
  window.addEventListener("pointerup", onPointerUp);
  window.addEventListener("pointercancel", onPointerUp);
  canvas.addEventListener("contextmenu", onContext);
  canvas.tabIndex = 0;
  canvas.focus({ preventScroll: true });

  function held(): Set<string> {
    return injected ?? keys;
  }

  function pollGamepad(a: Actions) {
    const pads = navigator.getGamepads?.() ?? [];
    for (const p of pads) {
      if (!p) continue;
      const l = radial(p.axes[0] ?? 0, p.axes[1] ?? 0);
      const r = radial(p.axes[2] ?? 0, p.axes[3] ?? 0, 0.22);
      a.moveX += l.x;
      a.moveY += l.y;
      if (r.x || r.y) {
        a.aimX = r.x * 280;
        a.aimY = r.y * 280;
      }
      if (p.buttons[0]?.pressed) a.q = true;
      if (p.buttons[2]?.pressed) a.w = true;
      if (p.buttons[1]?.pressed) a.e = true;
      if (p.buttons[3]?.pressed) a.r = true;
      if (p.buttons[7]?.pressed || p.buttons[5]?.pressed) a.fire = true;
      if (p.buttons[9]?.pressed) a.pause = true;
      if (p.buttons[8]?.pressed) a.shop = true;
    }
  }

  function sample(aimFromMouse: { x: number; y: number } | null): Actions {
    const k = held();
    const a: Actions = {
      moveX: 0,
      moveY: 0,
      aimX: 0,
      aimY: 0,
      fire: mouse.down,
      q: k.has("KeyQ") || k.has("Digit1") || hold.q,
      w: k.has("KeyF") || k.has("Digit2") || mouse.right || hold.w,
      e: k.has("KeyE") || k.has("Digit3") || hold.e,
      r: k.has("KeyR") || k.has("Digit4") || hold.r,
      shop: k.has("KeyB"),
      pause: k.has("Escape"),
      skip: k.has("Space"),
      clickMove: false,
      worldX: 0,
      worldY: 0,
    };
    if (k.has("KeyA") || k.has("ArrowLeft")) a.moveX -= 1;
    if (k.has("KeyD") || k.has("ArrowRight")) a.moveX += 1;
    if (k.has("KeyW") || k.has("ArrowUp")) a.moveY -= 1;
    if (k.has("KeyS") || k.has("ArrowDown")) a.moveY += 1;
    a.moveX += moveStick.x;
    a.moveY += moveStick.y;
    const ml = Math.hypot(a.moveX, a.moveY);
    if (ml > 1) {
      a.moveX /= ml;
      a.moveY /= ml;
    }
    if (aimStick.active && (aimStick.x || aimStick.y)) {
      a.aimX = aimStick.x * 280;
      a.aimY = aimStick.y * 280;
    } else if (aimFromMouse) {
      a.aimX = aimFromMouse.x;
      a.aimY = aimFromMouse.y;
    }
    pollGamepad(a);
    const ml2 = Math.hypot(a.moveX, a.moveY);
    if (ml2 > 1) {
      a.moveX /= ml2;
      a.moveY /= ml2;
    }
    return a;
  }

  function edges(curr: Actions): Edges {
    const just: Edges = {
      q: curr.q && !prev.q,
      w: curr.w && !prev.w,
      e: curr.e && !prev.e,
      r: curr.r && !prev.r,
      shop: curr.shop && !prev.shop,
      pause: curr.pause && !prev.pause,
      skip: curr.skip && !prev.skip,
      qUp: !curr.q && prev.q,
      wUp: !curr.w && prev.w,
      eUp: !curr.e && prev.e,
      rUp: !curr.r && prev.r,
    };
    prev.q = curr.q;
    prev.w = curr.w;
    prev.e = curr.e;
    prev.r = curr.r;
    prev.shop = curr.shop;
    prev.pause = curr.pause;
    prev.skip = curr.skip;
    return just;
  }

  return {
    mouse,
    moveStick,
    aimStick,
    sample,
    edges,
    setKeys(codes: string[]) {
      injected = codes.length ? new Set(codes) : null;
    },
    setMoveStick(x: number, y: number, active: boolean) {
      moveStick.x = x;
      moveStick.y = y;
      moveStick.active = active;
    },
    setAimStick(x: number, y: number, active: boolean) {
      aimStick.x = x;
      aimStick.y = y;
      aimStick.active = active;
    },
    hold(slot: "q" | "w" | "e" | "r" | "skip" | "shop", down: boolean) {
      if (slot === "skip" || slot === "shop") {
        if (down) keys.add(slot === "skip" ? "Space" : "KeyB");
        else keys.delete(slot === "skip" ? "Space" : "KeyB");
        return;
      }
      hold[slot] = down;
    },
    tap(slot: "q" | "w" | "e" | "r" | "skip" | "shop") {
      this.hold(slot, true);
    },
    destroy() {
      window.removeEventListener("keydown", onKeyDown, keyOpts);
      window.removeEventListener("keyup", onKeyUp, keyOpts);
      document.removeEventListener("keydown", onKeyDown, keyOpts);
      document.removeEventListener("keyup", onKeyUp, keyOpts);
      window.removeEventListener("blur", clearKeys);
      document.removeEventListener("visibilitychange", onVisibility);
      canvas.removeEventListener("pointermove", onCanvasPointerMove);
      canvas.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onWindowPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
      canvas.removeEventListener("contextmenu", onContext);
    },
  };
}

export type InputHandle = ReturnType<typeof createInput>;
