import { HEROES } from "./heroes";
import type { HeroId } from "./types";

const KEY = "cripta-infinita-v2";
const VERSION = 2;

export type SaveData = {
  version: number;
  bestWave: number;
  bestKills: number;
  lastHero: HeroId;
  muted: boolean;
  shake: boolean;
};

const DEFAULTS: SaveData = {
  version: VERSION,
  bestWave: 0,
  bestKills: 0,
  lastHero: "valkhar",
  muted: false,
  shake: true,
};

function migrate(raw: Partial<SaveData> & { lastHero?: string }): SaveData {
  const lastHero = raw.lastHero && raw.lastHero in HEROES ? (raw.lastHero as HeroId) : DEFAULTS.lastHero;
  return { ...DEFAULTS, ...raw, lastHero, version: VERSION };
}

export function loadSave(): SaveData {
  if (typeof window === "undefined") return { ...DEFAULTS };
  try {
    const raw = window.localStorage.getItem(KEY) ?? window.localStorage.getItem("cripta-infinita-v1");
    if (!raw) return { ...DEFAULTS };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return migrate(parsed);
  } catch {
    return { ...DEFAULTS };
  }
}

export function writeSave(partial: Partial<SaveData>): SaveData {
  const next = { ...loadSave(), ...partial, version: VERSION };
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode / quota */
  }
  return next;
}
