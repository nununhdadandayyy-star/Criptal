import { ARENA_R, aimGhost, statsOf, type AimGhost, type World } from "./world";
import { dirFromAngle, drawSheet, type SpriteBank } from "./sprites";
import type { HeroId } from "./types";

function hash(x: number, y: number, s = 0) {
  const n = Math.sin(x * 127.1 + y * 311.7 + s * 74.7) * 43758.5453;
  return n - Math.floor(n);
}

export function makeFloorTile(): HTMLCanvasElement {
  const S = 512;
  const c = document.createElement("canvas");
  c.width = c.height = S;
  const g = c.getContext("2d")!;
  g.fillStyle = "#120f0c";
  g.fillRect(0, 0, S, S);
  const cells = 5;
  const cell = S / cells;
  for (let y = 0; y < cells; y++) {
    for (let x = 0; x < cells; x++) {
      const n = hash(x, y);
      const n2 = hash(x, y, 3);
      const inset = 2 + n * 6;
      const shade = 22 + n * 16;
      g.fillStyle = `rgb(${shade + 14},${shade + 6},${shade - 1})`;
      const rx = x * cell + inset;
      const ry = y * cell + inset;
      const rw = cell - inset * 2;
      const rh = cell - inset * 2;
      g.beginPath();
      g.roundRect(rx, ry, rw, rh, 5);
      g.fill();
      g.strokeStyle = `rgba(70,55,42,${0.18 + n * 0.16})`;
      g.lineWidth = 1.4;
      g.stroke();
      if (n2 > 0.62) {
        g.strokeStyle = `rgba(90,48,36,${0.12 + n2 * 0.14})`;
        g.beginPath();
        g.moveTo(rx + 8, ry + rh * 0.3);
        g.lineTo(rx + rw * 0.7, ry + rh * 0.72);
        g.stroke();
      }
      if (n > 0.82) {
        g.fillStyle = `rgba(60,90,70,${0.05 + n * 0.05})`;
        g.beginPath();
        g.ellipse(rx + rw * 0.4, ry + rh * 0.55, 10, 6, n, 0, Math.PI * 2);
        g.fill();
      }
    }
  }
  g.fillStyle = "rgba(0,0,0,0.22)";
  g.fillRect(0, 0, S, S);
  return c;
}

function sil(ctx: CanvasRenderingContext2D, hero: HeroId, x: number, y: number, size: number, ang: number, flash: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang + Math.PI / 2);
  const s = size / 52;
  ctx.scale(s, s);
  ctx.translate(0, 4);
  if (hero === "valkhar") {
    ctx.fillStyle = flash ? "#f0e6dc" : "#1a1210";
    ctx.beginPath();
    ctx.ellipse(0, 0, 11, 16, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = flash ? "#fff" : "#6a1d18";
    ctx.beginPath();
    ctx.moveTo(-6, -18);
    ctx.lineTo(0, -28);
    ctx.lineTo(8, -10);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#b54a40";
    ctx.fillRect(-3, -22, 6, 36);
  } else if (hero === "morvak") {
    ctx.fillStyle = flash ? "#dce8e6" : "#2a2c2c";
    ctx.beginPath();
    ctx.roundRect(-14, -16, 28, 34, 4);
    ctx.fill();
    ctx.fillStyle = "#4d8a86";
    ctx.fillRect(-6, -10, 12, 5);
    ctx.fillStyle = "#6d6a66";
    ctx.beginPath();
    ctx.arc(16, 4, 8, 0, Math.PI * 2);
    ctx.fill();
  } else if (hero === "urgot") {
    ctx.fillStyle = flash ? "#e8ecd4" : "#3a3830";
    ctx.beginPath();
    ctx.ellipse(0, 6, 18, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = flash ? "#fff" : "#c8c2b4";
    ctx.beginPath();
    ctx.ellipse(0, -8, 9, 11, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#8fa84a";
    ctx.fillRect(-10, 4, 6, 14);
    ctx.fillRect(4, 4, 6, 14);
    ctx.fillRect(-3, 10, 6, 12);
    ctx.fillStyle = "#c4a574";
    ctx.fillRect(-5, -4, 10, 3);
  } else if (hero === "sion") {
    ctx.fillStyle = flash ? "#f0e4d4" : "#4a4a42";
    ctx.beginPath();
    ctx.ellipse(0, 4, 16, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = flash ? "#fff" : "#c47a3a";
    ctx.beginPath();
    ctx.ellipse(0, -10, 10, 9, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#8a3232";
    ctx.fillRect(-4, -6, 8, 18);
    ctx.fillStyle = "#d8c4a0";
    ctx.fillRect(10, -8, 5, 22);
  } else {
    ctx.fillStyle = flash ? "#eef4f8" : "#d8d4cc";
    ctx.beginPath();
    ctx.ellipse(0, 4, 16, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#6ea8c9";
    ctx.beginPath();
    ctx.arc(-5, -6, 3, 0, Math.PI * 2);
    ctx.arc(5, -6, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function enemySil(ctx: CanvasRenderingContext2D, kind: string, x: number, y: number, r: number, ang: number, flash: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(ang);
  const col =
    kind === "ghoul"
      ? "#6e7a5a"
      : kind === "skeleton"
        ? "#c4b08a"
        : kind === "brute"
          ? "#5a3a42"
          : kind === "wraith"
            ? "#7a93a4"
            : kind === "cultist"
              ? "#6a4a78"
              : kind === "hound"
                ? "#8a5a48"
                : kind === "golem"
                  ? "#6a6858"
                  : kind === "herald"
                    ? "#c4b08a"
                    : kind === "devourer"
                      ? "#6a2428"
                      : kind === "lich"
                        ? "#4a8a86"
                        : kind === "elite"
                          ? "#8a3232"
                          : "#9a9388";
  ctx.fillStyle = flash ? "#f4efe6" : col;
  ctx.beginPath();
  ctx.ellipse(0, 0, r, r * 1.15, 0, 0, Math.PI * 2);
  ctx.fill();
  if (kind === "boss" || kind === "herald" || kind === "devourer" || kind === "lich") {
    ctx.strokeStyle = "#b54a40";
    ctx.lineWidth = 3;
    ctx.stroke();
  }
  ctx.restore();
}

function strokeShape(ctx: CanvasRenderingContext2D, g: AimGhost, fillA: number, strokeA: number, dashed: boolean) {
  ctx.save();
  ctx.translate(g.x, g.y);
  if (g.shape !== "circle" && g.shape !== "self" && g.shape !== "unit") ctx.rotate(g.ang);
  ctx.fillStyle = g.color;
  ctx.strokeStyle = g.color;
  ctx.lineWidth = 2.2;
  if (dashed) ctx.setLineDash([7, 5]);
  if (g.shape === "line" || g.shape === "bar" || g.shape === "dash") {
    ctx.globalAlpha = fillA;
    ctx.beginPath();
    ctx.roundRect(0, -g.wid / 2, g.len, g.wid, 6);
    ctx.fill();
    ctx.globalAlpha = strokeA;
    ctx.stroke();
    if (g.sweet && g.shape === "line") {
      ctx.globalAlpha = fillA + 0.12;
      ctx.fillRect(g.len * 0.62, -g.wid / 2, g.len * 0.38, g.wid);
    }
  } else if (g.shape === "cone") {
    ctx.globalAlpha = fillA;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.arc(0, 0, g.len, -g.wid, g.wid);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = strokeA;
    ctx.stroke();
  } else {
    const rr = g.r || 36;
    ctx.globalAlpha = fillA;
    ctx.beginPath();
    ctx.arc(0, 0, rr, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = strokeA;
    ctx.stroke();
  }
  ctx.restore();
}

function drawTele(ctx: CanvasRenderingContext2D, w: World) {
  for (const t of w.telegraphs) {
    if (!t.alive) continue;
    const k = t.t / t.maxT;
    const ghost: AimGhost = {
      shape: t.shape,
      x: t.x,
      y: t.y,
      ang: t.ang,
      len: t.len,
      wid: t.wid,
      r: t.r,
      color: t.color,
      sweet: t.sweet,
      targetId: -1,
    };
    strokeShape(ctx, ghost, 0.16 + 0.22 * k, 0.55 + 0.35 * k, false);
    ctx.save();
    ctx.strokeStyle = t.color;
    ctx.globalAlpha = 0.85;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(t.x, t.y, 10, -Math.PI / 2, -Math.PI / 2 + k * Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

function drawGhost(ctx: CanvasRenderingContext2D, w: World) {
  const g = aimGhost(w);
  if (!g) return;
  strokeShape(ctx, g, 0.12, 0.72, true);
  if (g.shape === "circle" || g.shape === "unit") {
    ctx.save();
    ctx.strokeStyle = g.color;
    ctx.globalAlpha = 0.28;
    ctx.setLineDash([6, 8]);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(w.player.x, w.player.y);
    ctx.lineTo(g.x, g.y);
    ctx.stroke();
    ctx.restore();
  }
}

function drawCursor(ctx: CanvasRenderingContext2D, w: World) {
  const p = w.player;
  const st = statsOf(w);
  ctx.save();
  ctx.strokeStyle = "rgba(235,230,220,0.22)";
  ctx.lineWidth = 1.5;
  ctx.setLineDash([4, 6]);
  ctx.beginPath();
  ctx.arc(p.x, p.y, st.range, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.strokeStyle = "rgba(235,230,220,0.55)";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(p.aimX - 8, p.aimY);
  ctx.lineTo(p.aimX + 8, p.aimY);
  ctx.moveTo(p.aimX, p.aimY - 8);
  ctx.lineTo(p.aimX, p.aimY + 8);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(p.aimX, p.aimY, 11, 0, Math.PI * 2);
  ctx.stroke();
  ctx.globalAlpha = 0.35;
  ctx.beginPath();
  ctx.moveTo(p.x, p.y);
  ctx.lineTo(p.aimX, p.aimY);
  ctx.stroke();
  ctx.restore();

  if (p.hasDest) {
    const pulse = 0.55 + Math.sin(w.time * 8) * 0.25;
    ctx.save();
    ctx.strokeStyle = `rgba(232,215,176,${0.45 + pulse * 0.4})`;
    ctx.fillStyle = `rgba(232,215,176,${0.08 + pulse * 0.08})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(p.destX, p.destY, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(p.destX, p.destY - 18);
    ctx.lineTo(p.destX + 5, p.destY - 8);
    ctx.lineTo(p.destX - 5, p.destY - 8);
    ctx.closePath();
    ctx.fillStyle = `rgba(232,215,176,${0.7})`;
    ctx.fill();
    ctx.restore();
  }

  if (w.hoverId >= 0) {
    const e = w.enemies.find((n) => n.alive && n.id === w.hoverId);
    if (e) {
      ctx.save();
      ctx.strokeStyle = "rgba(232,215,176,0.85)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius * 1.85, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }
}

function hpBar(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, hp: number, max: number, elite: boolean) {
  const h = elite ? 5 : 4;
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  ctx.fillRect(x - w / 2, y, w, h);
  ctx.fillStyle = elite ? "#b54a40" : "#7d3d38";
  ctx.fillRect(x - w / 2, y, w * Math.max(0, hp / max), h);
}

function drawHeroAura(ctx: CanvasRenderingContext2D, w: World) {
  const p = w.player;
  const st = statsOf(w);
  const color =
    p.hero === "valkhar"
      ? "#b54a40"
      : p.hero === "morvak"
        ? "#4d8a86"
        : p.hero === "volgar"
          ? "#6ea8c9"
          : p.hero === "sion"
            ? "#c47a3a"
            : "#8fa84a";
  const pulse = 0.72 + Math.sin(w.time * 5.5) * 0.12;
  const radius = p.radius * (p.sizeMul > 1.1 ? 2.2 : 1.7);

  ctx.save();
  const grd = ctx.createRadialGradient(p.x, p.y, p.radius * 0.25, p.x, p.y, radius * 1.8);
  grd.addColorStop(0, `${color}22`);
  grd.addColorStop(0.58, `${color}0b`);
  grd.addColorStop(1, `${color}00`);
  ctx.fillStyle = grd;
  ctx.beginPath();
  ctx.arc(p.x, p.y, radius * 1.8, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = `${color}${Math.round((p.passiveFlash > 0 ? 0.8 : 0.28) * 255).toString(16).padStart(2, "0")}`;
  ctx.lineWidth = p.passiveFlash > 0 ? 3 : 1.5;
  ctx.beginPath();
  ctx.arc(p.x, p.y, radius + Math.sin(w.time * 4) * 2, 0, Math.PI * 2);
  ctx.stroke();

  if (p.hero === "volgar" && p.passiveN > 0) {
    for (let i = 0; i < p.passiveN; i++) {
      const a = w.time * 2.2 + i * (Math.PI * 2 / 5);
      const x = p.x + Math.cos(a) * (radius + 6);
      const y = p.y + Math.sin(a) * (radius + 6);
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.55 + 0.35 * pulse;
      ctx.beginPath();
      ctx.arc(x, y, 3.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  if (p.hero === "morvak" && p.passiveN > 0) {
    ctx.globalAlpha = 0.35;
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(p.x, p.y, radius + 10, -Math.PI / 2, -Math.PI / 2 + (Math.PI * 2 * p.passiveN) / 3);
    ctx.stroke();
  }
  if (p.hero === "valkhar" && p.passiveN > 0) {
    ctx.globalAlpha = 0.75;
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(p.x, p.y, radius + 7, -Math.PI / 2, -Math.PI / 2 + (Math.PI * 2 * p.passiveN) / 3);
    ctx.stroke();
  }
  if (p.hero === "urgot" && p.passiveN > 0) {
    ctx.globalAlpha = 0.72;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(p.x, p.y, radius + 8, -Math.PI / 2, -Math.PI / 2 + (Math.PI * 2 * p.passiveN) / 3);
    ctx.stroke();
  }
  if (p.hero === "scar") {
    ctx.globalAlpha = 0.7;
    ctx.strokeStyle = "#e14b43";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(p.x, p.y, radius + 9 + Math.sin(w.time * 7) * 2, 0, Math.PI * 2);
    ctx.stroke();
    if (p.passiveN > 0) {
      for (let i = 0; i < p.passiveN; i++) {
        const a = w.time * 2.4 + i * 2.1;
        ctx.fillStyle = "#e14b43";
        ctx.beginPath(); ctx.arc(p.x + Math.cos(a) * (radius + 10), p.y + Math.sin(a) * (radius + 10), 4, 0, Math.PI * 2); ctx.fill();
      }
    }
  }
  if (p.hero === "sion") {
    if (p.qCharge > 0) {
      ctx.globalAlpha = 0.55 + p.qCharge * 0.4;
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius + 12, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p.qCharge);
      ctx.stroke();
    }
    if (p.zombie > 0) {
      ctx.globalAlpha = 0.35;
      ctx.strokeStyle = "#8a3232";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius + 16 + Math.sin(w.time * 8) * 3, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
  ctx.restore();
  void st;
}

export function renderWorld(
  ctx: CanvasRenderingContext2D,
  w: World,
  sprites: SpriteBank,
  floor: HTMLCanvasElement,
  cssW: number,
  cssH: number,
  shakeMul: number,
) {
  const shake = w.trauma * w.trauma * 18 * shakeMul;
  const ox = (Math.random() - 0.5) * shake;
  const oy = (Math.random() - 0.5) * shake;
  const camX = w.camX + ox;
  const camY = w.camY + oy;
  const dpr = Math.min(typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1, 2);

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);
  ctx.fillStyle = "#070605";
  ctx.fillRect(0, 0, cssW, cssH);

  ctx.save();
  ctx.translate(cssW / 2 - camX, cssH / 2 - camY);

  const pat = ctx.createPattern(floor, "repeat");
  if (pat) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(0, 0, ARENA_R, 0, Math.PI * 2);
    ctx.clip();
    ctx.fillStyle = pat;
    ctx.fillRect(-ARENA_R, -ARENA_R, ARENA_R * 2, ARENA_R * 2);
    ctx.restore();
  }

  ctx.save();
  ctx.beginPath();
  ctx.arc(0, 0, ARENA_R, 0, Math.PI * 2);
  ctx.clip();

  ctx.strokeStyle = "rgba(196,176,138,0.14)";
  ctx.lineWidth = 2;
  for (const rr of [180, 340, 520, 660]) {
    ctx.beginPath();
    ctx.arc(0, 0, rr, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.strokeStyle = "rgba(181,74,64,0.22)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(0, 0, 128, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = "rgba(181,74,64,0.12)";
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.arc(0, 0, 128, 0, Math.PI * 2);
  ctx.stroke();

  ctx.save();
  ctx.rotate(w.time * 0.015);
  ctx.strokeStyle = "rgba(196,176,138,0.16)";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    ctx.moveTo(Math.cos(a) * 40, Math.sin(a) * 40);
    ctx.lineTo(Math.cos(a) * 118, Math.sin(a) * 118);
  }
  ctx.stroke();
  ctx.restore();

  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + 0.12;
    const gx = Math.cos(a) * (ARENA_R - 18);
    const gy = Math.sin(a) * (ARENA_R - 18);
    ctx.save();
    ctx.translate(gx, gy);
    ctx.rotate(a + Math.PI / 2);
    ctx.fillStyle = "#1a1612";
    ctx.fillRect(-28, -18, 56, 36);
    ctx.fillStyle = "#2c2620";
    ctx.fillRect(-22, -28, 14, 48);
    ctx.fillRect(8, -28, 14, 48);
    ctx.fillStyle = "#3a322c";
    ctx.fillRect(-28, -32, 56, 8);
    ctx.restore();
  }

  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const bx = Math.cos(a) * (ARENA_R - 48);
    const by = Math.sin(a) * (ARENA_R - 48);
    const flicker = 0.55 + Math.sin(w.time * 9 + i * 1.7) * 0.45;
    ctx.save();
    ctx.translate(bx, by);
    ctx.fillStyle = "#1c1814";
    ctx.beginPath();
    ctx.ellipse(0, 10, 9, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#2a2420";
    ctx.fillRect(-5, -4, 10, 12);
    const grd = ctx.createRadialGradient(0, -8, 1, 0, -10, 22);
    grd.addColorStop(0, `rgba(255,180,90,${0.55 * flicker})`);
    grd.addColorStop(0.45, `rgba(181,74,64,${0.35 * flicker})`);
    grd.addColorStop(1, "rgba(181,74,64,0)");
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(0, -10, 22, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = `rgba(255,200,110,${0.7 * flicker})`;
    ctx.beginPath();
    ctx.moveTo(-3, 0);
    ctx.lineTo(0, -16 - flicker * 6);
    ctx.lineTo(3, 0);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  ctx.strokeStyle = "#1a1613";
  ctx.lineWidth = 48;
  ctx.beginPath();
  ctx.arc(0, 0, ARENA_R + 10, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = "#2e2823";
  ctx.lineWidth = 18;
  ctx.beginPath();
  ctx.arc(0, 0, ARENA_R, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = "#4a433c";
  ctx.lineWidth = 4;
  ctx.stroke();
  ctx.strokeStyle = "rgba(196,176,138,0.28)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, ARENA_R - 14, 0, Math.PI * 2);
  ctx.stroke();

  for (const p of w.pillars) {
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.beginPath();
    ctx.ellipse(p.x, p.y + 14, p.r * 1.05, p.r * 0.42, 0, 0, Math.PI * 2);
    ctx.fill();
    const grd = ctx.createLinearGradient(p.x, p.y - p.r * 1.6, p.x, p.y + p.r);
    grd.addColorStop(0, "#4a433c");
    grd.addColorStop(0.35, "#2e2924");
    grd.addColorStop(1, "#161310");
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.roundRect(p.x - p.r * 0.52, p.y - p.r * 1.55, p.r * 1.04, p.r * 2.45, 7);
    ctx.fill();
    ctx.fillStyle = "#3a3530";
    ctx.beginPath();
    ctx.roundRect(p.x - p.r * 0.68, p.y - p.r * 1.72, p.r * 1.36, p.r * 0.38, 4);
    ctx.fill();
    ctx.strokeStyle = "#5a5248";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.strokeStyle = "rgba(196,176,138,0.18)";
    ctx.beginPath();
    ctx.moveTo(p.x - 6, p.y - p.r);
    ctx.lineTo(p.x + 4, p.y + p.r * 0.4);
    ctx.stroke();
  }

  for (const d of w.decals) {
    ctx.globalAlpha = d.a;
    ctx.fillStyle = d.color;
    ctx.beginPath();
    ctx.ellipse(d.x, d.y, d.r, d.r * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  for (const z of w.zones) {
    if (!z.alive) continue;
    ctx.save();
    if (z.kind === "realm") {
      ctx.fillStyle = "rgba(40, 70, 72, 0.28)";
      ctx.strokeStyle = "rgba(77, 138, 134, 0.7)";
    } else if (z.kind === "storm") {
      ctx.fillStyle = "rgba(80, 130, 160, 0.16)";
      ctx.strokeStyle = "rgba(110, 168, 201, 0.8)";
    } else if (z.kind === "root") {
      ctx.fillStyle = "rgba(140, 40, 36, 0.16)";
      ctx.strokeStyle = "rgba(181, 74, 64, 0.7)";
    } else {
      ctx.fillStyle = "rgba(180, 70, 60, 0.12)";
      ctx.strokeStyle = "rgba(181, 74, 64, 0.5)";
    }
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(z.x, z.y, z.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  drawCursor(ctx, w);
  drawGhost(ctx, w);
  drawTele(ctx, w);

  const p = w.player;
  drawHeroAura(ctx, w);
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.beginPath();
  ctx.ellipse(p.x, p.y + p.radius * 0.7, p.radius * 0.9, p.radius * 0.35, 0, 0, Math.PI * 2);
  ctx.fill();

  const walk = Math.hypot(p.vx, p.vy) > 20 || p.dashT > 0;
  const frame = walk ? Math.floor(p.walkT * 4) % 4 : Math.floor(p.walkT * 0.6) % 2;
  const row = dirFromAngle(p.face);
  const size = (p.hero === "volgar" ? 86 : p.hero === "urgot" ? 88 : p.hero === "sion" ? 92 : p.hero === "scar" ? 94 : 80) * p.sizeMul;
  const py = p.y - p.hop * 18;
  const sheet = sprites[p.hero];
  const drawn = drawSheet(ctx, sheet, frame, row, p.x, py, size, p.flash);
  if (!drawn) sil(ctx, p.hero, p.x, py, size, p.face, p.flash);

  if (w.wShield > 0) {
    ctx.strokeStyle =
      p.hero === "urgot" ? "rgba(143,168,74,0.7)" : p.hero === "sion" ? "rgba(196,122,58,0.75)" : "rgba(77,138,134,0.7)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.radius * 2.1, 0, Math.PI * 2);
    ctx.stroke();
  }

  for (const e of w.enemies) {
    if (!e.alive) continue;
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath();
    ctx.ellipse(e.x, e.y + e.radius * 0.6, e.radius * 0.85, e.radius * 0.32, 0, 0, Math.PI * 2);
    ctx.fill();
    const isBoss = e.kind === "boss" || e.kind === "herald" || e.kind === "devourer" || e.kind === "lich";
    if (isBoss) {
      const pulse = 0.45 + Math.sin(w.time * 4 + e.id) * 0.18;
      ctx.save();
      ctx.globalAlpha = pulse;
      ctx.strokeStyle = e.kind === "lich" ? "#6ea8c9" : "#e14b43";
      ctx.lineWidth = 3;
      ctx.setLineDash([10, 7]);
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius * (2.1 + Math.sin(w.time * 3) * 0.08), 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
    const ang = Math.atan2(p.y - e.y, p.x - e.x);
    const erow = dirFromAngle(ang);
    const eframe = Math.floor(w.time * (e.kind === "brute" || e.kind === "golem" || e.kind === "devourer" ? 4 : 7) + e.id) % 4;
    const esize = e.radius * 3.4;
    const ey = e.y - e.hop * 16;
    let ok = false;
    if (e.kind === "ghoul" || e.kind === "skeleton") {
      ok = drawSheet(ctx, sprites[e.kind], eframe, erow, e.x, ey, esize, e.flash);
    } else if (e.kind === "brute" || e.kind === "elite" || e.kind === "boss") {
      const col = eframe % 2;
      const rw = Math.floor(eframe / 2);
      ok = drawSheet(ctx, sprites.brute, col, rw, e.x, ey, esize * (e.kind === "boss" ? 1.35 : 1), e.flash);
    } else if (e.kind === "cultist" || e.kind === "hound" || e.kind === "golem" || e.kind === "herald" || e.kind === "devourer" || e.kind === "lich") {
      const col = eframe % 2;
      const rw = Math.floor(eframe / 2);
      const scale = e.kind === "devourer" ? 1.4 : e.kind === "herald" || e.kind === "lich" ? 1.3 : e.kind === "golem" ? 1.2 : 1;
      ok = drawSheet(ctx, sprites[e.kind], col, rw, e.x, ey, esize * scale, e.flash);
    } else {
      const col = eframe % 2;
      const rw = Math.floor(eframe / 2);
      ok = drawSheet(ctx, sprites.wraith, col, rw, e.x, ey, esize, e.flash);
    }
    if (!ok) enemySil(ctx, e.kind, e.x, ey, e.radius, ang, e.flash);
    if (e.markT > 0) {
      ctx.strokeStyle = "#6ea8c9";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius * 1.6, 0, Math.PI * 2);
      ctx.stroke();
    }
    if (p.hero === "urgot" && e.id === p.rMarkId) {
      ctx.strokeStyle = "#8fa84a";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.radius * 2.05, 0, Math.PI * 2);
      ctx.stroke();
    }
    if (isBoss) {
      ctx.save();
      ctx.textAlign = "center";
      ctx.font = "700 11px 'Source Sans 3', sans-serif";
      ctx.fillStyle = "rgba(235,230,220,0.92)";
      const bossName = e.kind === "herald" ? "ARAUTO" : e.kind === "devourer" ? "DEVORADOR" : e.kind === "lich" ? "LICH" : "COLOSSO";
      ctx.fillText(bossName, e.x, ey - e.radius * 2.65);
      ctx.restore();
    }
    hpBar(
      ctx,
      e.x,
      ey - e.radius * 2.2,
      Math.max(28, e.radius * 2.4),
      e.hp,
      e.maxHp,
      e.kind === "elite" || e.kind === "boss" || e.kind === "herald" || e.kind === "devourer" || e.kind === "lich",
    );
  }

  for (const b of w.bullets) {
    if (!b.alive) continue;
    const bulletColor =
      b.kind === "chain"
        ? "#b54a40"
        : b.kind === "acid" || b.kind === "drill"
          ? "#8fa84a"
          : b.kind === "pellet"
            ? "#c4a574"
            : b.kind === "roar"
              ? "#c47a3a"
              : b.kind === "hex"
                ? "#8a5aaa"
                : b.kind === "bone"
                  ? "#d8c4a0"
                  : b.friendly
                    ? "#c4b08a"
                    : "#6ea8c9";
    ctx.save();
    ctx.globalAlpha = 0.18;
    ctx.strokeStyle = bulletColor;
    ctx.lineWidth = b.r * 1.8;
    ctx.beginPath();
    ctx.moveTo(b.x - b.vx * 0.018, b.y - b.vy * 0.018);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.fillStyle = bulletColor;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    if (b.kind === "chain") {
      ctx.strokeStyle = "rgba(181,74,64,0.7)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
  }

  for (const pt of w.particles) {
    if (!pt.alive) continue;
    const k = 1 - pt.t / pt.maxT;
    ctx.globalAlpha = k;
    ctx.fillStyle = pt.color;
    if (pt.kind === "ring") {
      ctx.strokeStyle = pt.color;
      ctx.lineWidth = 2 + 2 * k;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size + (1 - k) * 32, 0, Math.PI * 2);
      ctx.stroke();
    } else if (pt.kind === "slash") {
      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(pt.ang);
      ctx.strokeStyle = pt.color;
      ctx.lineWidth = Math.max(2, pt.size * 0.65);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-pt.size * 1.8, pt.size * 0.7);
      ctx.lineTo(pt.size * 1.8, -pt.size * 0.7);
      ctx.stroke();
      ctx.restore();
    } else if (pt.kind === "ghost") {
      ctx.strokeStyle = pt.color;
      ctx.lineWidth = Math.max(1, pt.size * 0.45);
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * (0.8 + k), 0, Math.PI * 2);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * k, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;

  ctx.font = "600 13px 'Source Sans 3', sans-serif";
  ctx.textAlign = "center";
  for (const f of w.floaters) {
    if (!f.alive) continue;
    ctx.globalAlpha = 1 - f.t / 0.85;
    ctx.fillStyle = f.color;
    ctx.font = f.crit ? "700 18px 'Cinzel', serif" : "600 13px 'Source Sans 3', sans-serif";
    ctx.fillText(f.text, f.x, f.y);
  }
  ctx.globalAlpha = 1;

  if (w.announceT > 0) {
    ctx.font = "600 28px 'Cinzel', serif";
    ctx.fillStyle = "rgba(235,230,220,0.92)";
    ctx.textAlign = "center";
    ctx.fillText(w.announce, camX, camY - cssH * 0.28);
  }

  ctx.restore();

  const vg = ctx.createRadialGradient(cssW / 2, cssH / 2, cssH * 0.2, cssW / 2, cssH / 2, cssH * 0.78);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,0.55)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, cssW, cssH);
}
