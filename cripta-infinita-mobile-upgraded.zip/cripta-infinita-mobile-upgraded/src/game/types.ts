export type HeroId = "valkhar" | "morvak" | "volgar" | "urgot" | "sion" | "scar";
export type SkillSlot = "q" | "w" | "e" | "r";
export type EnemyKind =
  | "ghoul"
  | "skeleton"
  | "brute"
  | "wraith"
  | "cultist"
  | "hound"
  | "golem"
  | "elite"
  | "boss"
  | "herald"
  | "devourer"
  | "lich";
export type Phase = "combat" | "between" | "dead" | "paused";
export type AimShape = "line" | "bar" | "circle" | "cone" | "self" | "dash" | "unit";

export type UpgradeId =
  | "ad"
  | "ap"
  | "crit"
  | "critDmg"
  | "lifesteal"
  | "hp"
  | "armor"
  | "haste"
  | "move"
  | "regen"
  | "cdr";

export type Screen = "title" | "help" | "select" | "play";

export type Stats = {
  hp: number;
  ad: number;
  as: number;
  ms: number;
  armor: number;
  range: number;
  radius: number;
};

export type SkillDef = {
  slot: SkillSlot;
  key: string;
  name: string;
  desc: string;
};

export type SkillAim = {
  shape: AimShape;
  range: number;
  width: number;
  radius: number;
  follow: boolean;
};

export type HeroDef = {
  id: HeroId;
  name: string;
  title: string;
  role: string;
  blurb: string;
  portrait: string;
  sheet: string;
  tint: "ruin" | "iron" | "storm" | "chem" | "grave";
  base: Stats;
  passive: { name: string; desc: string; max: number };
  skills: SkillDef[];
};

export type UpgradeDef = {
  id: UpgradeId;
  name: string;
  desc: string;
  max: number;
  baseCost: number;
};

export type SkillHud = {
  slot: SkillSlot;
  name: string;
  key: string;
  cd: number;
  maxCd: number;
  charges: number;
  maxCharges: number;
  recast: boolean;
  pips: number;
};

export type HudSnapshot = {
  phase: Phase;
  hp: number;
  maxHp: number;
  shield: number;
  gold: number;
  wave: number;
  kills: number;
  betweenT: number;
  announce: string;
  skills: SkillHud[];
  upgrades: Record<UpgradeId, number>;
  heroId: HeroId;
  shopHint: boolean;
  preview: SkillSlot | null;
  passive: { name: string; desc: string; stacks: number; max: number; active: boolean };
  combo: number;
  ad: number;
  ap: number;
};
