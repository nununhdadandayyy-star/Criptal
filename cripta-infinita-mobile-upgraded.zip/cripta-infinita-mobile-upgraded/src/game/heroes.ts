import type { HeroDef, HeroId, SkillAim, SkillSlot, UpgradeDef, UpgradeId } from "./types";

export const HEROES: Record<HeroId, HeroDef> = {
  valkhar: {
    id: "valkhar",
    name: "Valkhar",
    title: "a Lâmina da Ruína",
    role: "Duelista",
    blurb: "Três golpes da espada-mundo. Correntes. A asa da ruína não perdoa.",
    portrait: "/portraits/valkhar.jpg",
    sheet: "/sprites/valkhar.png",
    tint: "ruin",
    passive: { name: "Sangue da Ruína", desc: "A cada 3 ataques básicos, o próximo golpe é fortalecido e cura.", max: 3 },
    base: { hp: 860, ad: 92, as: 0.78, ms: 278, armor: 38, range: 102, radius: 18 },
    skills: [
      {
        slot: "q",
        key: "Q",
        name: "Lâmina da Ruína",
        desc: "Três golpes: linha, travessão e círculo. Escala com AD. A ponta da lâmina é o ponto doce.",
      },
      {
        slot: "w",
        key: "W",
        name: "Correntes do Abismo",
        desc: "Dispara uma corrente na mira. Se a vítima ficar no local, fica enraizada. Escala com AD e AP.",
      },
      {
        slot: "e",
        key: "E",
        name: "Impulso Sombrio",
        desc: "Dois impulsos na direção do movimento. Atravessar inimigos cura — e cura mais no definitivo.",
      },
      {
        slot: "r",
        key: "R",
        name: "Fim do Mundo",
        desc: "Desperta. Mais AD, velocidade, tamanho e vampirismo. Inimigos próximos recuam.",
      },
    ],
  },
  morvak: {
    id: "morvak",
    name: "Morvak",
    title: "o Senhor de Ferro",
    role: "Tanque",
    blurb: "O ferro não esquece. O reino dos mortos ainda espera pelo seu nome.",
    portrait: "/portraits/morvak.jpg",
    sheet: "/sprites/morvak.png",
    tint: "iron",
    passive: { name: "Couraça Ancestral", desc: "Receber dano cria uma camada de armadura. Até 3 camadas.", max: 3 },
    base: { hp: 1020, ad: 78, as: 0.68, ms: 255, armor: 58, range: 92, radius: 20 },
    skills: [
      {
        slot: "q",
        key: "Q",
        name: "Obliterar",
        desc: "Esmaga na mira. Três golpes empilham poder — o terceiro é devastador. Escala com AD.",
      },
      {
        slot: "w",
        key: "W",
        name: "Baluarte de Ferro",
        desc: "Escudo de ossos e aço. Recaste para explodir o que restar — a explosão escala com AP.",
      },
      {
        slot: "e",
        key: "E",
        name: "Garra da Morte",
        desc: "Cone espectral na mira que puxa inimigos até você. Escala com AD e AP.",
      },
      {
        slot: "r",
        key: "R",
        name: "Reino dos Mortos",
        desc: "Isola o inimigo sob o cursor num círculo de morte. Lá dentro, ele sofre mais.",
      },
    ],
  },
  volgar: {
    id: "volgar",
    name: "Volgar",
    title: "o Urso da Tempestade",
    role: "Lutador",
    blurb: "O trovão anda sobre quatro relâmpagos. A cripta aprende a se ajoelhar.",
    portrait: "/portraits/volgar.jpg",
    sheet: "/sprites/volgar.png",
    tint: "storm",
    passive: { name: "Fúria Tempestuosa", desc: "Mover-se acumula fúria. Ataques consomem a fúria para causar dano extra.", max: 5 },
    base: { hp: 940, ad: 86, as: 0.84, ms: 292, armor: 44, range: 96, radius: 20 },
    skills: [
      {
        slot: "q",
        key: "Q",
        name: "Investida Trovejante",
        desc: "Ganha fúria e velocidade. O próximo golpe atordoa e ruge. Escala com AD.",
      },
      {
        slot: "w",
        key: "W",
        name: "Dilacerar",
        desc: "Morde o alvo da mira. Recaste na marca para dilacerar de novo e se curar. Escala com AD.",
      },
      {
        slot: "e",
        key: "E",
        name: "Cisão do Céu",
        desc: "Círculo de tempestade na mira. Dano mágico que escala com AP. Escudo se estiver dentro.",
      },
      {
        slot: "r",
        key: "R",
        name: "Avatar da Tempestade",
        desc: "Salta até a mira e cresce. Aterrissagem atordoa. Relâmpagos pulsam com AD e AP.",
      },
    ],
  },
  urgot: {
    id: "urgot",
    name: "Urgot",
    title: "o Carrasco",
    role: "Atirador de Ferro",
    blurb: "Onde a carne falha, o cano decide. A forja química não pede perdão.",
    portrait: "/portraits/urgot.jpg",
    sheet: "/sprites/urgot.png",
    tint: "chem",
    passive: { name: "Barragem de Ferro", desc: "A cada 3 ataques, um cano extra dispara contra outro inimigo.", max: 3 },
    base: { hp: 920, ad: 90, as: 0.72, ms: 252, armor: 50, range: 200, radius: 22 },
    skills: [
      {
        slot: "q",
        key: "Q",
        name: "Carga Corrosiva",
        desc: "Lança uma carga no chão da mira. Explode em ácido. Escala com AD e AP.",
      },
      {
        slot: "w",
        key: "W",
        name: "Purga",
        desc: "Escudo e rajada de canos. Quanto mais velocidade de ataque, mais projéteis e mais rápido eles saem.",
      },
      {
        slot: "e",
        key: "E",
        name: "Desdém",
        desc: "Investida na mira. Vira os primeiros inimigos de ponta-cabeça e os atordoa. Escala com AD.",
      },
      {
        slot: "r",
        key: "R",
        name: "Medo Além da Morte",
        desc: "Marca o inimigo sob o cursor. Se cair abaixo de 28% de vida, é executado.",
      },
    ],
  },
  sion: {
    id: "sion",
    name: "Sion",
    title: "o Colosso Morto",
    role: "Tanque",
    blurb: "O general que recusou a cova. A fornalha ainda queima no peito.",
    portrait: "/portraits/sion.jpg",
    sheet: "/sprites/sion.png",
    tint: "grave",
    passive: {
      name: "Glória na Morte",
      desc: "Ao morrer, revive 10s com vida que decai e ataques vorazes. Abates concedem vida máxima permanente nesta run.",
      max: 1,
    },
    base: { hp: 1240, ad: 84, as: 0.62, ms: 250, armor: 56, range: 102, radius: 24 },
    skills: [
      {
        slot: "q",
        key: "Q",
        name: "Golpe Dizimador",
        desc: "Segure para carregar o machado. Solte para esmagar em linha. Carga máxima arremessa ao ar. Escala com AD.",
      },
      {
        slot: "w",
        key: "W",
        name: "Fornalha das Almas",
        desc: "Escudo de almas. Recaste para explodir. Abates alimentam vida máxima. Escala com AP e vida.",
      },
      {
        slot: "e",
        key: "E",
        name: "Rugido do Carrasco",
        desc: "Urro em linha que fere e reduz a velocidade. Inimigos pequenos viram projéteis. Escala com AD e AP.",
      },
      {
        slot: "r",
        key: "R",
        name: "Investida Imparável",
        desc: "Carrega sem parar na mira. Atravessa, arremessa e esmaga no fim. Escala com AD.",
      },
    ],
  },
  scar: {
    id: "scar",
    name: "Scar",
    title: "o Carrasco",
    role: "Executor",
    blurb: "Ele não caça heróis. Ele marca sentenças. Cada golpe abre uma ferida que a cripta não consegue fechar.",
    portrait: "/portraits/scar.png",
    sheet: "/sprites/scar.png",
    tint: "ruin",
    passive: { name: "Sentença de Sangue", desc: "Ataques e habilidades aplicam marcas. No terceiro acúmulo, a ferida explode e o alvo fica vulnerável.", max: 3 },
    base: { hp: 980, ad: 98, as: 0.74, ms: 270, armor: 46, range: 128, radius: 21 },
    skills: [
      { slot: "q", key: "Q", name: "Corte Condenado", desc: "Arremessa o cutelo em uma linha. O ponto final causa dano extra e puxa inimigos marcados." },
      { slot: "w", key: "W", name: "Capa de Ferro", desc: "Fica intocável por um instante e devolve uma lâmina em cone. Abates renovam a proteção." },
      { slot: "e", key: "E", name: "Gancho do Carrasco", desc: "Avança até a mira e arrasta o primeiro inimigo atingido, causando atordoamento." },
      { slot: "r", key: "R", name: "Execução Final", desc: "Marca o inimigo sob a mira. Ao cair abaixo de 35% de vida, Scar o executa e espalha terror." },
    ],
  },
};

export const SKILL_AIM: Record<HeroId, Record<SkillSlot, SkillAim>> = {
  valkhar: {
    q: { shape: "line", range: 280, width: 64, radius: 0, follow: true },
    w: { shape: "line", range: 440, width: 30, radius: 0, follow: true },
    e: { shape: "dash", range: 180, width: 42, radius: 0, follow: true },
    r: { shape: "self", range: 0, width: 0, radius: 210, follow: true },
  },
  morvak: {
    q: { shape: "line", range: 230, width: 86, radius: 0, follow: true },
    w: { shape: "self", range: 0, width: 0, radius: 160, follow: true },
    e: { shape: "cone", range: 310, width: 0.72, radius: 0, follow: true },
    r: { shape: "unit", range: 380, width: 80, radius: 240, follow: false },
  },
  volgar: {
    q: { shape: "self", range: 0, width: 0, radius: 70, follow: true },
    w: { shape: "unit", range: 110, width: 70, radius: 36, follow: false },
    e: { shape: "circle", range: 300, width: 0, radius: 175, follow: false },
    r: { shape: "circle", range: 320, width: 0, radius: 210, follow: false },
  },
  urgot: {
    q: { shape: "circle", range: 430, width: 0, radius: 118, follow: false },
    w: { shape: "cone", range: 240, width: 0.42, radius: 0, follow: true },
    e: { shape: "dash", range: 270, width: 72, radius: 0, follow: false },
    r: { shape: "unit", range: 420, width: 90, radius: 46, follow: false },
  },
  sion: {
    q: { shape: "line", range: 360, width: 92, radius: 0, follow: true },
    w: { shape: "self", range: 0, width: 0, radius: 175, follow: true },
    e: { shape: "line", range: 460, width: 46, radius: 0, follow: true },
    r: { shape: "dash", range: 640, width: 78, radius: 0, follow: false },
  },
  scar: {
    q: { shape: "line", range: 390, width: 54, radius: 0, follow: true },
    w: { shape: "cone", range: 250, width: 0.55, radius: 0, follow: true },
    e: { shape: "dash", range: 300, width: 64, radius: 0, follow: false },
    r: { shape: "unit", range: 460, width: 96, radius: 64, follow: false },
  },
};

export const UPGRADE_POWER = {
  ad: 5,
  ap: 10,
  hp: 100,
  armor: 5,
  ls: 0.02,
  cdr: 0.045,
  cdrCap: 0.55,
} as const;

export const UPGRADE_LIST: UpgradeDef[] = [
  { id: "ad", name: "Dano de ataque", desc: "+5 AD", max: 50, baseCost: 22 },
  { id: "ap", name: "Poder de habilidade", desc: "+10 AP", max: 50, baseCost: 22 },
  { id: "crit", name: "Chance crítica", desc: "+2.2% chance de crítico", max: 50, baseCost: 30 },
  { id: "critDmg", name: "Dano crítico", desc: "+6% no crítico", max: 50, baseCost: 28 },
  { id: "lifesteal", name: "Vampirismo", desc: "+2% vampirismo (cura em todo o dano)", max: 50, baseCost: 34 },
  { id: "hp", name: "Vitalidade", desc: "+100 vida máxima", max: 50, baseCost: 22 },
  { id: "armor", name: "Armadura", desc: "+5 armadura", max: 50, baseCost: 24 },
  { id: "haste", name: "Fúria", desc: "+3.5% vel. de ataque", max: 50, baseCost: 26 },
  { id: "move", name: "Ímpeto", desc: "+2.8% vel. de movimento", max: 50, baseCost: 20 },
  { id: "regen", name: "Regeneração", desc: "+0.85 vida por segundo", max: 50, baseCost: 22 },
  { id: "cdr", name: "Bravura", desc: "+4.5% redução de recarga", max: 50, baseCost: 34 },
];

export const EMPTY_UPGRADES: Record<UpgradeId, number> = {
  ad: 0,
  ap: 0,
  crit: 0,
  critDmg: 0,
  lifesteal: 0,
  hp: 0,
  armor: 0,
  haste: 0,
  move: 0,
  regen: 0,
  cdr: 0,
};

export function upgradeCost(def: UpgradeDef, level: number): number {
  return Math.floor(def.baseCost * Math.pow(1.132, level) + level * 4);
}

export const TINT_CLASS: Record<HeroDef["tint"], string> = {
  ruin: "text-ruin",
  iron: "text-iron",
  storm: "text-storm",
  chem: "text-chem",
  grave: "text-grave",
};

export const HERO_IDS: HeroId[] = ["valkhar", "morvak", "volgar", "urgot", "sion", "scar"];
