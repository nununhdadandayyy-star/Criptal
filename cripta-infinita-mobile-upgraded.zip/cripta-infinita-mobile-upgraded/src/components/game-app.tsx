import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import {
  CloudLightning,
  Coins,
  Crosshair,
  Heart,
  Pause,
  Play,
  Shield,
  ShoppingBag,
  Skull,
  Swords,
  Volume2,
  VolumeX,
} from "lucide-react";
import { HERO_IDS, HEROES, UPGRADE_LIST, upgradeCost } from "@/game/heroes";
import { hydrateGameSave, useGameStore } from "@/game/store";
import { mountGame, type GameHandle } from "@/game/runtime";
import { unlockAudio, setMuted } from "@/game/audio";
import type { HeroId, SkillSlot, UpgradeId } from "@/game/types";

const TINT: Record<HeroId, string> = {
  valkhar: "text-ruin",
  morvak: "text-iron",
  volgar: "text-storm",
  urgot: "text-chem",
  sion: "text-grave",
  scar: "text-ruin",
};

const RING: Record<HeroId, string> = {
  valkhar: "ring-ruin",
  morvak: "ring-iron",
  volgar: "ring-storm",
  urgot: "ring-chem",
  sion: "ring-grave",
  scar: "ring-ruin",
};

function HeroIcon({ id, className }: { id: HeroId; className?: string }) {
  const cls = `size-3.5 ${TINT[id]} ${className ?? ""}`;
  if (id === "valkhar") return <Swords className={cls} />;
  if (id === "morvak") return <Shield className={cls} />;
  if (id === "volgar") return <CloudLightning className={cls} />;
  if (id === "sion") return <Skull className={cls} />;
  if (id === "scar") return <Swords className={cls} />;
  return <Crosshair className={cls} />;
}

function TitleScreen() {
  const setScreen = useGameStore((s) => s.setScreen);
  const bestWave = useGameStore((s) => s.bestWave);
  const bestKills = useGameStore((s) => s.bestKills);
  return (
    <div className="game-root">
      <div className="absolute inset-0 grid grid-cols-2 md:grid-cols-5">
        {HERO_IDS.map((id) => (
          <div key={id} className="relative min-w-0 overflow-hidden">
            <img src={HEROES[id].portrait} alt="" className="h-full w-full object-cover object-top opacity-50" />
          </div>
        ))}
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/82 to-bg/35" />
      </div>
      <div className="relative z-10 flex h-full flex-col items-center justify-end px-5 pb-10 pt-16 md:justify-center md:pb-0">
        <p className="stagger-in text-xs font-medium uppercase tracking-[0.28em] text-muted">Arena eterna</p>
        <h1
          className="font-display stagger-in mt-3 text-center text-5xl font-semibold text-fg md:text-7xl"
          style={{ animationDelay: "40ms" }}
        >
          Cripta Infinita
        </h1>
        <p
          className="stagger-in mt-4 max-w-lg text-center text-base leading-relaxed text-muted"
          style={{ animationDelay: "80ms" }}
        >
          Seis guerreiros. Waves que nunca cessam. Clique no chão para andar, ou use WASD.
          Segure a habilidade para ver a área, solte para disparar. Ouro dos caídos forja até o nível 50.
        </p>
        <div className="stagger-in mt-8 flex w-full max-w-sm flex-col gap-3" style={{ animationDelay: "120ms" }}>
          <button
            className="h-12 rounded-xl bg-accent text-sm font-semibold text-accent-fg transition-transform duration-150 hover:brightness-110 active:scale-[0.98]"
            onClick={() => {
              unlockAudio();
              setScreen("select");
            }}
          >
            Entrar na cripta
          </button>
          <button
            className="h-12 rounded-xl border border-border bg-surface text-sm font-medium text-fg transition-colors hover:bg-elevated"
            onClick={() => setScreen("help")}
          >
            Como jogar
          </button>
        </div>
        {bestWave > 0 && (
          <p className="mt-6 text-sm text-subtle tabular">
            Recorde: onda {bestWave} · {bestKills} abates
          </p>
        )}
      </div>
    </div>
  );
}

function HelpScreen() {
  const setScreen = useGameStore((s) => s.setScreen);
  return (
    <div className="game-root game-root-menu">
      <div className="game-root-menu-scroll flex items-center justify-center px-5 py-8">
        <div className="panel-in w-full max-w-lg rounded-2xl border border-border bg-surface p-6 md:p-8">
          <h2 className="font-display text-2xl font-semibold">Como jogar</h2>
          <ul className="mt-5 space-y-3 text-sm leading-relaxed text-muted">
            <li>
              <span className="font-medium text-fg">Clique no chão</span> (ou WASD / setas) para andar. O mouse mira —
              o cruzeta no chão é o ponto da habilidade. No celular, use o joystick.
            </li>
            <li>
              <span className="font-medium text-fg">Segure Q F E R</span> (ou 1 2 3 4) para ver a área.{" "}
              <span className="font-medium text-fg">Solte</span> para lançar na mira. F é o W.
            </li>
            <li>
              No alcance, o ataque vai no inimigo mais alinhado à mira. Clique só reforça o foco.
            </li>
            <li>
              Inimigos soltam <span className="font-medium text-coin">ouro</span>. Entre as ondas, gaste na forja (B) —
              cada atributo sobe até 50. AD e AP fazem as habilidades escalarem.
            </li>
            <li className="md:hidden">
              Toque: joystick esquerdo move, direito mira. Segure a habilidade e solte na direção da mira.
            </li>
          </ul>
          <button
            className="mt-6 h-11 w-full rounded-lg bg-accent text-sm font-semibold text-accent-fg"
            onClick={() => setScreen("select")}
          >
            Escolher guerreiro
          </button>
        </div>
      </div>
    </div>
  );
}

function SelectScreen() {
  const heroId = useGameStore((s) => s.heroId);
  const setHero = useGameStore((s) => s.setHero);
  const startRun = useGameStore((s) => s.startRun);
  const setScreen = useGameStore((s) => s.setScreen);
  const hero = HEROES[heroId];

  function play() {
    unlockAudio();
    startRun();
  }

  return (
    <div className="game-root game-root-menu">
      <div className="game-root-menu-scroll">
        <div className="mx-auto flex w-full max-w-6xl flex-col px-4 pb-4 pt-6 md:pt-8">
          <button className="self-start text-sm text-muted hover:text-fg" onClick={() => setScreen("title")}>
            Voltar
          </button>
          <h2 className="font-display mt-3 text-3xl font-semibold md:text-4xl">Escolha seu guerreiro</h2>
          <p className="mt-2 max-w-xl text-sm text-muted">Cinco destinos. O mesmo abismo. Sion recusa a cova.</p>
          <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
            {HERO_IDS.map((id) => {
              const h = HEROES[id];
              const on = id === heroId;
              return (
                <button
                  key={id}
                  onClick={() => setHero(id)}
                  className={`overflow-hidden rounded-2xl border text-left transition-transform duration-150 active:scale-[0.99] ${
                    on ? `border-accent ring-1 ${RING[id]} bg-elevated` : "border-border bg-surface"
                  }`}
                >
                  <div className="relative h-44 overflow-hidden sm:h-56 md:h-64">
                    <img
                      src={h.portrait}
                      alt={h.name}
                      className="h-full w-full object-cover object-top outline outline-1 -outline-offset-1 outline-white/10"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/70 to-transparent p-3 md:p-4">
                      <p className={`font-display text-lg font-semibold md:text-xl ${TINT[id]}`}>{h.name}</p>
                      <p className="text-[10px] uppercase tracking-[0.18em] text-muted md:text-xs">{h.title}</p>
                    </div>
                  </div>
                  <div className="hidden p-3 sm:block md:p-4">
                    <p className="text-xs font-medium uppercase tracking-[0.16em] text-subtle">{h.role}</p>
                    <p className="mt-1 line-clamp-2 text-sm leading-relaxed text-muted">{h.blurb}</p>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-4 rounded-2xl border border-border bg-surface p-4 md:p-5">
            <div className="flex items-baseline justify-between gap-3">
              <p className={`font-display text-lg font-semibold ${TINT[heroId]}`}>{hero.name}</p>
              <p className="text-xs uppercase tracking-[0.16em] text-subtle">{hero.role}</p>
            </div>
            <p className="mt-1 text-sm text-muted sm:hidden">{hero.blurb}</p>
            <div className={`mt-3 rounded-xl border bg-bg/50 p-3 ${RING[heroId]}`}>
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className={`text-xs font-semibold uppercase tracking-[0.14em] ${TINT[heroId]}`}>Passiva · {hero.passive.name}</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted">{hero.passive.desc}</p>
                </div>
                <span className="shrink-0 rounded-lg border border-border px-2 py-1 text-[10px] text-subtle">0/{hero.passive.max}</span>
              </div>
            </div>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {hero.skills.map((s) => (
                <div key={s.slot} className="rounded-lg bg-elevated px-3 py-2.5">
                  <p className="text-xs font-semibold tracking-wide text-fg">
                    {s.key} · {s.name}
                  </p>
                  <p className="mt-1 text-sm leading-snug text-muted">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="game-root-menu-bar">
        <div className="mx-auto flex w-full max-w-6xl items-center gap-3">
          <img
            src={hero.portrait}
            alt=""
            className="hidden size-12 shrink-0 rounded-lg object-cover object-top outline outline-1 -outline-offset-1 outline-white/10 sm:block"
          />
          <div className="min-w-0 flex-1">
            <p className={`font-display truncate text-base font-semibold ${TINT[heroId]}`}>{hero.name}</p>
            <p className="truncate text-xs text-muted">{hero.title}</p>
          </div>
          <button
            className="inline-flex h-12 min-w-[9.5rem] flex-1 items-center justify-center gap-2 rounded-xl bg-accent px-6 text-sm font-semibold text-accent-fg transition-transform duration-150 hover:brightness-110 active:scale-[0.98] sm:flex-none sm:min-w-[12rem]"
            onClick={play}
          >
            <Play className="size-4" style={{ marginLeft: 2 }} />
            Jogar
          </button>
        </div>
      </div>
    </div>
  );
}

function Stick({
  label,
  onChange,
}: {
  label: string;
  onChange: (x: number, y: number, active: boolean) => void;
}) {
  const origin = useRef({ x: 0, y: 0 });
  const [knob, setKnob] = useState({ x: 0, y: 0 });

  function radial(dx: number, dy: number) {
    const m = Math.hypot(dx, dy);
    const max = 42;
    if (m < 8) return { x: 0, y: 0 };
    const k = Math.min(1, m / max);
    return { x: (dx / m) * k, y: (dy / m) * k };
  }

  function down(e: ReactPointerEvent<HTMLDivElement>) {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    origin.current = { x: e.clientX, y: e.clientY };
    setKnob({ x: 0, y: 0 });
    onChange(0, 0, true);
  }
  function move(e: ReactPointerEvent<HTMLDivElement>) {
    if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
    const v = radial(e.clientX - origin.current.x, e.clientY - origin.current.y);
    setKnob(v);
    onChange(v.x, v.y, true);
  }
  function up(e: ReactPointerEvent<HTMLDivElement>) {
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
    setKnob({ x: 0, y: 0 });
    onChange(0, 0, false);
  }

  return (
    <div
      className="relative size-[112px] touch-none sm:size-[108px] rounded-full border border-border/80 bg-bg/40 sm:size-[108px]"
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={up}
      onPointerCancel={up}
    >
      <span className="pointer-events-none absolute inset-x-0 -top-5 text-center text-[10px] uppercase tracking-[0.16em] text-subtle">
        {label}
      </span>
      <span
        className="absolute left-1/2 top-1/2 size-11 -translate-x-1/2 -translate-y-1/2 rounded-full border border-border bg-elevated"
        style={{ transform: `translate(calc(-50% + ${knob.x * 42}px), calc(-50% + ${knob.y * 42}px))` }}
      />
    </div>
  );
}

function SkillButton({
  slot,
  name,
  keycap,
  cd,
  maxCd,
  recast,
  pips,
  preview,
  onHold,
  heroId,
}: {
  slot: SkillSlot;
  name: string;
  keycap: string;
  cd: number;
  maxCd: number;
  recast: boolean;
  pips: number;
  preview: boolean;
  onHold: (s: SkillSlot, down: boolean) => void;
  heroId: HeroId;
}) {
  const ready = cd <= 0.05;
  const frac = ready ? 0 : cd / maxCd;
  return (
    <button
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        onHold(slot, true);
      }}
      onPointerUp={() => onHold(slot, false)}
      onPointerCancel={() => onHold(slot, false)}
      className={`skill-button pointer-events-auto relative flex h-16 w-16 min-w-16 flex-col items-center justify-center overflow-hidden rounded-2xl border bg-surface/95 md:h-[4.7rem] md:w-[5.1rem] ${
        preview ? `border-accent skill-aiming ${TINT[heroId]}` : "border-border"
      } ${ready ? "skill-ready" : ""}`}
      aria-label={name}
    >
      <span className="absolute inset-x-0 bottom-0 bg-elevated" style={{ height: `${frac * 100}%` }} />
      <span className="relative flex size-9 items-center sm:size-8 justify-center rounded-lg border border-border/80 bg-bg/70 font-display text-sm font-semibold text-fg shadow-inner">
        {keycap}
      </span>
      <span className="relative mt-1 hidden max-w-full truncate px-1 text-[10px] font-medium text-muted md:block">{name}</span>
      {!ready && (
        <span className="relative text-[10px] tabular text-subtle">{Math.ceil(cd)}</span>
      )}
      {pips > 0 && (
        <span className="relative mt-0.5 flex gap-0.5">
          {Array.from({ length: Math.min(3, Math.max(pips, 3)) }).map((_, i) => (
            <span key={i} className={`h-1 w-1 rounded-full ${i < pips ? "bg-accent" : "bg-border"}`} />
          ))}
        </span>
      )}
      {recast && ready && <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-ok" />}
    </button>
  );
}

function ShopPanel({
  gold,
  upgrades,
  onBuy,
  onClose,
  onNext,
  between,
  betweenT,
}: {
  gold: number;
  upgrades: Record<UpgradeId, number>;
  onBuy: (id: UpgradeId) => void;
  onClose: () => void;
  onNext: () => void;
  between: boolean;
  betweenT: number;
}) {
  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex items-end justify-center p-3 md:items-center">
      <div
        className="pointer-events-auto panel-in max-h-[88dvh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-border bg-surface/95 p-5 shadow-[0_20px_80px_rgba(0,0,0,0.55)]"
        style={{ touchAction: "pan-y" }}
      >
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="font-display text-xl font-semibold">Forja</h3>
            <p className="text-sm text-muted">Cada atributo sobe até 50. A morte zera a run.</p>
          </div>
          <p className="font-display text-lg text-coin tabular">{gold}</p>
        </div>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {UPGRADE_LIST.map((u) => {
            const lv = upgrades[u.id];
            const cost = upgradeCost(u, lv);
            const maxed = lv >= u.max;
            const can = !maxed && gold >= cost;
            return (
              <button
                key={u.id}
                disabled={maxed}
                onClick={() => onBuy(u.id)}
                className={`flex items-center justify-between rounded-xl border px-3 py-3 text-left ${
                  can ? "border-border bg-elevated hover:border-accent" : "border-border/60 bg-bg opacity-70"
                }`}
              >
                <div>
                  <p className="text-sm font-medium text-fg">
                    {u.name}{" "}
                    <span className="text-subtle">
                      · {lv}/{u.max}
                    </span>
                  </p>
                  <p className="text-xs text-muted">{u.desc}</p>
                  <div className="mt-1 h-1 w-28 overflow-hidden rounded-full bg-border">
                    <div className="h-full bg-accent/80" style={{ width: `${(lv / u.max) * 100}%` }} />
                  </div>
                </div>
                <span className={`text-sm tabular ${can ? "text-coin" : "text-subtle"}`}>{maxed ? "Máx" : cost}</span>
              </button>
            );
          })}
        </div>
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          {between && (
            <button className="h-11 flex-1 rounded-lg bg-accent text-sm font-semibold text-accent-fg" onClick={onNext}>
              Próxima onda{betweenT > 0 ? ` · ${Math.ceil(betweenT)}s` : ""}
            </button>
          )}
          <button className="h-11 flex-1 rounded-lg border border-border text-sm font-medium text-fg" onClick={onClose}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}

function PlayScreen() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const handleRef = useRef<GameHandle | null>(null);
  const heroId = useGameStore((s) => s.heroId);
  const runId = useGameStore((s) => s.runId);
  const hud = useGameStore((s) => s.hud);
  const setHud = useGameStore((s) => s.setHud);
  const recordRun = useGameStore((s) => s.recordRun);
  const setScreen = useGameStore((s) => s.setScreen);
  const startRun = useGameStore((s) => s.startRun);
  const muted = useGameStore((s) => s.muted);
  const shake = useGameStore((s) => s.shake);
  const toggleMute = useGameStore((s) => s.toggleMute);
  const toggleShake = useGameStore((s) => s.toggleShake);
  const shopOpen = useGameStore((s) => s.shopOpen);
  const setShopOpen = useGameStore((s) => s.setShopOpen);
  const bestWave = useGameStore((s) => s.bestWave);
  const [paused, setPaused] = useState(false);
  const shopRef = useRef(false);
  shopRef.current = shopOpen;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handle = mountGame(canvas, {
      heroId,
      muted,
      shake,
      onHud: setHud,
      onDeath: (wave, kills) => recordRun(wave, kills),
      onShop: () => setShopOpen(!shopRef.current),
      onPause: (v) => setPaused(v),
    });
    handleRef.current = handle;
    return () => {
      handle.destroy();
      handleRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [heroId, runId]);

  useEffect(() => {
    setMuted(muted);
  }, [muted]);
  useEffect(() => {
    handleRef.current?.setShake(shake);
  }, [shake]);
  useEffect(() => {
    handleRef.current?.setPaused(paused);
  }, [paused]);
  useEffect(() => {
    if (hud.shopHint) setShopOpen(true);
    if (hud.phase === "combat") setShopOpen(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hud.phase, hud.shopHint]);

  const hpPct = hud.maxHp > 0 ? (hud.hp / hud.maxHp) * 100 : 0;
  const shPct = hud.maxHp > 0 ? (hud.shield / hud.maxHp) * 100 : 0;
  const dead = hud.phase === "dead";
  const previewName = hud.skills.find((s) => s.slot === hud.preview)?.name;

  return (
    <div className="game-root">
      <canvas ref={canvasRef} className="game-canvas" tabIndex={0} onPointerDown={() => canvasRef.current?.focus()} />
      <div className="pointer-events-none absolute inset-0 flex flex-col p-3 md:p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="hud-chip pointer-events-auto min-w-0 max-w-[78%] px-3 py-2">
            <div className="flex items-center gap-2 text-xs text-muted">
              <HeroIcon id={heroId} />
              <span className="font-display text-sm text-fg">Onda {hud.wave}</span>
              <span className="tabular text-coin flex items-center gap-1">
                <Coins className="size-3.5" />
                {hud.gold}
              </span>
              <span className="hidden tabular text-subtle sm:inline">{hud.kills} abates</span>
            </div>
            <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-bg">
              <div className="relative h-full">
                <div className="h-full bg-blood" style={{ width: `${hpPct}%` }} />
                {shPct > 0 && (
                  <div
                    className="absolute inset-y-0 left-0 bg-iron/80"
                    style={{ width: `${Math.min(100, hpPct + shPct)}%` }}
                  />
                )}
              </div>
            </div>
            <p className="mt-1 flex items-center gap-1 text-[11px] text-subtle tabular">
              <Heart className="size-3" />
              {Math.ceil(hud.hp)}/{Math.ceil(hud.maxHp)}
              <span className="ml-2 text-subtle">AD {Math.round(hud.ad)} · AP {Math.round(hud.ap)}</span>
              {previewName && <span className="ml-2 text-fg">· {previewName}</span>}
            </p>
            <div className="mt-1 flex items-center gap-1.5 sm:hidden">
              <span className={`text-[9px] font-semibold uppercase tracking-[0.12em] ${TINT[heroId]}`}>{hud.passive.name}</span>
              <span className="flex gap-0.5">
                {Array.from({ length: hud.passive.max }).map((_, i) => (
                  <span key={i} className={`h-1 w-1 rounded-full ${i < hud.passive.stacks ? "bg-accent" : "bg-border"}`} />
                ))}
              </span>
            </div>
          </div>
          <div className="pointer-events-auto flex gap-2">
            <button
              className="hud-chip flex size-11 items-center justify-center"
              onClick={() => setShopOpen(true)}
              aria-label="Loja"
            >
              <ShoppingBag className="size-4" />
            </button>
            <button
              className="hud-chip flex size-11 items-center justify-center"
              onClick={() => setPaused((p) => !p)}
              aria-label="Pausar"
            >
              {paused ? <Play className="size-4" /> : <Pause className="size-4" />}
            </button>
          </div>
        </div>

        <div className="pointer-events-none absolute left-1/2 top-[5.8rem] z-10 hidden -translate-x-1/2 sm:block md:top-[6.7rem]">
          <div className={`passive-chip ${hud.passive.active ? "passive-chip-active" : ""}`}>
            <div className="flex items-center gap-2">
              <span className={`passive-orb ${TINT[heroId]}`} />
              <div className="min-w-0">
                <p className="truncate text-[10px] font-semibold uppercase tracking-[0.16em] text-fg">{hud.passive.name}</p>
                <p className="mt-0.5 max-w-[260px] truncate text-[10px] text-muted">{hud.passive.desc}</p>
              </div>
              <div className="flex gap-1 pl-1">
                {Array.from({ length: hud.passive.max }).map((_, i) => (
                  <span
                    key={i}
                    className={`h-1.5 w-1.5 rounded-full ${i < hud.passive.stacks ? `bg-current ${TINT[heroId]}` : "bg-border"}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="pointer-events-none absolute left-1/2 top-16 z-10 -translate-x-1/2 md:top-20">
          {hud.phase === "between" && !shopOpen && !dead && (
            <button
              className="pointer-events-auto hud-chip px-4 py-2 text-sm font-medium"
              onClick={() => setShopOpen(true)}
            >
              Forja aberta · próxima onda em {Math.ceil(hud.betweenT)}s
            </button>
          )}
        </div>

        <div className="mt-auto flex flex-col gap-2">
          <p className="pointer-events-none hidden text-center text-[11px] uppercase tracking-[0.18em] text-subtle md:block">
            Clique no chão para andar · WASD · segure Q F E R
          </p>
          <div className="flex items-end justify-between gap-3 pb-1">
            <div className={`combo-meter ${hud.combo > 0 ? "combo-meter-on" : ""}`}>
              <span className="font-display text-base">{hud.combo}</span>
              <span>combo</span>
            </div>
            <div className="flex justify-end gap-1.5 md:gap-2">
            {hud.skills.map((s) => (
              <SkillButton
                key={s.slot}
                slot={s.slot}
                name={s.name}
                keycap={s.key}
                cd={s.cd}
                maxCd={s.maxCd}
                recast={s.recast}
                pips={s.pips}
                preview={hud.preview === s.slot}
                heroId={heroId}
                onHold={(slot, down) => handleRef.current?.hold(slot, down)}
              />
            ))}
            </div>
          </div>
          <div className="flex items-end justify-between">
            <div className="pointer-events-auto">
              <Stick
                label="Andar"
                onChange={(x, y, active) => handleRef.current?.setMoveStick(x, y, active)}
              />
            </div>
            <div className="pointer-events-auto md:hidden">
              <Stick
                label="Mira"
                onChange={(x, y, active) => handleRef.current?.setAimStick(x, y, active)}
              />
            </div>
          </div>
        </div>
      </div>

      {shopOpen && !dead && (
        <ShopPanel
          gold={hud.gold}
          upgrades={hud.upgrades}
          between={hud.phase === "between"}
          betweenT={hud.betweenT}
          onBuy={(id) => {
            handleRef.current?.buy(id);
            const w = handleRef.current?.getWorld();
            if (w) setHud({ ...hud, gold: w.gold, upgrades: { ...w.upgrades }, hp: w.player.hp });
          }}
          onClose={() => setShopOpen(false)}
          onNext={() => {
            setShopOpen(false);
            handleRef.current?.skip();
          }}
        />
      )}

      {paused && !dead && !shopOpen && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-bg/70 p-4">
          <div className="panel-in w-full max-w-sm rounded-2xl border border-border bg-surface p-6">
            <h3 className="font-display text-2xl font-semibold">Pausa</h3>
            <p className="mt-2 text-sm text-muted">Clique no chão para andar · WASD · mouse mira · segure QFER e solte</p>
            <div className="mt-5 flex flex-col gap-2">
              <button className="h-11 rounded-lg bg-accent text-sm font-semibold text-accent-fg" onClick={() => setPaused(false)}>
                Continuar
              </button>
              <button className="h-11 rounded-lg border border-border text-sm" onClick={toggleMute}>
                <span className="inline-flex items-center gap-2">
                  {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
                  {muted ? "Som desligado" : "Som ligado"}
                </span>
              </button>
              <button className="h-11 rounded-lg border border-border text-sm" onClick={toggleShake}>
                Tremor de tela: {shake ? "ligado" : "desligado"}
              </button>
              <button className="h-11 rounded-lg border border-border text-sm text-muted" onClick={() => setScreen("select")}>
                Abandonar run
              </button>
            </div>
          </div>
        </div>
      )}

      {dead && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-bg/75 p-4">
          <div className="panel-in w-full max-w-sm rounded-2xl border border-border bg-surface p-6 text-center">
            <p className="text-xs uppercase tracking-[0.22em] text-muted">A cripta reivindica</p>
            <h3 className="font-display mt-2 text-3xl font-semibold">Você caiu</h3>
            <p className="mt-4 text-sm text-muted">
              Onda <span className="text-fg tabular">{hud.wave}</span> · {hud.kills} abates
            </p>
            <p className="mt-1 text-xs text-subtle">Recorde: onda {bestWave}</p>
            <p className="mt-3 text-sm text-muted">Ouro e atributos desta run foram perdidos.</p>
            <div className="mt-6 flex flex-col gap-2">
              <button
                className="h-11 rounded-lg bg-accent text-sm font-semibold text-accent-fg"
                onClick={() => {
                  unlockAudio();
                  startRun();
                }}
              >
                Tentar de novo
              </button>
              <button className="h-11 rounded-lg border border-border text-sm" onClick={() => setScreen("select")}>
                Trocar guerreiro
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function GameApp() {
  const screen = useGameStore((s) => s.screen);
  useEffect(() => {
    hydrateGameSave();
  }, []);
  if (screen === "title") return <TitleScreen />;
  if (screen === "help") return <HelpScreen />;
  if (screen === "select") return <SelectScreen />;
  return <PlayScreen />;
}
