# Estrutura

- `src/components/game-app.tsx`: telas, seletor de herói, HUD, joysticks e botões de habilidade.
- `src/game/types.ts`: tipos de heróis, habilidades, inimigos e HUD.
- `src/game/heroes.ts`: dados de heróis, descrições e formas de mira.
- `src/game/world.ts`: simulação fixa, combate, waves, bosses, habilidades e efeitos.
- `src/game/render.ts`: renderização Canvas 2D, partículas, telegráficos, aura e bosses.
- `src/game/runtime.ts`: loop de render, input e ligação da simulação ao React.
- `src/game/input.ts`: teclado, mouse, gamepad e joysticks touch.
- `public/portraits/scar.png`: retrato do Scar.
- `public/sprites/scar.png`: sprite transparente usado em combate.

A simulação continua desacoplada do React; o React apenas dirige HUD e entrada touch.
